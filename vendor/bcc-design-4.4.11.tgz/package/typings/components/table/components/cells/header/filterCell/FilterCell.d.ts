/// <reference types="react" />
import { FilterCellProps } from './FilterCell.type';
export declare const FilterItem: ({ header, filterArr, targetId }: {
    header: any;
    filterArr: any;
    targetId: any;
}) => import("react/jsx-runtime").JSX.Element;
export declare const FilterCell: React.FC<FilterCellProps>;
