/// <reference types="react" />
import { ActionsCellProps } from './ActionsCell.type';
export declare const ActionsCell: React.FC<ActionsCellProps>;
