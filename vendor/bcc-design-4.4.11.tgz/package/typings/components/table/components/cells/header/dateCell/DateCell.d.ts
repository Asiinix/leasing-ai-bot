/// <reference types="react" />
import { DateCellProps } from './DateCell.type';
export declare const DateItem: ({ header, targetId, calendarProps }: {
    header: any;
    targetId: any;
    calendarProps: any;
}) => import("react/jsx-runtime").JSX.Element;
export declare const DateCell: React.FC<DateCellProps>;
