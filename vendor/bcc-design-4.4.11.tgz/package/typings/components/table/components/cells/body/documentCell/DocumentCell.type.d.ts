/// <reference types="react" />
export interface DocumentCellProps {
    link: string;
    title: string;
    customIcon?: React.ReactNode;
    align?: 'start' | 'center' | 'end';
}
