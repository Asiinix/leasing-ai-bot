/// <reference types="react" />
import { Header } from '@tanstack/react-table';
import { FilterItem, TableStructure } from '../../../../../table/Table.type';
export interface FilterCellProps {
    columnId: string;
    header: Header<TableStructure, unknown>;
    filterArr?: FilterItem[];
    children: string | React.ReactNode;
}
