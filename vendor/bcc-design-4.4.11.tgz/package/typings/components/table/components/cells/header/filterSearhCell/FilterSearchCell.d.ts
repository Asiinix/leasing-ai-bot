/// <reference types="react" />
import { FilterSearchCellProps } from './FilterSearchCell.type';
export declare const FilterSearchCell: React.FC<FilterSearchCellProps>;
