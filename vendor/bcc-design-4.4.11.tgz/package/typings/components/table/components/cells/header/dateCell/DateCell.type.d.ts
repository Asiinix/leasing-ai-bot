/// <reference types="react" />
import { Header } from '@tanstack/react-table';
import { CalendarProps } from '../../../../../calendar';
import { FilterItem, TableStructure } from '../../../../../table/Table.type';
export interface DateCellProps {
    columnId: string;
    header: Header<TableStructure, unknown>;
    filterArr?: FilterItem[];
    children: string | React.ReactNode;
    disableSort?: boolean;
    calendarProps: CalendarProps;
    width?: string;
}
