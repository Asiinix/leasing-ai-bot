/// <reference types="react" />
export interface ActionProps {
    name: string | React.ReactNode;
    onClick: (e: React.MouseEvent, rowData: unknown) => void;
}
export interface ActionsCellProps {
    actions: ActionProps[];
    rowData: unknown;
}
