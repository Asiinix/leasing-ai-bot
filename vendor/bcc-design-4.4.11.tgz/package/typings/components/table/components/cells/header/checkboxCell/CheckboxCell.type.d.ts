import { Table } from '@tanstack/react-table';
import { Column, TableStructure } from '../../../../../table/Table.type';
export interface CheckboxCellProps {
    table: Table<TableStructure>;
    column: Column;
}
