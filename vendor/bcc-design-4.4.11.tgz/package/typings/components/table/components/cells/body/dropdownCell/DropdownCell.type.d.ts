import { Table } from '@tanstack/react-table';
import { TableStructure } from '../../../../../table';
export interface DropdownItem {
    title: string;
    desc?: string;
    onClick?: () => void;
}
export interface DropdownCellProps {
    id: string;
    items: DropdownItem[];
    table: Table<TableStructure>;
}
