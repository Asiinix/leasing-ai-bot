/// <reference types="react" />
export declare enum BasicCellPositionEnum {
    Start = "start",
    Center = "center",
    End = "end"
}
export interface BasicCellProps {
    children: string | React.ReactNode;
    position?: BasicCellPositionEnum;
    width?: string;
}
