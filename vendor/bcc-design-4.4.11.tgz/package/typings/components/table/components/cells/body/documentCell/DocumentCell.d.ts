/// <reference types="react" />
import { DocumentCellProps } from './DocumentCell.type';
export declare const DocumentCell: React.FC<DocumentCellProps>;
