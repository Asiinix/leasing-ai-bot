export declare const DocumentIcon: () => import("react/jsx-runtime").JSX.Element;
