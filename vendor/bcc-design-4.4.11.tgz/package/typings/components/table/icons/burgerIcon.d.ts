export declare const BurgerIcon: () => import("react/jsx-runtime").JSX.Element;
