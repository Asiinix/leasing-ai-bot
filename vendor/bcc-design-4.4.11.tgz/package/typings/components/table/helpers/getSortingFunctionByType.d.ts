import { Column } from '../Table.type';
export declare const getSortingFunctionByType: (column: Column) => any;
