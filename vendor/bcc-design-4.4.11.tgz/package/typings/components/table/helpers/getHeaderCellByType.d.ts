import { Header, Table } from '@tanstack/react-table';
import { Column, TableStructure } from '../Table.type';
export declare const getHeaderCellByType: (header: Header<TableStructure, unknown>, column: Column, table: Table<TableStructure>) => any;
