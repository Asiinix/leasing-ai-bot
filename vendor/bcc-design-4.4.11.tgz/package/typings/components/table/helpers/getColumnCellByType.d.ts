import { Row, Table } from '@tanstack/react-table';
import { Column, TableStructure } from '../Table.type';
export declare const getColumnCellByType: (column: Column, row: Row<TableStructure>, table: Table<TableStructure>) => any;
