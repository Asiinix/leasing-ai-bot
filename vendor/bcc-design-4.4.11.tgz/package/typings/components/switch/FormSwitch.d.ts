import React from 'react';
import { FormItemProps } from '../form';
import { SwitchProps } from './Switch.type';
export type FormSwitchProps = SwitchProps & Omit<FormItemProps, 'render'>;
export declare const FormSwitch: React.ForwardRefExoticComponent<Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "size"> & Omit<import("../toggle-control").ToggleControlProps, "Control"> & {
    size?: "sm" | "md" | undefined;
    checked?: boolean | undefined;
    onChange?: ((event: React.ChangeEvent<HTMLInputElement>, payload: import("./Switch.type").SwitchValuePayload) => void) | undefined;
    disabled?: boolean | undefined;
    'data-pw'?: string | undefined;
} & Omit<FormItemProps, "render"> & React.RefAttributes<HTMLInputElement>>;
