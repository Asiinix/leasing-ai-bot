import { HTMLAttributes } from 'react';
export type AnchorMenuItem = {
    id: string;
    title: string;
};
export type AnchorMenuProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange'> & {
    items: AnchorMenuItem[];
    activeId?: string;
    onChange?: (id: string) => void;
    scrollOffset?: number;
    'data-pw'?: string;
};
