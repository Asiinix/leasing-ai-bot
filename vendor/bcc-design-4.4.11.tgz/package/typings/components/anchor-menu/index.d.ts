export { AnchorMenu } from './AnchorMenu';
export type { AnchorMenuProps, AnchorMenuItem } from './AnchorMenu.type';
