/// <reference types="react" />
export declare const AnchorMenu: import("react").ForwardRefExoticComponent<Omit<import("react").HTMLAttributes<HTMLDivElement>, "onChange"> & {
    items: import("./AnchorMenu.type").AnchorMenuItem[];
    activeId?: string | undefined;
    onChange?: ((id: string) => void) | undefined;
    scrollOffset?: number | undefined;
    'data-pw'?: string | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
