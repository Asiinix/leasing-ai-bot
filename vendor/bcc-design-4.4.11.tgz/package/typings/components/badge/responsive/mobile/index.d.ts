export * from './BadgeMobile';
export type { BadgeMobileProps } from './BadgeMobile.type';
