/// <reference types="react" />
export declare const BadgeMobile: import("react").ForwardRefExoticComponent<import("./BadgeMobile.type").NativeProps & {
    view?: "count" | "icon" | undefined;
    size?: string | undefined;
    colors?: {
        color: string;
        iconColor?: string | undefined;
    } | undefined;
    children?: import("react").ReactNode;
    childrenRef?: import("react").LegacyRef<HTMLSpanElement> | undefined;
    styles?: {
        [key: string]: string;
    } | undefined;
    longCount?: boolean | undefined;
    stroke?: boolean | undefined;
    'data-test-id'?: string | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
