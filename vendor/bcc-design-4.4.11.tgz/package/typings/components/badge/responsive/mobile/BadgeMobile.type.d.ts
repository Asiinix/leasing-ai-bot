import React, { HTMLAttributes, LegacyRef } from 'react';
type ColorsProps = {
    color: string;
    iconColor?: string;
};
export type NativeProps = HTMLAttributes<HTMLDivElement>;
export type BadgeMobileProps = NativeProps & {
    /**
     * Форма компонента
     */
    view?: 'icon' | 'count';
    /**
     * @deprecated Size is fixed at 16px
     */
    size?: string;
    /**
     * Описание цветовых параметров
     */
    colors?: ColorsProps;
    /**
     * Содержимое компонента BadgeProps
     */
    children?: React.ReactNode;
    /**
     * ref на children
     */
    childrenRef?: LegacyRef<HTMLSpanElement> | undefined;
    /**
     * Основные стили компонента
     */
    styles?: {
        [key: string]: string;
    };
    /**
     * Длинный вид счетчика
     */
    longCount?: boolean;
    /**
     * Обводка компонента (1px inner stroke, размер увеличивается на 2px)
     */
    stroke?: boolean;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
export {};
