/// <reference types="react" />
export declare const BadgeDesktop: import("react").ForwardRefExoticComponent<import("./BadgeDesktop.type").NativeProps & {
    view?: "count" | "icon" | undefined;
    size?: string | undefined;
    stroke?: boolean | undefined;
    colors?: {
        color: string;
        iconColor?: string | undefined;
    } | undefined;
    children?: import("react").ReactNode;
    childrenRef?: import("react").LegacyRef<HTMLSpanElement> | undefined;
    styles?: {
        [key: string]: string;
    } | undefined;
    'data-test-id'?: string | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
