export * from './BadgeDesktop';
export type { BadgeDesktopProps } from './BadgeDesktop.type';
