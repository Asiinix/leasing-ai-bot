/// <reference types="react" />
export declare const Badge: import("react").ForwardRefExoticComponent<import("./Badge.type").NativeProps & {
    view?: "count" | "icon" | undefined;
    size?: string | undefined;
    colors?: {
        color: string;
        iconColor?: string | undefined;
    } | undefined;
    children?: import("react").ReactNode;
    childrenRef?: import("react").LegacyRef<HTMLSpanElement> | undefined;
    stroke?: boolean | undefined;
    styles?: {
        [key: string]: string;
    } | undefined;
    'data-test-id'?: string | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
