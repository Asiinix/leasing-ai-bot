import React, { CSSProperties, HTMLAttributes, LegacyRef } from 'react';
import { SingleTabProps } from '../../../tabs';
export type NativeProps = HTMLAttributes<HTMLDivElement>;
export type TopbarDefaultProps = NativeProps & {
    /**
     * Заголовок компонента
     */
    title?: string;
    /**
     * Отвечает за скрытие иконки назад
     */
    hideBackIcon?: boolean;
    /**
     * Отвечает за скрытие иконки действия
     */
    hideActionIcon?: boolean;
    /**
     * Обработчик клика по иконке назад
     */
    onBackActionClick?: () => void;
    /**
     * Иконка действия
     */
    actionIcon?: 'close' | 'info' | 'question';
    /**
     * Кастомная пользовательская иконка действия
     */
    customActionIcon?: React.ReactNode;
    /**
     * Обработчик клика по иконке действия
     */
    onActionClick?: () => void;
    /**
     * Счетчик для компонента Badge
     */
    badgeCount?: number | null;
    /**
     * Текст под заголовком
     */
    captionText?: string;
    /**
     * Обработчик клика по тексту под заголовком
     */
    onCaptionTextClick?: () => void;
    /**
     * Массив табов
     */
    tabs?: SingleTabProps[];
    /**
     * Выбранный id таба
     */
    selectedTabId?: number;
    /**
     * Обработчик изменения таба
     */
    onChangeTab?: (id: number) => void;
    /**
     * Включение поиска
     */
    enableSearch?: boolean;
    /**
     * Значение поиска
     */
    searchValue?: string;
    /**
     * Обработчик изменения поиска
     */
    onChangeSearch?: (value: string) => void;
    /**
     * Содержимое компонента BadgeProps
     */
    children?: React.ReactNode;
    /**
     * ref на children
     */
    childrenRef?: LegacyRef<HTMLSpanElement> | undefined;
    /**
     * Отвечает за стики позицию компонента
     */
    enableStickyPosition?: boolean;
    /**
     * Основные стили компонента
     */
    styles?: CSSProperties;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-pw'?: string;
};
