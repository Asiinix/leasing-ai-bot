/// <reference types="react" />
export declare const DefaultTopbar: import("react").ForwardRefExoticComponent<import("./DefaultTopbar.type").NativeProps & {
    title?: string | undefined;
    hideBackIcon?: boolean | undefined;
    hideActionIcon?: boolean | undefined;
    onBackActionClick?: (() => void) | undefined;
    actionIcon?: "close" | "info" | "question" | undefined;
    customActionIcon?: import("react").ReactNode;
    onActionClick?: (() => void) | undefined;
    badgeCount?: number | null | undefined;
    captionText?: string | undefined;
    onCaptionTextClick?: (() => void) | undefined;
    tabs?: import('../../../tabs').SingleTabProps[] | undefined;
    selectedTabId?: number | undefined;
    onChangeTab?: ((id: number) => void) | undefined;
    enableSearch?: boolean | undefined;
    searchValue?: string | undefined;
    onChangeSearch?: ((value: string) => void) | undefined;
    children?: import("react").ReactNode;
    childrenRef?: import("react").LegacyRef<HTMLSpanElement> | undefined;
    enableStickyPosition?: boolean | undefined;
    styles?: import("react").CSSProperties | undefined;
    'data-test-id'?: string | undefined;
    'data-pw'?: string | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
