import { SVGProps } from 'react';
export declare const BonusBccFilled: (props: SVGProps<SVGSVGElement>) => import("react/jsx-runtime").JSX.Element;
