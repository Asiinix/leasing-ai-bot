export declare const DoorIcon: () => import("react/jsx-runtime").JSX.Element;
