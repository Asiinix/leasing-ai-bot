type Props = {
    open: boolean;
    onClick?: () => void;
};
export declare const FridgeBackdrop: ({ open, onClick }: Props) => import("react/jsx-runtime").JSX.Element;
export {};
