import React from 'react';
type Props = {
    shouldRender: boolean;
    usePortal: boolean;
    container: Element | DocumentFragment | null;
    children: React.ReactNode;
};
export declare const FridgePortal: ({ shouldRender, usePortal, children, container }: Props) => React.ReactNode;
export {};
