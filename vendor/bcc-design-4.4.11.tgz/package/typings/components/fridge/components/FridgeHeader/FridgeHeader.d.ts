import { FridgeProps } from '../../Fridge.type';
type Props = {
    sticky?: boolean;
    highlight?: boolean;
    padding?: number;
    paddingX?: number;
    paddingY?: number;
    title?: FridgeProps['title'];
    description?: FridgeProps['description'];
    onClose?: FridgeProps['onClose'];
    actions?: FridgeProps['headerActions'];
    hideClose?: FridgeProps['hideClose'];
    position: FridgeProps['position'];
    view: FridgeProps['view'];
};
export declare const FridgeHeader: ({ title, description, actions, onClose, sticky, highlight, padding, paddingX, paddingY, hideClose, position, view, }: Props) => import("react/jsx-runtime").JSX.Element | null;
export {};
