import { FridgeProps } from '../../Fridge.type';
type Props = {
    sticky?: boolean;
    highlight?: boolean;
    padding?: number;
    paddingX?: number;
    paddingY?: number;
    actions: FridgeProps['actions'];
    view: FridgeProps['view'];
};
export declare const FridgeFooter: ({ actions, sticky, highlight, padding, paddingX, paddingY, view }: Props) => import("react/jsx-runtime").JSX.Element | null;
export {};
