import { CSSProperties, ReactNode } from 'react';
import { ButtonProps, ButtonVariant } from '../button';
export type FridgeView = 'primary' | 'secondary';
export type FridgeAction = {
    view?: ButtonVariant;
    title?: string;
    onClick?: () => void;
    size?: ButtonProps['size'];
    disabled?: boolean;
    fullWidth?: boolean;
    loading?: boolean;
};
export type FridgeProps = {
    /** Открыт/закрыт */
    open: boolean;
    /** Обработчик закрытия */
    onClose?: () => void;
    /** Заголовок */
    title?: string | ReactNode;
    /** Подзаголовок */
    description?: string;
    /** Позиция слева/справа */
    position?: 'left' | 'right';
    /** Прятать ли иконку закрытия */
    hideClose?: boolean;
    /** Контент компонента */
    children: ReactNode;
    /** Является ли header стики */
    stickyHeader?: boolean;
    /** Подсвечивать ли header при скролле, когда stickyHeader = true */
    highlightHeader?: boolean;
    /** Является ли footer стики */
    stickyFooter?: boolean;
    /** Подсвечивать ли footer при скролле, когда stickyFooter = true */
    highlightFooter?: boolean;
    /** Кнопки в header */
    headerActions?: FridgeAction[];
    /** Кнопки в footer */
    actions?: FridgeAction[];
    id?: string;
    /** Максимальная ширина */
    maxWidth?: CSSProperties['maxWidth'];
    /** Минимальная ширина */
    minWidth?: CSSProperties['minWidth'];
    /** Ширина */
    width?: CSSProperties['width'];
    /** Внутренний отступ */
    padding?: number;
    /** Горизонтальный внутренний отступ (переопределяет padding по горизонтали) */
    paddingX?: number;
    /** Вертикальный внутренний отступ (переопределяет padding по вертикали) */
    paddingY?: number;
    /** Вид */
    view?: FridgeView;
    /** z-index для компонента */
    zIndex?: CSSProperties['zIndex'];
    /** Атрибут data-pw для тестирования */
    'data-pw'?: string;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
};
