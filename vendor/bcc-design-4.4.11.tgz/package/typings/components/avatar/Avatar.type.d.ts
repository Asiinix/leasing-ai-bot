import React, { ReactNode } from 'react';
/**
 * Размеры для фирменной иконки
 */
export declare const altSizesBcc: {
    md: number;
    xl: number;
    xxl: number;
};
/**
 * Размеры для стандартной иконки
 */
export declare const altSizesIcon: {
    md: number;
    xl: number;
    xxl: number;
};
export declare enum TypeAvatar {
    Bcc = "bcc",
    Initials = "initials",
    Picture = "picture",
    Icon = "icon",
    Upload = "upload"
}
export interface BaseAvatarProps {
    children?: ReactNode;
    /**
     * Тип аватара (Фирменный, Инициалы, Картинка, Иконка)
     */
    type?: 'bcc' | 'initials' | 'picture' | 'icon' | 'upload';
    /**
     * Сокращенные инициалы пользователя
     */
    initials?: string;
    /**
     * URL путь до картинки
     */
    imgSrc?: string;
    /**
     * Размер аватара
     */
    size?: 'md' | 'xl' | 'xxl';
    /**
     * Кастомный стиль для аватара
     */
    className?: string;
    /**
     * Обработчик нажатия на аватар
     */
    onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
}
