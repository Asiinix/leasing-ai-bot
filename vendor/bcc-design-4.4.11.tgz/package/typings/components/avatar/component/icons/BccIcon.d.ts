type Props = {
    size?: number;
};
export declare const BccIcon: ({ size }: Props) => import("react/jsx-runtime").JSX.Element;
export {};
