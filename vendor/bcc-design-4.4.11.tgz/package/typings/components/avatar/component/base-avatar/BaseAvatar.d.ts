/// <reference types="react" />
import { BaseAvatarProps } from '../../Avatar.type';
export declare const BaseAvatar: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<BaseAvatarProps & import("react").RefAttributes<HTMLDivElement | null>>>;
