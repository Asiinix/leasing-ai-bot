import { BaseAvatar } from './component/base-avatar/BaseAvatar';
export { BaseAvatar as Avatar };
