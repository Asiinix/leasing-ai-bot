export { Avatar } from './Avatar';
export type { BaseAvatarProps, TypeAvatar } from './Avatar.type';
