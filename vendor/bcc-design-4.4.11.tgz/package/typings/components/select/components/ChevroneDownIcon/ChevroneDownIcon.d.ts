import React from 'react';
type Props = {
    isOpen: boolean;
    className?: string;
    onClick?: (e: React.MouseEvent) => void;
};
export declare const ChevroneDownIcon: React.MemoExoticComponent<({ isOpen, onClick, className }: Props) => import("react/jsx-runtime").JSX.Element>;
export {};
