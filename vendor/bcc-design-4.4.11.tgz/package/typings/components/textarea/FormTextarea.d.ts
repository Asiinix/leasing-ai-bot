import React from 'react';
import { FormItemProps } from '../form';
import { TextareaProps } from './Textarea.type';
export type FormTextareaProps = TextareaProps & Omit<FormItemProps, 'render'>;
export declare const FormTextarea: React.ForwardRefExoticComponent<Omit<FormTextareaProps, "ref"> & React.RefAttributes<HTMLTextAreaElement>>;
