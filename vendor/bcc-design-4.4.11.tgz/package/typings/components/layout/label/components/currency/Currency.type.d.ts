export type CurrencyProps = {
    /**
     * Тип валюты
     * */
    type?: 'kz' | 'us' | 'eu' | 'gb' | 'ru' | 'bcc_cashback';
    /**
     * Дополнительный класс
     * */
    className?: string;
};
