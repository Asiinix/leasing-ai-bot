/// <reference types="react" />
import { CurrencyProps } from './Currency.type';
export declare const Currency: React.FC<CurrencyProps>;
