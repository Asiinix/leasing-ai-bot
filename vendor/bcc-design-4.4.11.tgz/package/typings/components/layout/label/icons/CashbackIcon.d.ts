export declare const CashbackIcon: () => import("react/jsx-runtime").JSX.Element;
