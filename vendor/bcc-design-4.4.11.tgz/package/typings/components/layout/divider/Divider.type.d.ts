import { CSSProperties } from 'react';
export type DividerProps = {
    /**
     * Имя класса
     * */
    className?: string;
    /**
     * Убрать ли top и bottom margin
     * */
    noGap?: boolean;
    /**
     * Ориентация разделителя
     * */
    orientation?: 'horizontal' | 'vertical';
    /**
     * Толщина разделителя
     * */
    height?: number;
    /**
     * margin разделителя
     * */
    margin?: CSSProperties['margin'];
    /**
     * Стили
     * */
    style?: CSSProperties;
    /**
     * Цвет
     * */
    color?: CSSProperties['color'];
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
