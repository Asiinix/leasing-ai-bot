import { DividerProps } from './Divider.type';
export declare const Divider: ({ className, noGap, orientation, style, margin, color, height }: DividerProps) => import("react/jsx-runtime").JSX.Element;
