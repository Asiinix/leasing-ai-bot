export declare const getIsActiveLink: (currentLink: any, links: any) => any;
