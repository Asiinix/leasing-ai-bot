export declare const BusinessLogoShort: () => import("react/jsx-runtime").JSX.Element;
