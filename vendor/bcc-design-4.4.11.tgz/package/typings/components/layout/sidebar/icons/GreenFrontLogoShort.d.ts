export declare const GreenFrontLogoShort: () => import("react/jsx-runtime").JSX.Element;
