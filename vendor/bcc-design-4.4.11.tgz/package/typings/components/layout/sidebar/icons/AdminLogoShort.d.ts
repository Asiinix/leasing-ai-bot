export declare const AdminLogoShort: () => import("react/jsx-runtime").JSX.Element;
