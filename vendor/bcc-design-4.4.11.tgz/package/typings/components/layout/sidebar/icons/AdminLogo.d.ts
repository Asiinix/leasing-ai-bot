export declare const AdminLogo: () => import("react/jsx-runtime").JSX.Element;
