export declare const ExtendIcon: ({ className }: {
    className?: string | undefined;
}) => import("react/jsx-runtime").JSX.Element;
