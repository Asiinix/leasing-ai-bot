export declare const GreenFrontLogo: () => import("react/jsx-runtime").JSX.Element;
