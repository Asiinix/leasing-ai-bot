export declare const AdminLogoLight: () => import("react/jsx-runtime").JSX.Element;
