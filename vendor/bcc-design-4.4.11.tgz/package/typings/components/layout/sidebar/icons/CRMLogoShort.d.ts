export declare const CRMLogoShort: () => import("react/jsx-runtime").JSX.Element;
