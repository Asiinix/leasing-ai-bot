export declare const CRMLogoLight: () => import("react/jsx-runtime").JSX.Element;
