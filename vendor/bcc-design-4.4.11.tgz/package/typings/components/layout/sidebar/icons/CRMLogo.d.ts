export declare const CRMLogo: () => import("react/jsx-runtime").JSX.Element;
