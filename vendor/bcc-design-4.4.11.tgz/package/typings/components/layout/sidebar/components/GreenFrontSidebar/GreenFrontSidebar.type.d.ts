import { SidebarProps } from '../../Sidebar.type';
export type GreenFrontSidebarProps = SidebarProps;
