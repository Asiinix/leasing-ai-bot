export declare const CollapseMenu: ({ isCollapsed, isActive, title, wrapperId, trigger, isMenuOpened, setMenuClosed, subMenu, handleLink, currentLink, }: {
    isCollapsed: any;
    isActive: any;
    title: any;
    wrapperId: any;
    trigger: any;
    isMenuOpened: any;
    setMenuClosed: any;
    subMenu: any;
    handleLink: any;
    currentLink: any;
}) => import("react/jsx-runtime").JSX.Element;
