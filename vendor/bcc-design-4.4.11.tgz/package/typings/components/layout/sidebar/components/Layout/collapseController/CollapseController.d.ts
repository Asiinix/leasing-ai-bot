type CollapseControllerProps = {
    enableCollapse?: boolean;
    isCollapsed?: boolean;
    handleCollapse?: () => void;
};
export declare const CollapseController: ({ enableCollapse, isCollapsed, handleCollapse, }: CollapseControllerProps) => import("react/jsx-runtime").JSX.Element | null;
export {};
