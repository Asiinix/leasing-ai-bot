/// <reference types="react" />
export declare const AdminSidebar: import("react").ForwardRefExoticComponent<import("./AdminSidebar.type").NativeProps & {
    type?: "business" | "admin" | "crm" | "greenFront" | undefined;
    activeLink?: string | undefined;
    isLoading?: boolean | undefined;
    menuSkeletonCount?: number | undefined;
    navigationList: import("../..").NavigationItem[];
    enableScroll?: boolean | undefined;
    enableCollapse?: boolean | undefined;
    isCollapsed?: boolean | undefined;
    handleCollapse?: (() => void) | undefined;
    handleNavigate?: ((link: string) => void) | undefined;
    shouldNavigate?: boolean | undefined;
    customHeaderLogo?: import("react").ReactNode;
    enableFooterMenu?: boolean | undefined;
    hasTransparentBackground?: boolean | undefined;
    footerHelperLinkTitle?: string | undefined;
    footerHelperLinkAction?: (() => void) | undefined;
    footerTitle?: string | undefined;
    footerDescription?: string | undefined;
    footerProgressTitle?: string | undefined;
    footerProgressDetail?: string | undefined;
    footerProgressValue?: number | null | undefined;
    footerAction?: (() => void) | undefined;
    childrenRef?: import("react").LegacyRef<HTMLSpanElement> | undefined;
    styles?: import("react").CSSProperties | undefined;
    'data-test-id'?: string | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
