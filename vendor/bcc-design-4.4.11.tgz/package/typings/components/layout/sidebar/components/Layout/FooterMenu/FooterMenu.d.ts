/// <reference types="react" />
interface BusinessFooterMenuProps {
    footerTitle?: string;
    footerHelperLinkTitle?: string;
    footerHelperLinkAction?: () => void;
    footerDescription?: string;
    footerProgressTitle?: string;
    footerProgressDetail?: string;
    footerProgressValue?: number | null;
    footerAction?: () => void;
    enableFooterMenu?: boolean;
    isCollapsed?: boolean;
}
export declare const FooterMenu: React.FC<BusinessFooterMenuProps>;
export {};
