/// <reference types="react" />
export declare const BusinessSidebar: import("react").ForwardRefExoticComponent<import("./BusinessSidebar.type").NativeProps & {
    type?: "business" | "admin" | "crm" | "greenFront" | undefined;
    isLoading?: boolean | undefined;
    menuSkeletonCount?: number | undefined;
    activeLink?: string | undefined;
    navigationList: import("../..").NavigationItem[];
    enableFooterMenu?: boolean | undefined;
    footerHelperLinkTitle?: string | undefined;
    footerHelperLinkAction?: (() => void) | undefined;
    footerTitle?: string | undefined;
    footerDescription?: string | undefined;
    footerProgressTitle?: string | undefined;
    footerProgressDetail?: string | undefined;
    footerProgressValue?: number | null | undefined;
    footerAction?: (() => void) | undefined;
    enableCollapse?: boolean | undefined;
    isCollapsed?: boolean | undefined;
    handleCollapse?: (() => void) | undefined;
    handleNavigate?: ((link: string) => void) | undefined;
    shouldNavigate?: boolean | undefined;
    hasTransparentBackground?: boolean | undefined;
    customHeaderLogo?: import("react").ReactNode;
    customFooterMenu?: import("react").ReactNode;
    childrenRef?: import("react").LegacyRef<HTMLSpanElement> | undefined;
    styles?: import("react").CSSProperties | undefined;
    'data-test-id'?: string | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
