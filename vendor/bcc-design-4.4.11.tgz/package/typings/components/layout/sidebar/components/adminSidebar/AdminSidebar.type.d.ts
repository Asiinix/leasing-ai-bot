import { CSSProperties, HTMLAttributes, LegacyRef } from 'react';
import { NavigationItem } from '../../Sidebar.type';
export interface NavigationFooterItem extends Omit<NavigationItem, 'subMenu'> {
}
export type NativeProps = HTMLAttributes<HTMLTableElement>;
export type AdminSidebarProps = NativeProps & {
    /**
     * Тип компонента
     */
    type?: 'business' | 'admin' | 'crm' | 'greenFront';
    /**
     * Активная ссылка
     */
    activeLink?: string;
    /**
     * Для отображение загрузки если данные получаем с сервера
     */
    isLoading?: boolean;
    /**
     * Для отображение количества элементов загрузки
     */
    menuSkeletonCount?: number;
    /**
     * Основной список
     */
    navigationList: NavigationItem[];
    /**
     * Активирует скролл для основного списка
     */
    enableScroll?: boolean;
    /**
     * Активирует сворачивание/разворачивание компонента
     */
    enableCollapse?: boolean;
    /**
     * Отвечает за сворачивание/разворачивание компонента
     */
    isCollapsed?: boolean;
    /**
     * Сворачивает/разворачивает компонент
     */
    handleCollapse?: () => void;
    /**
     * Навигация по ссылке
     */
    handleNavigate?: (link: string) => void;
    /**
     * Дополнительный флаг для навигации
     */
    shouldNavigate?: boolean;
    /**
     * Кастомное лого в хедере
     */
    customHeaderLogo?: React.ReactNode;
    /**
     * Активация футерного меню
     */
    enableFooterMenu?: boolean;
    /**
     * Флаг для прозрачного фона
     */
    hasTransparentBackground?: boolean;
    /**
     * Заголовок ссылки в футере
     */
    footerHelperLinkTitle?: string;
    /**
     * Ссылка в футере
     */
    footerHelperLinkAction?: () => void;
    /**
     * Заголовок футера
     */
    footerTitle?: string;
    /**
     * Описание футера
     */
    footerDescription?: string;
    /**
     * Заголовок прогресс бара
     */
    footerProgressTitle?: string;
    /**
     * Деталь описания прогресс бара
     */
    footerProgressDetail?: string;
    /**
     * Значение прогресс бара
     */
    footerProgressValue?: number | null;
    /**
     * Обработчик при клике на футер
     */
    footerAction?: () => void;
    /**
     * ref на children
     */
    childrenRef?: LegacyRef<HTMLSpanElement> | undefined;
    /**
     * Основные стили компонента
     */
    styles?: CSSProperties;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
