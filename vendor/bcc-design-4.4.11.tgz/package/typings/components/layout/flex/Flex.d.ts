import React from 'react';
import { FlexProps, FlexPropsWithTypedAttrs, FlexRef } from './Flex.type';
export declare const Flex: (<C extends React.ElementType<any, keyof React.JSX.IntrinsicElements> = "div">(props: FlexProps<C> & Omit<React.PropsWithoutRef<React.ComponentProps<C>>, keyof FlexProps<T>> & {
    ref?: FlexRef<C> | undefined;
}) => React.ReactElement) & {
    displayName: string;
};
