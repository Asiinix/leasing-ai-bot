import { ContainerProps } from './Container.type';
export declare const Container: ({ children, style: outerStyle, as: Component, maxWidth, className, gutters, "data-test-id": dataTestId, }: ContainerProps) => import("react/jsx-runtime").JSX.Element;
