import { CSSProperties, ReactNode } from 'react';
import { BreakpointsKeys } from '../layout-config/breakpoints';
export interface ContainerProps {
    /**
     * Html тэг, который должен использоваться
     * */
    as?: keyof JSX.IntrinsicElements;
    /**
     * Максимальная ширина контейнера соответсвующая Breakpoints
     */
    maxWidth?: BreakpointsKeys | CSSProperties['maxWidth'];
    /**
     * Padding слева и справа
     */
    gutters?: CSSProperties['paddingRight'];
    /**
     * Название класса
     * */
    className?: string;
    /**
     * Стили
     * */
    style?: CSSProperties;
    children?: ReactNode;
    /**
     * Идентификатор для систем автоматизированного тестирования
     * */
    'data-test-id'?: string;
}
