import { FC } from 'react';
import { ColProps } from './components/col';
import { RowProps } from './components/row';
export declare const Grid: {
    Row: FC<RowProps>;
    Col: FC<ColProps>;
};
