import React from 'react';
import { MediaPartial } from '../../../layout-config/LayoutContext.type';
import { GridSystemValue } from '../../Grid.type';
export type AdaptiveGridSystemValue = GridSystemValue | MediaPartial<GridSystemValue>;
type ColAlignPosition = 'top' | 'middle' | 'bottom' | 'stretch';
type ColJustifyPosition = 'start' | 'end' | 'center';
export type ColPropsInternal = {
    /**
     * Внутреннее свойство для расчета ширины
     * */
    _wrappedRowCount: number;
    children?: React.ReactNode | React.ReactNode[];
    /**
     * Кол-во ед. занимаемое колонкой в 24-ой системе
     * */
    span?: AdaptiveGridSystemValue;
    /**
     * Выравнивание элемента по вертикали
     * */
    align?: ColAlignPosition;
    /**
     * Выравнивание элемента по горизонтали
     * */
    justify?: ColJustifyPosition;
    /**
     * Порядок элемента
     * */
    order?: GridSystemValue | 0;
    /**
     * Идентификатор для систем автоматизированного тестирования
     * */
    'data-test-id'?: string;
};
export type ColProps = Omit<ColPropsInternal, '_wrappedRowCount'>;
export {};
