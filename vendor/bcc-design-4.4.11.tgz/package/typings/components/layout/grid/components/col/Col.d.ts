import React from 'react';
import { ColProps } from './Col.type';
export declare const Col: React.MemoExoticComponent<(props: ColProps) => import("react/jsx-runtime").JSX.Element>;
