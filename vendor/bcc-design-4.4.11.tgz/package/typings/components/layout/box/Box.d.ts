import React from 'react';
import { BoxProps, BoxPropsWithTypedAttrs, BoxRef } from './Box.type';
export declare const Box: (<C extends React.ElementType<any, keyof React.JSX.IntrinsicElements> = "div">(props: BoxProps<C> & Omit<React.PropsWithoutRef<React.ComponentProps<C>>, keyof BoxProps<T>> & {
    ref?: BoxRef<C> | undefined;
}) => React.ReactElement) & {
    displayName: string;
};
