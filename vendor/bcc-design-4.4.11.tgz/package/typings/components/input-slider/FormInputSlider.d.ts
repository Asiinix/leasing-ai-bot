import React from 'react';
import { FormItemProps } from '../form';
import type { InputSliderProps } from './InputSlider.type';
export type FormInputSliderProps = InputSliderProps & Omit<FormItemProps, 'render'>;
export declare const FormInputSlider: React.ForwardRefExoticComponent<InputSliderProps & Omit<FormItemProps, "render"> & React.RefAttributes<HTMLInputElement>>;
