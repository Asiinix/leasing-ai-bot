/// <reference types="react" />
import { CustomSliderProps } from './CustomSlider.type';
export declare const CustomSlider: React.FC<CustomSliderProps>;
