export interface CustomSliderProps {
    max?: number;
    min?: number;
    onChange?: (value: number) => void;
    /** Пользователь закончил выбор: отпустил мышь или палец, изменил значение с клавиатуры */
    onChangeComplete?: (value: number) => void;
    /** @deprecated используйте onChangeComplete: срабатывал только на отпускание мыши */
    onMouseUp?: (value: number) => void;
    value?: number;
    disabled?: boolean;
    stepMarks?: number[];
}
