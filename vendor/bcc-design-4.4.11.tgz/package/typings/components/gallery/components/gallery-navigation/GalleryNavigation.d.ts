import { GalleryNavigationProps } from './GalleryNavigation.type';
export declare const GalleryNavigation: ({ state, handlers, hideThumbs, hideArrows }: GalleryNavigationProps) => import("react/jsx-runtime").JSX.Element | null;
