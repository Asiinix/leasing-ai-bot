import type { CarouselHandlers, CarouselState } from '../../../carousel';
export type GalleryNavigationProps = {
    state: CarouselState;
    handlers: CarouselHandlers;
    hideArrows?: boolean;
    hideThumbs?: boolean;
};
