export type GalleryHeaderProps = {
    heading?: string;
    subheading?: string;
};
