import React from 'react';
import { GalleryHeaderProps } from './GalleryHeader.type';
export declare const GalleryHeader: React.MemoExoticComponent<({ heading, subheading }: GalleryHeaderProps) => import("react/jsx-runtime").JSX.Element | null>;
