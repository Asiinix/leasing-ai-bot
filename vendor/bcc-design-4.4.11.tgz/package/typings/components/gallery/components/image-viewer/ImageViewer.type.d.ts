import React from 'react';
import type { CarouselHandlers } from '../../../carousel';
import type { ModalV2Props } from '../../../modal-v2';
export type ImageViewerProps = {
    open: ModalV2Props['open'];
    onClose: ModalV2Props['onClose'];
    handlers: CarouselHandlers;
    cachedImages: string[];
    currentIndex: number;
    objectFit?: React.CSSProperties['objectFit'];
    thumbsObjectFit?: React.CSSProperties['objectFit'];
};
