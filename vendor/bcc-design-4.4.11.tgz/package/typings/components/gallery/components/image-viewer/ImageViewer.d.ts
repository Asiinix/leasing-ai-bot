import React from 'react';
import type { ImageViewerProps } from './ImageViewer.type';
export declare const ImageViewer: React.MemoExoticComponent<({ open, onClose, cachedImages, handlers, currentIndex, objectFit, thumbsObjectFit }: ImageViewerProps) => import("react/jsx-runtime").JSX.Element>;
