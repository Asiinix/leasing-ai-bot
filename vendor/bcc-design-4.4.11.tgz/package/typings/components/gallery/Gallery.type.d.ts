import { CSSProperties } from 'react';
import type { CarouselImageProps, CarouselProps } from '../carousel';
import type { GalleryHeaderProps } from './components/gallery-header';
import type { GalleryNavigationProps } from './components/gallery-navigation';
export type SliderImageObj = {
    src: CarouselImageProps['src'];
    alt?: CarouselImageProps['alt'];
    className?: CarouselImageProps['className'];
    loading?: CarouselImageProps['loading'];
    showZoom?: CarouselImageProps['showZoom'];
    objectFit?: CarouselImageProps['objectFit'];
    borderRadius?: CarouselImageProps['borderRadius'];
};
export type GalleryProps = {
    images: SliderImageObj[];
    objectFit?: CarouselImageProps['objectFit'];
    onImageClick?: CarouselImageProps['onClick'];
    visibleSlides?: CarouselProps['visibleSlides'];
    autoPlay?: CarouselProps['autoPlay'];
    autoPlayInterval?: CarouselProps['autoPlayInterval'];
    slideGap?: CarouselProps['slideGap'];
    carouselContainerStyles?: CarouselProps['containerStyles'];
    height?: CSSProperties['height'];
    disabledCache?: boolean;
    imageViewerObjectFit?: CSSProperties['objectFit'];
    imageViewerThumbsObjectFit?: CSSProperties['objectFit'];
    heading?: GalleryHeaderProps['heading'];
    subheading?: GalleryHeaderProps['subheading'];
    hideArrows?: GalleryNavigationProps['hideArrows'];
    hideThumbs?: GalleryNavigationProps['hideThumbs'];
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
};
