/// <reference types="react" />
export declare const Checkbox: import("react").ForwardRefExoticComponent<Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "onChange" | "size"> & Omit<import("../toggle-control").ToggleControlProps, "Control"> & {
    checked?: boolean | undefined;
    onChange?: ((event: import("react").ChangeEvent<HTMLInputElement>, payload: import("./Checkbox.type").CheckboxValuePayload) => void) | undefined;
    size?: "sm" | "md" | "lg" | undefined;
    indeterminate?: boolean | undefined;
    disabled?: boolean | undefined;
} & import("react").RefAttributes<HTMLInputElement>>;
