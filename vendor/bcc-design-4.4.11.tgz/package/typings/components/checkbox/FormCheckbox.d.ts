import React from 'react';
import { FormItemProps } from '../form';
import { CheckboxProps } from './Checkbox.type';
export type FormCheckboxProps = CheckboxProps & Omit<FormItemProps, 'render'>;
export declare const FormCheckbox: React.ForwardRefExoticComponent<Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "size"> & Omit<import("../toggle-control").ToggleControlProps, "Control"> & {
    checked?: boolean | undefined;
    onChange?: ((event: React.ChangeEvent<HTMLInputElement>, payload: import("./Checkbox.type").CheckboxValuePayload) => void) | undefined;
    size?: "sm" | "md" | "lg" | undefined;
    indeterminate?: boolean | undefined;
    disabled?: boolean | undefined;
} & Omit<FormItemProps, "render"> & React.RefAttributes<HTMLInputElement>>;
