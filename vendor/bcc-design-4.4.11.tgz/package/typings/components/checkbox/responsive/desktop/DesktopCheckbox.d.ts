import { ChangeEvent } from 'react';
export declare const DesktopCheckbox: import("react").ForwardRefExoticComponent<Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "onChange" | "size"> & Omit<import("../../../toggle-control").ToggleControlProps, "Control"> & {
    checked?: boolean | undefined;
    onChange?: ((event: ChangeEvent<HTMLInputElement>, payload: import("./DesktopCheckbox.type").DesktopCheckboxValuePayload) => void) | undefined;
    size?: "sm" | "md" | "lg" | undefined;
    indeterminate?: boolean | undefined;
    disabled?: boolean | undefined;
} & import("react").RefAttributes<HTMLInputElement>>;
