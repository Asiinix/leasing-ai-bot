import { ChangeEvent, InputHTMLAttributes } from 'react';
import { ToggleControlProps } from '../toggle-control/ToggleControl.type';
type NativeProps = InputHTMLAttributes<HTMLInputElement>;
export type CheckboxValuePayload = {
    checked: boolean;
    name: string;
};
export type CheckboxProps = 
/**
 * Нативные пропсы инпута
 * */
Omit<NativeProps, 'size' | 'onChange'> & 
/**
 * Все пропсы ToggleControl кроме Control.
 * Control указывается руками в зависимости от компонента
 * */
Omit<ToggleControlProps, 'Control'> & /**
 * Пропсы чекбокса
 * */ {
    /**
     * Состояние переключателя: включен или выключен
     */
    checked?: boolean;
    /**
     * Обработчик переключения чекбокса
     */
    onChange?: (event: ChangeEvent<HTMLInputElement>, payload: CheckboxValuePayload) => void;
    /**
     * Размер компонента
     */
    size?: 'sm' | 'md' | 'lg';
    /**
     * Визуально переводит чекбокс в неопределенное состояние. Не влияет на состояние, указанное в `checked`.
     *
     * Может использоваться в дереве чекбоксов, чтобы показать состояние родительского чекбокса,
     * когда хотя бы один вложенный чекбокс отмечен, но не все.
     *
     * Если свойство задано родительскому чекбоксу,
     * то в `aria-controls` необходимо добавить `id` всех вложенных чекбоксов
     */
    indeterminate?: boolean;
    /**
     * Включен / выключен
     */
    disabled?: boolean;
};
export {};
