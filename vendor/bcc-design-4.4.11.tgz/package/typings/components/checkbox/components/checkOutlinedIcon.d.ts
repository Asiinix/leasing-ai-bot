import { SVGProps } from 'react';
export declare const CheckOutlinedIcon: React.FC<SVGProps<SVGSVGElement>>;
