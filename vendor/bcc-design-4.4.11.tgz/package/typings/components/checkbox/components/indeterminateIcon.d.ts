import { SVGProps } from 'react';
export declare const IndeterminateIcon: React.FC<SVGProps<SVGSVGElement>>;
