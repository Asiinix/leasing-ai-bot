import React from 'react';
import { FormItemProps } from '../form';
import { RadioProps } from './Radio.type';
export type FormRadioProps = RadioProps & Omit<FormItemProps, 'render'>;
export declare const FormRadio: React.ForwardRefExoticComponent<Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "size"> & Omit<import("../toggle-control").ToggleControlProps, "Control"> & {
    checked?: boolean | undefined;
    onChange?: ((event: React.ChangeEvent<HTMLInputElement>, payload: import("./Radio.type").RadioValuePayload) => void) | undefined;
    size?: "sm" | "md" | "lg" | undefined;
    disabled?: boolean | undefined;
    showTooltip?: boolean | undefined;
} & Omit<FormItemProps, "render"> & React.RefAttributes<HTMLInputElement>>;
