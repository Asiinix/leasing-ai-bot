import { SupportedCalendarLocales } from '../../utilities/dates/calendar/calendar-base-class.type';
export type DatePickerFooterStrings = {
    reset: string;
    select: string;
};
export declare const getFooterStrings: (locale?: SupportedCalendarLocales) => DatePickerFooterStrings;
