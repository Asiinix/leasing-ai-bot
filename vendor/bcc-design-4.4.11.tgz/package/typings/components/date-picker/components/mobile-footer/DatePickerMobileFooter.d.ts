import React from 'react';
import { DatePickerProps } from '../../DatePicker.type';
type DatePickerMobileFooterProps = {
    value: DatePickerProps['value'];
    onConfirm?: () => void;
    onCancel?: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    cancelText?: DatePickerProps['footerCancelText'];
    submitText?: DatePickerProps['footerSubmitText'];
};
export declare const DatePickerMobileFooter: React.MemoExoticComponent<({ onConfirm, onCancel, value, cancelText, submitText }: DatePickerMobileFooterProps) => import("react/jsx-runtime").JSX.Element>;
export {};
