import React from 'react';
type DatePickerMobileHeaderProps = {
    title?: string;
    subtitle?: string;
    onBack?: () => void;
};
export declare const DatePickerMobileHeader: React.MemoExoticComponent<({ title, onBack, subtitle }: DatePickerMobileHeaderProps) => import("react/jsx-runtime").JSX.Element>;
export {};
