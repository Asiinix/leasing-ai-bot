import React from 'react';
import { DatePickerPreset, DatePickerValue } from '../../DatePicker.type';
type Props = {
    value?: DatePickerValue;
    hide?: boolean;
    sortedPresets?: DatePickerPreset[];
    onPresetClick: (e: React.MouseEvent<HTMLButtonElement>) => void;
    vertical?: boolean;
    className?: string;
    showShadow?: boolean;
    'data-pw'?: string;
};
export declare const DatePickerPresets: React.MemoExoticComponent<({ sortedPresets, onPresetClick, vertical, hide, className, showShadow, value, "data-pw": dataPw }: Props) => import("react/jsx-runtime").JSX.Element | null>;
export {};
