import React from 'react';
import { DatePickerProps } from '../../DatePicker.type';
type Props = {
    show?: boolean;
    value: DatePickerProps['value'];
    locale?: DatePickerProps['locale'];
    onCancel?: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    onConfirm?: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    cancelText?: DatePickerProps['footerCancelText'];
    submitText?: DatePickerProps['footerSubmitText'];
    'data-pw'?: string;
};
export declare const DatePickerFooter: ({ onCancel, onConfirm, value, show, locale, cancelText, submitText, "data-pw": dataPw, }: Props) => import("react/jsx-runtime").JSX.Element | null;
export {};
