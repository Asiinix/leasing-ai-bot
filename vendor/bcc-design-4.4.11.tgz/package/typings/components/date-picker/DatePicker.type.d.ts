/// <reference types="react" />
import { CalendarProps, CalendarValueRange, CalendarValueSingle } from '../calendar';
import { DropdownProps } from '../dropdown';
import { InputOnChangeHandler, InputProps } from '../input';
export type DatePickerValue = DatePickerSingle | DatePickerRange;
export type DatePickerSingle = CalendarValueSingle;
export type DatePickerRange = CalendarValueRange;
export type DatePickerValuePayload = {
    value: DatePickerValue;
    name: string;
    /** Нужно для правильной работы с Form.Item */
    target?: {
        value: DatePickerValue;
    };
};
export type DatePickerPreset = {
    label: string;
    value: DatePickerValue;
};
export type DatePickerChangeHandler = (data: DatePickerValuePayload) => void;
type NativeDropdownProps = Pick<DropdownProps, 'position' | 'placement' | 'zIndex' | 'autoFlip' | 'fallbackPlacements'>;
type NativeCalendarProps = Pick<CalendarProps, 'minDate' | 'maxDate' | 'period' | 'weekStart' | 'siblingMonths' | 'withMonthsList' | 'withYearSelect' | 'scrollIntoCurrentMonth' | 'isRange' | 'onDaySelect' | 'locale' | 'showWeekdays' | 'stickyMonthLabel' | 'disableWeekends' | 'dayModifiers'>;
type NativeInputProps = Pick<InputProps, 'fullWidth' | 'size' | 'disabled' | 'error' | 'hint' | 'label' | 'labelType' | 'leftAddon' | 'preserveCaptionSpace' | 'animateCaption' | 'clear' | 'focusAfterClear' | 'onClear' | 'onClick' | 'name' | 'id' | 'onFocus' | 'onBlur' | 'placeholder' | 'readOnly' | 'loading'>;
export type DatePickerProps = NativeDropdownProps & NativeCalendarProps & NativeInputProps & {
    isOpen?: boolean;
    onOpen?: () => void;
    onClose?: () => void;
    value?: DatePickerValue;
    onChange?: DatePickerChangeHandler;
    /** Когда isRange = true, onChange будет отрабатывать только при value = [Date, Date] или [null, null] */
    enableFullRangeOnly?: boolean;
    /** Закрывать ли календарь после выбора даты/дат */
    closeAfterSelect?: boolean;
    /**
     * Разрешать ли вписывать дату в инпут руками (только десктоп).
     * Введенная дата сразу становится значением датапикера, и календарь открывается на ней.
     * */
    manualInput?: boolean;
    /**
     * Массив заранее подготовленных опций для выбора даты или периода
     * */
    presets?: DatePickerPreset[];
    /**
     * При выборе пресета, показывать значение пресета вместо даты
     * */
    showPresetLabelAsValue?: boolean;
    /**
     * Показывать ли футер с кнопками сброса и подтверждения. На десктопе появляется после полного выбора даты или периода
     * */
    withFooter?: boolean;
    /** Текст кнопки cancel у футера */
    footerCancelText?: string;
    /** Текст кнопки submit у футера */
    footerSubmitText?: string;
    parentId?: string;
    /**
     * Заголовок, который будет в BottomSheet в мобильной версии
     * */
    mobileTitle?: string;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
    /**
     * Кастомная функция рендера инпута.
     * Если указана, будет использована вместо стандартного Input компонента
     */
    renderInput?: (props: {
        /** Ref для инпута */
        ref: React.Ref<HTMLInputElement>;
        /** Текущее значение для отображения */
        value: string;
        /** Обработчик фокуса */
        onFocus: (e: React.FocusEvent<HTMLInputElement>) => void;
        /** Обработчик ручного ввода даты (только десктоп) */
        onChange?: InputOnChangeHandler;
        /** Обработчик потери фокуса: возвращает инпуту отформатированное значение (только десктоп) */
        onBlur?: (e: React.FocusEvent<HTMLInputElement>) => void;
        /** Обработчик очистки */
        onClear: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
        /** Состояние загрузки */
        loading?: boolean;
        /** Имя поля */
        name: string;
    }) => React.ReactNode;
};
export {};
