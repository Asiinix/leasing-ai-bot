/// <reference types="react" />
import { ChildWatcherProps } from './ChildMutationWatcher.type';
export declare const ChildMutationWatcher: ({ children, container, onChange }: ChildWatcherProps) => import("react").ReactNode;
