import { ReactNode, RefObject } from 'react';
export type ChildWatcherProps = {
    children: ReactNode;
    container: RefObject<HTMLDivElement>;
    onChange?: (record: MutationRecord[]) => void;
};
