/// <reference types="react" />
import { FocusLockProps } from './FocusLock.type';
export declare const FocusLock: ({ children, disabled, "data-test-id": dataTestId, ...props }: FocusLockProps) => string | number | boolean | import("react/jsx-runtime").JSX.Element | Iterable<import("react").ReactNode> | null | undefined;
