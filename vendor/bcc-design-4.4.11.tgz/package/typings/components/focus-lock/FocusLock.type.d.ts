import { ReactNode } from 'react';
export type FocusLockProps = {
    children: ReactNode;
    /** Возвращать ли фокус на последний активный элемент после FocusLock unmount */
    returnFocus?: boolean;
    /**
     * Когда FocusLock рендерится, он захватывает фокус внутри дочерних элементов.
     * onActivityChange - отрабатывает когда фокус смещается (например при открытии модалки).
     * */
    onActivityChange?: (active: boolean) => void;
    /** Фокусить ли первый focusable элемент при рендере */
    autoFocus?: boolean;
    /** Отключен ли FocusLock */
    disabled?: boolean;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
};
