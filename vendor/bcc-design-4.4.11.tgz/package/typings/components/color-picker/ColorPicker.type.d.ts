import React, { InputHTMLAttributes } from 'react';
export type NativeProps = InputHTMLAttributes<HTMLInputElement>;
export type ColorPickerProps = Omit<NativeProps, 'onChange' | 'value'> & {
    /**
     * Выбранный цвет
     */
    value?: string;
    /**
     * Цвет по умолчанию для сброса
     */
    defaultColor?: string;
    /**
     * Неактивное состояние ColorPicker
     */
    disabled?: boolean;
    /**
     * Состояние загрузки
     */
    loading?: boolean;
    /**
     * Показывать ли предварительный просмотр цвета
     */
    showPreview?: boolean;
    /**
     * Показывать текущий цвет в круге (вместо радужного градиента)
     */
    showColorInCircle?: boolean;
    /**
     * Предустановленные цвета
     */
    presetColors?: (string | undefined)[];
    /**
     * Маркер доступности
     */
    ariaLabel?: string;
    /**
     * Обработчик изменения цвета
     */
    onChange?: (event: React.ChangeEvent<HTMLInputElement>, payload: {
        value: string;
        hex: string;
        rgb: {
            r: number;
            g: number;
            b: number;
        };
        hsl: {
            h: number;
            s: number;
            l: number;
        };
    }) => void;
    /**
     * Обработчик завершения выбора цвета
     */
    onComplete?: (event: React.ChangeEvent<HTMLInputElement>, payload: {
        value: string;
        hex: string;
        rgb: {
            r: number;
            g: number;
            b: number;
        };
        hsl: {
            h: number;
            s: number;
            l: number;
        };
    }) => void;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
