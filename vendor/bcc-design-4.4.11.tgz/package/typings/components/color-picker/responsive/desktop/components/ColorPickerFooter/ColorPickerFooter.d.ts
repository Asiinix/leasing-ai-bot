import React from 'react';
interface ColorPickerFooterProps {
    onReset: () => void;
    onConfirm: () => void;
}
export declare const ColorPickerFooter: React.FC<ColorPickerFooterProps>;
export {};
