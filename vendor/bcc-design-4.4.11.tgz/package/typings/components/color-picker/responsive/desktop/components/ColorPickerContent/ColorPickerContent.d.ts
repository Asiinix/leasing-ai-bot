import React from 'react';
interface ColorPickerContentProps {
    saturationLightnessGradient: string;
    saturation: number;
    lightness: number;
    tempValue: string;
    hue: number;
    alpha: number;
    presetColors: string[];
    onMouseDown: (event: React.MouseEvent<HTMLDivElement>) => void;
    onMouseMove: (event: React.MouseEvent<HTMLDivElement>) => void;
    onMouseUp: (event: React.MouseEvent<HTMLDivElement>) => void;
    onSaturationLightnessChange: (event: React.MouseEvent<HTMLDivElement>) => void;
    onHueChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onAlphaChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onHexInputChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onPresetClick: (color: string) => void;
}
export declare const ColorPickerContent: React.FC<ColorPickerContentProps>;
export {};
