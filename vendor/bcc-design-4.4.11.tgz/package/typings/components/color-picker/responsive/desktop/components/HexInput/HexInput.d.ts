import React from 'react';
interface HexInputProps {
    value: string;
    onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
export declare const HexInput: React.FC<HexInputProps>;
export {};
