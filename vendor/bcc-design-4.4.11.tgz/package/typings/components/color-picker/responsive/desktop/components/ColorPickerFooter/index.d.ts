export { ColorPickerFooter } from './ColorPickerFooter';
