export { TransparencySlider } from './TransparencySlider';
