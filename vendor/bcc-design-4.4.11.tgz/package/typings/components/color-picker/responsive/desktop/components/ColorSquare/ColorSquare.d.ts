import React from 'react';
interface ColorSquareProps {
    saturationLightnessGradient: string;
    saturation: number;
    lightness: number;
    tempValue: string;
    onMouseDown: (event: React.MouseEvent<HTMLDivElement>) => void;
    onMouseMove: (event: React.MouseEvent<HTMLDivElement>) => void;
    onMouseUp: (event: React.MouseEvent<HTMLDivElement>) => void;
    onClick: (event: React.MouseEvent<HTMLDivElement>) => void;
}
export declare const ColorSquare: React.FC<ColorSquareProps>;
export {};
