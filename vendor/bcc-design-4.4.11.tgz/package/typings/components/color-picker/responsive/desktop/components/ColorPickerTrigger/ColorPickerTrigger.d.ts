import React from 'react';
interface ColorPickerTriggerProps {
    currentValue: string;
    showPreview?: boolean;
    showColorInCircle?: boolean;
    disabled?: boolean;
    onOpen: () => void;
    alpha?: number;
    'data-pw'?: string;
}
export declare const ColorPickerTrigger: React.FC<ColorPickerTriggerProps>;
export {};
