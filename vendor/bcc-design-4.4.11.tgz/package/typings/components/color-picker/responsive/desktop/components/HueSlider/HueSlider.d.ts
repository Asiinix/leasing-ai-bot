import React from 'react';
interface HueSliderProps {
    hue: number;
    onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
export declare const HueSlider: React.FC<HueSliderProps>;
export {};
