import React from 'react';
interface ColorGridProps {
    tempValue: string;
    onColorClick: (color: string) => void;
}
export declare const ColorGrid: React.FC<ColorGridProps>;
export {};
