import React from 'react';
interface GridModeContentProps {
    presetColors: string[];
    tempValue: string;
    alpha: number;
    onPresetClick: (color: string) => void;
    onAlphaChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onHexInputChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
export declare const GridModeContent: React.FC<GridModeContentProps>;
export {};
