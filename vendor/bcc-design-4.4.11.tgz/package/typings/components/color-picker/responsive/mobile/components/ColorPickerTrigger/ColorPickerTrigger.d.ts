import React from 'react';
interface ColorPickerTriggerProps {
    currentValue: string;
    showPreview?: boolean;
    disabled?: boolean;
    onOpen: () => void;
    alpha?: number;
}
export declare const ColorPickerTrigger: React.FC<ColorPickerTriggerProps>;
export {};
