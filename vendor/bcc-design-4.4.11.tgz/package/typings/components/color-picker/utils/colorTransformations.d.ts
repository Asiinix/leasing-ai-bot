export declare const hexToRgb: (hex: string) => {
    r: number;
    g: number;
    b: number;
};
export declare const rgbToHsl: (r: number, g: number, b: number) => {
    h: number;
    s: number;
    l: number;
};
export declare const hslToHex: (h: number, s: number, l: number) => string;
