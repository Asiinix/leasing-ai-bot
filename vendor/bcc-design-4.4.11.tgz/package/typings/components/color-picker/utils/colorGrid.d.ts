export declare const createColorGrid: () => string[];
