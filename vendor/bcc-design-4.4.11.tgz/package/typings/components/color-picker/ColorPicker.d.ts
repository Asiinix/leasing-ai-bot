/// <reference types="react" />
export declare const ColorPicker: import("react").ForwardRefExoticComponent<Omit<import("./ColorPicker.type").NativeProps, "onChange" | "value"> & {
    value?: string | undefined;
    defaultColor?: string | undefined;
    disabled?: boolean | undefined;
    loading?: boolean | undefined;
    showPreview?: boolean | undefined;
    showColorInCircle?: boolean | undefined;
    presetColors?: (string | undefined)[] | undefined;
    ariaLabel?: string | undefined;
    onChange?: ((event: import("react").ChangeEvent<HTMLInputElement>, payload: {
        value: string;
        hex: string;
        rgb: {
            r: number;
            g: number;
            b: number;
        };
        hsl: {
            h: number;
            s: number;
            l: number;
        };
    }) => void) | undefined;
    onComplete?: ((event: import("react").ChangeEvent<HTMLInputElement>, payload: {
        value: string;
        hex: string;
        rgb: {
            r: number;
            g: number;
            b: number;
        };
        hsl: {
            h: number;
            s: number;
            l: number;
        };
    }) => void) | undefined;
    'data-test-id'?: string | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
