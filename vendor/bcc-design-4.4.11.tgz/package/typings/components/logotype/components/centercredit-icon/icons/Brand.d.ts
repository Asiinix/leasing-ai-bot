import { FC } from 'react';
import { LogotypeIconProps } from '../../../Logotype.type';
export declare const Brand: FC<LogotypeIconProps>;
