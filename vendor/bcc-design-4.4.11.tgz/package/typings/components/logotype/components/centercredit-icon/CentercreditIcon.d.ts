import { BaseLogotypeProps } from '../../Logotype.type';
export type CentercreditIconProps = Omit<BaseLogotypeProps, 'appearance'> & {
    appearance?: 'default' | 'brand' | 'neutral';
    'data-pw'?: string;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
};
export declare const CentercreditIcon: ({ size, appearance, invert, "data-pw": dataPw, "data-test-id": dataTestId, }: CentercreditIconProps) => import("react/jsx-runtime").JSX.Element;
