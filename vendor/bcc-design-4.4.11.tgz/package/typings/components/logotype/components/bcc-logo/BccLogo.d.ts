import { BaseLogotypeProps } from '../../Logotype.type';
export type BccLogoProps = Omit<BaseLogotypeProps, 'appearance'> & {
    appearance?: 'default' | 'neutral';
    'data-pw'?: string;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
};
export declare const BccLogo: ({ size, appearance, invert, "data-pw": dataPw, "data-test-id": dataTestId, }: BccLogoProps) => import("react/jsx-runtime").JSX.Element;
