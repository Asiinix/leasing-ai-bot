import { BaseLogotypeProps } from '../../Logotype.type';
export type BccHubLogoProps = Omit<BaseLogotypeProps, 'appearance'> & {
    appearance?: 'default';
    'data-pw'?: string;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
};
export declare const BccHubLogo: ({ size, appearance, invert, "data-pw": dataPw, "data-test-id": dataTestId, }: BccHubLogoProps) => import("react/jsx-runtime").JSX.Element;
