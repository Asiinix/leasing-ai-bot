import { FC } from 'react';
import { LogotypeIconProps } from '../../../Logotype.type';
export declare const DefaultInvert: FC<LogotypeIconProps>;
