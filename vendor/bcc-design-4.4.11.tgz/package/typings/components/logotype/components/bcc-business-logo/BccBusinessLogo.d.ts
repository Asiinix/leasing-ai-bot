import { BaseLogotypeProps } from '../../Logotype.type';
export type BccBusinessLogoProps = Omit<BaseLogotypeProps, 'appearance'> & {
    appearance?: 'brand' | 'neutral';
    'data-pw'?: string;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
};
export declare const BccBusinessLogo: ({ size, appearance, invert, "data-pw": dataPw, "data-test-id": dataTestId, }: BccBusinessLogoProps) => import("react/jsx-runtime").JSX.Element;
