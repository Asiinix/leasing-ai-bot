import React from 'react';
import { LogotypeIconProps } from '../../../Logotype.type';
export declare const Brand: React.FC<LogotypeIconProps>;
