import React from 'react';
import { LogotypeIconProps } from '../../../Logotype.type';
export declare const BrandInvert: React.FC<LogotypeIconProps>;
