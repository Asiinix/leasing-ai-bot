import { BaseLogotypeProps } from '../../Logotype.type';
export type CentercreditLogoProps = Omit<BaseLogotypeProps, 'appearance'> & {
    appearance?: 'default' | 'brand' | 'neutral';
    'data-pw'?: string;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
};
export declare const CentercreditLogo: ({ size, appearance, invert, "data-pw": dataPw, "data-test-id": dataTestId, }: CentercreditLogoProps) => import("react/jsx-runtime").JSX.Element;
