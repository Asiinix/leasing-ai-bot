import React from 'react';
import { LogotypeIconProps } from '../../../Logotype.type';
export declare const Default: React.FC<LogotypeIconProps>;
