export type { ChipProps } from './Chip.type';
export { Chip } from './Chip';
