import React from 'react';
export declare const Chip: React.ForwardRefExoticComponent<Omit<import('../chip/Chip.type').NativeProps, "onClick"> & {
    variant?: "active" | "inactive" | undefined;
    shape?: "rounded" | "rectangular" | undefined;
    size?: "s" | "md" | undefined;
    clickable?: boolean | undefined;
    closeable?: boolean | undefined;
    disabled?: boolean | undefined;
    checked?: boolean | undefined;
    notificator?: boolean | undefined;
    enableNumberNotificator?: boolean | undefined;
    notificationNumber?: number | undefined;
    leftAddons?: React.ReactNode;
    rightAddons?: React.ReactNode;
    enableWhiteChip?: boolean | undefined;
    children?: React.ReactNode;
    childrenRef?: React.LegacyRef<HTMLSpanElement> | undefined;
    ariaLabel?: string | undefined;
    onClose?: ((event: React.MouseEvent<HTMLSpanElement, MouseEvent>) => void) | undefined;
    onClick?: ((event: React.MouseEvent<HTMLButtonElement, MouseEvent>, payload: {
        checked: boolean;
        name?: string | undefined;
    }) => void) | undefined;
    'data-test-id'?: string | undefined;
} & React.RefAttributes<HTMLButtonElement>>;
