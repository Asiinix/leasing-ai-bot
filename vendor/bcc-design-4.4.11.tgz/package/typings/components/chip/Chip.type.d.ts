import React, { ButtonHTMLAttributes, LegacyRef, ReactNode } from 'react';
export type NativeProps = ButtonHTMLAttributes<HTMLButtonElement>;
export type ChipProps = Omit<NativeProps, 'onClick'> & {
    /**
     * Вариант отображение Chips
     */
    variant?: 'active' | 'inactive';
    /**
     * @planned
     * Данный функционал еще не утвержден"
     */
    shape?: 'rounded' | 'rectangular';
    /**
     * Размер компонента Chips.
     */
    size?: 's' | 'md';
    /**
     * Возможность кликабельности Chips.
     */
    clickable?: boolean;
    /**
     * Возможность закрытия Chips.
     */
    closeable?: boolean;
    /**
     * Неактивное состояние Chips.
     * Состояние, при котором Chips отображается, но недоступна для действий пользователя
     */
    disabled?: boolean;
    /**
     * Состояние chips
     */
    checked?: boolean;
    /**
     * Badge нотификация
     */
    notificator?: boolean;
    /**
     * @deprecated
     * Badge нотификация с числом
     */
    enableNumberNotificator?: boolean;
    /**
     * Число для нотификации
     */
    notificationNumber?: number;
    /**
     * Слот слева
     */
    leftAddons?: ReactNode;
    /**
     * Слот справа
     */
    rightAddons?: ReactNode;
    /**
     * Возможность отображения чипа в белом цвете
     */
    enableWhiteChip?: boolean;
    /**
     * Содержимое компонента Chips
     */
    children?: React.ReactNode;
    /**
     * ref на children
     */
    childrenRef?: LegacyRef<HTMLSpanElement> | undefined;
    /**
     * Маркер доступности
     */
    ariaLabel?: string;
    /**
     * Обработчик закрытия
     */
    onClose?: (event: React.MouseEvent<HTMLSpanElement>) => void;
    /**
     * Обработчик нажатия
     */
    onClick?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>, payload: {
        checked: boolean;
        name?: string;
    }) => void;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
