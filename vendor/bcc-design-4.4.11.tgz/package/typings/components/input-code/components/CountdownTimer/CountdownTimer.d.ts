type Props = {
    interval: number;
    onResend?: () => void;
    showCountdown: boolean;
    loading?: boolean;
    preserveFooterSpace?: boolean;
    countdownText?: string;
    resendButtonText?: string;
    showSubmitButton?: boolean;
    isSubmitAvailable?: boolean;
    submitButtonText?: string;
    onSubmit?: () => void;
};
export declare const CountdownTimer: ({ interval, onResend, showCountdown, preserveFooterSpace, countdownText, resendButtonText, showSubmitButton, isSubmitAvailable, submitButtonText, onSubmit, loading, }: Props) => import("react/jsx-runtime").JSX.Element | null;
export {};
