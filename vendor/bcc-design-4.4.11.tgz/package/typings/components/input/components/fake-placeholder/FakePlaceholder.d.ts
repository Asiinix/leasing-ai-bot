import React, { RefObject } from 'react';
import { MaskOptions } from '../base-input/BaseInput.type';
type Props = {
    show?: boolean;
    value?: string;
    maskOptions?: MaskOptions;
    className?: string;
    inputRef: RefObject<HTMLInputElement>;
};
export declare const FakePlaceholder: React.MemoExoticComponent<({ value, maskOptions, className, show, inputRef }: Props) => import("react/jsx-runtime").JSX.Element | null>;
export {};
