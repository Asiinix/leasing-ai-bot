import { ChangeEvent } from 'react';
import { BaseInputProps } from './BaseInput.type';
/**
 * Функция генерирует React Event программно
 *
 * На вход получает реф на инпут и onChange коллбэк
 * @params input
 * @params onChange
 * */
export declare const generateInputEvent: (input: HTMLInputElement | null, _onChange: (event: ChangeEvent<HTMLInputElement>) => void) => void;
export declare const getInputMode: (inputModeProps: BaseInputProps['inputMode'], mask: BaseInputProps['mask']) => BaseInputProps['inputMode'];
