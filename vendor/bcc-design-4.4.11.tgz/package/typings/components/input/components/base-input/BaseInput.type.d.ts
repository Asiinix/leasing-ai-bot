import type { ChangeEvent, ElementType, HTMLAttributes, InputHTMLAttributes, MouseEvent, RefAttributes } from 'react';
import type { MaskitoOptions } from '@maskito/core';
import { FormControlProps } from '../../../form-control';
import type { BaseFormControlProps } from '../../../form-control/base-form-control';
import type { InputMaskProps } from '../mask/InputMask.type';
/** Mask types */
export type MaskOptions = MaskitoOptions & {
    placeholderStr?: string;
};
/** Values / onChange */
export type InputPayloadValue = {
    value: string;
    name: string;
};
export type InputOnChangeHandler = (event: ChangeEvent<HTMLInputElement>, payload: InputPayloadValue) => void;
/** Пропсы нативного инпута */
type NativeInputProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'size' | 'type' | 'value' | 'defaultValue' | 'onChange' | 'onClick' | 'enterKeyHint'>;
/** Пропсы FormControl */
type NativeFormControlProps = {
    fullWidth?: FormControlProps['fullWidth'];
    size?: FormControlProps['size'];
    disabled?: FormControlProps['disabled'];
    error?: FormControlProps['error'];
    success?: FormControlProps['success'];
    hint?: FormControlProps['hint'];
    label?: FormControlProps['label'];
    labelType?: FormControlProps['labelType'];
    leftAddon?: FormControlProps['leftAddon'];
    rightAddon?: FormControlProps['rightAddon'];
    preserveCaptionSpace?: FormControlProps['preserveCaptionSpace'];
    animateCaption?: FormControlProps['animateCaption'];
    _extraAddonLeft?: FormControlProps['_extraAddonLeft'];
    _extraAddonRight?: FormControlProps['_extraAddonRight'];
    _extraAddonBottom?: FormControlProps['_extraAddonBottom'];
};
export type BaseInputProps = NativeInputProps & NativeFormControlProps & {
    mask?: InputMaskProps;
    /**
     * Playwright
     */
    'data-pw'?: string;
    /**
     * Значение поля ввода
     */
    value?: string;
    /**
     * Начальное значение поля
     */
    defaultValue?: string;
    /**
     * Показывать ли счётчик символов
     */
    showLettersLimit?: boolean;
    /**
     * Максимальное количество символов
     */
    maxLength?: number;
    /**
     * Крестик для очистки поля
     */
    clear?: boolean;
    /**
     * Состояние загрузки
     */
    loading?: boolean;
    /**
     * Фокусировать ли инпут после очистки
     */
    focusAfterClear?: boolean;
    /**
     * Атрибут type
     */
    type?: 'number' | 'card' | 'email' | 'money' | 'password' | 'tel' | 'text';
    /**
     * Обработчик поля ввода
     */
    onChange?: InputOnChangeHandler;
    /**
     * Обработчик нажатия на кнопку очистки
     */
    onClear?: (event: MouseEvent<HTMLButtonElement>) => void;
    /**
     * Обработчик клика по полю
     */
    onClick?: (event: MouseEvent<HTMLDivElement>) => void;
    /**
     * Обработчик MouseDown по полю
     */
    onMouseDown?: (event: MouseEvent<HTMLDivElement>) => void;
    /**
     * Показать ли, что инпут в фокусе
     * */
    showFocus?: boolean;
    /**
     * Обработчик MouseUp по полю
     */
    onMouseUp?: (event: MouseEvent<HTMLDivElement>) => void;
    /**
     * Компонент FormControl
     */
    FormControlComponent?: ElementType<FormControlProps & RefAttributes<HTMLDivElement>>;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
    /**
     * html аттрибуты для обертки инпута
     */
    wrapperProps?: HTMLAttributes<HTMLDivElement> & BaseFormControlProps;
    _forceClear?: boolean;
    _maskOptions?: MaskOptions;
    _extraInnerAddonRight?: BaseFormControlProps['_extraInnerAddonRight'];
};
export {};
