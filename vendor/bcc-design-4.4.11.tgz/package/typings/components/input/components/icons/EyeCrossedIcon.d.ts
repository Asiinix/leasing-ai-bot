export declare const EyeCrossedIcon: () => import("react/jsx-runtime").JSX.Element;
