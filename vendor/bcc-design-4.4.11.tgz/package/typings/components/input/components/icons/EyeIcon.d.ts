export declare const EyeIcon: () => import("react/jsx-runtime").JSX.Element;
