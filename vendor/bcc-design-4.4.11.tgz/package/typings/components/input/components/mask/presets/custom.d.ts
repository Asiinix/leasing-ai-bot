import { MaskOptions } from '../../base-input/BaseInput.type';
import { CustomMaskProps } from '../InputMask.type';
export declare const getCustomPreset: ({ value, prefix, postfix, placeholder, mode, }: CustomMaskProps) => MaskOptions;
