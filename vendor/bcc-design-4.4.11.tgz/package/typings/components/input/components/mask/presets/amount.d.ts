import { MaskOptions } from '../../base-input/BaseInput.type';
import { AmountMaskProps } from '../InputMask.type';
export declare const getAmountPreset: (props: AmountMaskProps) => MaskOptions;
