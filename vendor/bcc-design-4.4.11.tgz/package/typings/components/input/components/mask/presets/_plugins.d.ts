import type { ElementState } from '@maskito/core/src/lib/types';
export declare const removeRedundantLeadingZeros: ({ value, selection }: ElementState, _: ElementState) => ElementState;
