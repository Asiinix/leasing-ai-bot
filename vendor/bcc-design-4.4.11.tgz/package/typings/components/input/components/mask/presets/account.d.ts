import { MaskOptions } from '../../base-input/BaseInput.type';
import { AccountMaskProps } from '../InputMask.type';
export declare const getAccountPreset: ({ placeholder: placeholderProp, ...props }: AccountMaskProps) => MaskOptions;
