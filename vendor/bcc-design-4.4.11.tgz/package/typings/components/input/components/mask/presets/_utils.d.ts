import { MaskitoDateMode, MaskitoTimeMode } from '@maskito/kit';
export declare const DEFAULT_DATE_RANGE_SEPARATOR = " - ";
type DefaultDateModePlaceholderMap = Record<MaskitoDateMode, string>;
export declare const defaultDateModePlaceholderMap: DefaultDateModePlaceholderMap;
type DefaultTimeModePlaceholderMap = Record<MaskitoTimeMode, string>;
export declare const defaultTimeModePlaceholderMap: DefaultTimeModePlaceholderMap;
export {};
