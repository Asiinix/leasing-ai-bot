import { MaskOptions } from '../../base-input/BaseInput.type';
import { DateMaskProps } from '../InputMask.type';
export declare const getDatePreset: (props: DateMaskProps) => MaskOptions;
