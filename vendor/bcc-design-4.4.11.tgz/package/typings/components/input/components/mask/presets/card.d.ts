import { MaskOptions } from '../../base-input/BaseInput.type';
import { CardMaskProps } from '../InputMask.type';
export declare const getCardPreset: ({ placeholder: placeholderProp, ...props }: CardMaskProps) => MaskOptions;
