import { MaskOptions } from '../../base-input/BaseInput.type';
import { DateRangeMaskProps } from '../InputMask.type';
export declare const getDateRangePreset: (props: DateRangeMaskProps) => MaskOptions;
