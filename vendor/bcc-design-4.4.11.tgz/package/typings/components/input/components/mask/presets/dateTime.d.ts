import { MaskOptions } from '../../base-input/BaseInput.type';
import { DateTimeMaskProps } from '../InputMask.type';
export declare const getDateTimePreset: (props: DateTimeMaskProps) => MaskOptions;
