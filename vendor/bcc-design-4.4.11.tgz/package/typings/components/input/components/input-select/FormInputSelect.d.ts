import { FormItemProps } from '../../../form';
import { InputSelectProps } from './InputSelect.type';
export type FormInputSelectProps = InputSelectProps & Omit<FormItemProps, 'render'> & {
    select?: InputSelectProps['select'] & {
        rules?: FormItemProps['rules'];
    };
};
export declare const FormInputSelect: (props: FormInputSelectProps) => import("react/jsx-runtime").JSX.Element;
