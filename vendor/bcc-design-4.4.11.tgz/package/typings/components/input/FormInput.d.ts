/// <reference types="react" />
import { FormItemProps } from '../form';
import { InputProps } from './Input';
export type FormInputProps = InputProps & Omit<FormItemProps, 'render'>;
export declare const FormInput: import("react").ForwardRefExoticComponent<Omit<import("./components/base-input/BaseInput.type").BaseInputProps, "FormControlComponent" | "labelType"> & {
    labelType?: "inner" | undefined;
} & Omit<FormItemProps, "render"> & import("react").RefAttributes<HTMLInputElement>>;
