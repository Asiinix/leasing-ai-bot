import React, { CSSProperties, HTMLAttributes, LegacyRef } from 'react';
export interface BreadcrumbProps {
    id: number;
    title: string;
    link: string;
}
export type NativeProps = HTMLAttributes<HTMLUListElement>;
export type BreadcrumbsProps = NativeProps & {
    /**
     * Массив объектов, содержащих информацию о хлебных крошках
     */
    breadcrumbs?: BreadcrumbProps[];
    /**
     * Размер компонента Breadcrumb
     */
    size?: 'xs' | 'sm' | 'md' | 'lg';
    /**
     * Обработчик клика по компоненту Breadcrumb
     */
    onClick?: (breadcrumb: BreadcrumbProps) => void;
    /**
     * Содержимое компонента Breadcrumb
     */
    children?: React.ReactNode;
    /**
     * ref на children
     */
    childrenRef?: LegacyRef<HTMLSpanElement> | undefined;
    /**
     * Основные стили компонента
     */
    styles?: CSSProperties;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
