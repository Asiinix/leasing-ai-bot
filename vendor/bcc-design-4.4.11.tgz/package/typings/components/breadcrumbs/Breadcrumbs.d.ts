/// <reference types="react" />
import { BreadcrumbProps } from './Breadcrumbs.type';
export declare const Breadcrumbs: import("react").ForwardRefExoticComponent<import("./Breadcrumbs.type").NativeProps & {
    breadcrumbs?: BreadcrumbProps[] | undefined;
    size?: "xs" | "sm" | "md" | "lg" | undefined;
    onClick?: ((breadcrumb: BreadcrumbProps) => void) | undefined;
    children?: import("react").ReactNode;
    childrenRef?: import("react").LegacyRef<HTMLSpanElement> | undefined;
    styles?: import("react").CSSProperties | undefined;
    'data-test-id'?: string | undefined;
} & import("react").RefAttributes<HTMLUListElement>>;
