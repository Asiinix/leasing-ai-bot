/// <reference types="react" />
export declare const Alert: import("react").ForwardRefExoticComponent<import("./Alert.type").NativeProps & {
    title?: import("react").ReactNode;
    variant?: import("./Alert.type").AlertVariant | undefined;
    buttonVariant?: "link" | "invert" | undefined;
    size?: "sm" | "md" | "lg" | undefined;
    leftAddons?: import("react").ReactNode;
    actionButton?: import("react").ReactNode;
    actionButtonText?: string | undefined;
    actionButtonHandler?: ((event: import("react").MouseEvent<import("../button/Button.type").ContainerElement, MouseEvent>) => void) | undefined;
    onClick?: ((event?: import("react").MouseEvent<Element, MouseEvent> | undefined) => void) | undefined;
    hasCloser?: boolean | undefined;
    fullWidth?: boolean | undefined;
    onClose?: ((event?: import("react").MouseEvent<HTMLButtonElement, MouseEvent> | undefined) => void) | undefined;
    visible?: boolean | undefined;
    offset?: number | undefined;
    autoCloseDelay?: number | null | undefined;
    zIndex?: number | undefined;
    disableTruncate?: boolean | undefined;
    onCloseTimeout?: (() => void) | undefined;
    onClickOutside?: ((event?: MouseEvent | undefined) => void) | undefined;
    children?: import("react").ReactNode;
    styles?: import("react").CSSProperties | undefined;
    'data-test-id'?: string | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
