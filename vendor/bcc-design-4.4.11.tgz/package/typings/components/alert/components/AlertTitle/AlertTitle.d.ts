export declare const AlertTitle: ({ currentIcon, title, onClick, disableTruncate }: {
    currentIcon: any;
    title: any;
    onClick: any;
    disableTruncate?: boolean | undefined;
}) => import("react/jsx-runtime").JSX.Element;
