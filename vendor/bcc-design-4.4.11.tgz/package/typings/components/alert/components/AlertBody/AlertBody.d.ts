export declare const AlertBody: ({ children, actionButtonText, actionButtonHandler, hasCloser, closeHandler, disableTruncate, isTitlePresent, }: {
    children: any;
    actionButtonText: any;
    actionButtonHandler: any;
    hasCloser: any;
    closeHandler: any;
    disableTruncate: any;
    isTitlePresent: any;
}) => import("react/jsx-runtime").JSX.Element;
