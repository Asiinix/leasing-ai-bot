export declare const ErrorIcon: () => import("react/jsx-runtime").JSX.Element;
