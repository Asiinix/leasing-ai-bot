export * from './DesktopAlert';
export type { DesktopAlertProps } from './DesktopAlert.type';
