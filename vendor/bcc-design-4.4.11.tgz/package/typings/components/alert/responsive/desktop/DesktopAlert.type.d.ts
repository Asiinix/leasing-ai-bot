import React, { CSSProperties, HTMLAttributes } from 'react';
import { ContainerElement } from '../../../button/Button.type';
export type AlertVariant = 'success' | 'error' | 'warning' | 'info';
export type NativeProps = HTMLAttributes<HTMLDivElement>;
export type DesktopAlertProps = NativeProps & {
    /**
     * Заголовок компонента
     */
    title?: React.ReactNode | string;
    /**
     * Вариант компонента
     */
    variant?: AlertVariant;
    /**
     * Данный вариант используется для того что бы в компоненте Snackbar кнопка отображалась как ссылка и имела стили по умолчанию
     */
    buttonVariant?: 'link' | 'invert';
    /**
     * @deprecated Это свойство устарело и будет удалено в будущих версиях. Используйте свойство `actionButtonText` и `actionButtonHandler`  вместо него.
     */
    actionButton?: React.ReactNode;
    /**
     * Текст кнопки действия
     */
    actionButtonText?: string;
    /**
     * Обработчик кнопки действия
     */
    actionButtonHandler?: (event: React.MouseEvent<ContainerElement, MouseEvent>) => void;
    /**
     * Функция действия
     */
    onClick?: (event?: React.MouseEvent) => void;
    /**
     * Управляет отображением кнопки закрытия уведомления
     */
    hasCloser?: boolean;
    /**
     * Обработчик клика по крестику
     */
    onClose?: (event?: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    /**
     * Управление видимостью компонента
     */
    visible?: boolean;
    /**
     * Время до закрытия компонента
     */
    autoCloseDelay?: number | null;
    /**
     * z-index компонента.
     * По умолчанию не задаётся — порядок наложения определяется потоком документа.
     * Указывать только если компонент нужно поднять над другими слоями,
     * значения см. в `stackingOrder`
     */
    zIndex?: number;
    /**
     * Флаг, указывающий на то, что компонент должен занимать всю ширину родителя
     */
    fullWidth?: boolean;
    /**
     * Обработчик события истечения времени до закрытия компонента
     */
    onCloseTimeout?: () => void;
    /**
     * Обработчик клика вне компонента
     */
    onClickOutside?: (event?: MouseEvent) => void;
    /**
     * Отключает транкейт текста
     */
    disableTruncate?: boolean;
    /**
     * Содержимое компонента BadgeProps
     */
    children?: React.ReactNode;
    /**
     * Основные стили компонента
     */
    styles?: CSSProperties;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
