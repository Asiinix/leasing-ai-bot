/// <reference types="react" />
export declare const DesktopAlert: import("react").ForwardRefExoticComponent<import("./DesktopAlert.type").NativeProps & {
    title?: import("react").ReactNode;
    variant?: import("./DesktopAlert.type").AlertVariant | undefined;
    buttonVariant?: "link" | "invert" | undefined;
    actionButton?: import("react").ReactNode;
    actionButtonText?: string | undefined;
    actionButtonHandler?: ((event: import("react").MouseEvent<import("../../../button/Button.type").ContainerElement, MouseEvent>) => void) | undefined;
    onClick?: ((event?: import("react").MouseEvent<Element, MouseEvent> | undefined) => void) | undefined;
    hasCloser?: boolean | undefined;
    onClose?: ((event?: import("react").MouseEvent<HTMLButtonElement, MouseEvent> | undefined) => void) | undefined;
    visible?: boolean | undefined;
    autoCloseDelay?: number | null | undefined;
    zIndex?: number | undefined;
    fullWidth?: boolean | undefined;
    onCloseTimeout?: (() => void) | undefined;
    onClickOutside?: ((event?: MouseEvent | undefined) => void) | undefined;
    disableTruncate?: boolean | undefined;
    children?: import("react").ReactNode;
    styles?: import("react").CSSProperties | undefined;
    'data-test-id'?: string | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
