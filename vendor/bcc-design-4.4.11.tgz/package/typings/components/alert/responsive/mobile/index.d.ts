export * from './MobileAlert.scss';
export type { MobileAlertProps } from './MobileAlert.type';
