import React, { ChangeEvent, CSSProperties, HTMLAttributes, LegacyRef } from 'react';
import { AlertProps } from '../alert/Alert.type';
import { CheckboxValuePayload } from '../checkbox/Checkbox.type';
import { ChipProps } from '../chip/Chip.type';
export declare enum PositionTypeEnum {
    Start = "startPosition",
    Center = "centerPosition",
    End = "endPosition"
}
export declare enum ListStateEnum {
    Default = "default",
    Loading = "loading",
    Error = "error",
    NotFound = "not-found"
}
export interface ListProps {
    title?: string;
    desc?: string;
    addon?: React.ReactNode;
    addonType?: PositionTypeEnum;
    disabled?: boolean;
    selected?: boolean;
    checkbox?: boolean;
    checked?: boolean;
    label?: string;
    name?: string;
}
export type NativeProps = HTMLAttributes<HTMLUListElement>;
export type DropdownMenuProps = NativeProps & {
    /**
     * Состояние DropDownMenu
     */
    isOpen?: boolean;
    /**
     * Идентификатор элемента к которому привязывается DropDownMenu
     */
    targetId?: string;
    /**
     * Позиция привязки к таргет элементу - начало / конец (PositionTypeEnum)
     */
    targetPosition?: 'startPosition' | 'centerPosition' | 'endPosition';
    /**
     * Состояние контента DropDownMenu
     */
    listState?: ListStateEnum | string;
    /**
     * Активирует поиск по списку и показывает поле ввода
     */
    enableSearch?: boolean;
    /**
     * Плейсхолдер поля поиска (по умолчанию 'Поиск')
     */
    searchPlaceholder?: string;
    /**
     * Состояние текущего поиска
     */
    searchState?: string;
    /**
     * Изменяет текущий список для использования чекбоксов
     */
    enableCheckboxes?: boolean;
    /**
     * Изменяет текущий список для использования радио-кнопок
     */
    enableRadio?: boolean;
    /**
     * Показывает кнопку удаления справа от каждого элемента списка
     */
    enableDelete?: boolean;
    /**
     * Показывает кнопки сохранения и отмены
     */
    showFooterButtons?: boolean;
    /**
     * Тайтл кнопки сохранения в футере
     */
    footerSaveButtonTitle?: string;
    /**
     * Тайтл кнопки отмены в футере
     */
    footerCancelButtonTitle?: string;
    /**
     * Тайтл кнопки отмены
     */
    cancelButtonTitle?: boolean;
    /**
     * Массив элементов - Chips
     */
    chips?: ChipProps[];
    /**
     * Обработчик элемента по клику на отдельный элемент Chip
     */
    onChipItemClick?: (chip: ChipProps) => void;
    /**
     * Список данных - ListProps
     */
    list?: ListProps[];
    /**
     * Дополнительный контент в DropDownMenu
     */
    customContent?: string | React.ReactNode;
    /**
     * Обработчик поиска
     */
    onSearchItem?: (value: string) => void;
    /**
     * Обработчик элемента по клику на отдельный элемент списка
     */
    onListItemClick?: (listItem: ListProps) => void;
    /**
     * Обработчик клика на правый аддон элемента списка
     */
    onRightAddonClick?: (listItem: ListProps) => void;
    /**
     * Обработчик элемента по клику на отдельный элемент списка с чекбоксом
     */
    onCheckboxItemClick?: (event: ChangeEvent<HTMLInputElement>, payload: CheckboxValuePayload) => void;
    /**
     * Обработчик выбора всех чекбоксов
     */
    onCheckboxSelectAll?: () => void;
    /**
     * Обработчик сохранения данных в футере
     */
    onFooterSave?: () => void;
    /**
     * Обработчик отмены данных в футере
     */
    onFooterCancel?: () => void;
    /**
     * Обработчик клика вне компонента DropDownMenu
     */
    onClickOutside?: () => void;
    /**
     * Свойства алерта, их наличие активирует Alert в конце списка с возможностью полной кастомизации
     */
    alertProps?: AlertProps;
    /**
     * Минимальная ширина DropDownMenu - '260px' по умолчанию
     */
    minWidth?: string;
    /**
     * Максимальная ширина DropDownMenu - '260px' по умолчанию
     */
    maxWidth?: string;
    /**
     * Содержимое компонента DropDownMenu
     */
    children?: React.ReactNode;
    /**
     * ref на children
     */
    childrenRef?: LegacyRef<HTMLSpanElement> | undefined;
    /**
     * Основные стили компонента
     */
    styles?: CSSProperties;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
