export declare const DeleteIcon: () => import("react/jsx-runtime").JSX.Element;
