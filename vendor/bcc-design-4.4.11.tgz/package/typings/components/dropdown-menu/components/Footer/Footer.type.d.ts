import { AlertProps } from '../../../alert';
export interface FooterProps {
    showFooterButtons?: boolean;
    saveButtonTitle?: string;
    cancelButtonTitle?: string;
    alertProps?: AlertProps | null;
    onFooterSave?: () => void;
    onFooterCancel?: () => void;
}
