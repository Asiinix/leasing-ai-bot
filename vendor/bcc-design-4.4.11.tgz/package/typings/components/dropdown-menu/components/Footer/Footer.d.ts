/// <reference types="react" />
import { FooterProps } from './Footer.type';
export declare const Footer: React.FC<FooterProps>;
