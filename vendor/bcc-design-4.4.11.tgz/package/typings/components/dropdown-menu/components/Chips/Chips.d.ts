/// <reference types="react" />
import { ChipItemProps } from './Chips.type';
export declare const Chips: React.FC<ChipItemProps>;
