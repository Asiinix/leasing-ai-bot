import { ChipProps } from '../../../chip';
export interface ChipItemProps {
    chips: ChipProps[];
    onChipItemClick?: (chip: ChipProps) => void;
}
