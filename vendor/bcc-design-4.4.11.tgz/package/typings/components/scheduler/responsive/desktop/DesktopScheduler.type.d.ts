import { SchedulerProps } from '../../Scheduler.type';
export interface DesktopSchedulerProps extends SchedulerProps {
}
