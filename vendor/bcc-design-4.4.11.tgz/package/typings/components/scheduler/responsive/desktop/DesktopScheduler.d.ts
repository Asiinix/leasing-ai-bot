/// <reference types="react" />
import { SchedulerProps } from '../../Scheduler.type';
export declare const DesktopScheduler: import("react").ForwardRefExoticComponent<SchedulerProps & import("react").RefAttributes<HTMLDivElement>>;
