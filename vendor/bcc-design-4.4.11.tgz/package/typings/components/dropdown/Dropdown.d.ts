import React from 'react';
import { DropdownProps } from './Dropdown.type';
export declare const Dropdown: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<DropdownProps, "ref"> & React.RefAttributes<HTMLElement>>>;
