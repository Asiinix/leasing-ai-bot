import React, { CSSProperties } from 'react';
import { HTMLAttrsOf } from '../../utilities/types/utility-types';
export type DropdownPositionType = 'start' | 'center' | 'end';
export type DropdownPlacementType = 'top' | 'bottom' | 'left' | 'right';
export type DropdownProps = Omit<HTMLAttrsOf<any>, 'content' | 'className' | 'style'> & {
    /**
     * Идентификатор элемента к которому привязывается Dropdown
     */
    targetId?: string;
    /**
     * Ref Html элемента. Если прокинут, то будет использоваться anchor
     */
    anchor?: HTMLElement;
    /**
     * Содержимое компонента Dropdown
     */
    content?: React.ReactNode;
    /**
     * Anchor Element
     */
    children?: React.ReactNode;
    /**
     * Открыт ли dropdown
     */
    isOpen?: boolean;
    /**
     * Позиция привязки к таргет элементу - начало / середина / конец (DropdownPositionType)
     */
    position?: DropdownPositionType;
    /**
     * Позиционирование дропдауна - верх / низ / слева / справа (DropdownPlacementType)
     */
    placement?: DropdownPlacementType;
    /**
     * Автоматически изменять placement если недостаточно места
     * @default true
     */
    autoFlip?: boolean;
    /**
     * Порядок fallback placement при autoFlip
     * @default Зависит от изначального placement
     */
    fallbackPlacements?: DropdownPlacementType[];
    /**
     * Дополнительная высота, которую autoFlip учитывает при выборе placement.
     * Полезно, когда содержимое Dropdown может увеличиться после открытия.
     * @default 0
     */
    autoFlipReservedHeight?: number;
    /**
     * Позиционирует dropdown относительно viewport (как position: fixed)
     */
    isFixed?: boolean;
    /**
     * Отступ сверху
     */
    offset?: number;
    /**
     * Отступ слева
     */
    offsetLeft?: number;
    /**
     * Отступ справа
     */
    offsetRight?: number;
    /**
     * Матчить ли длину с anchor
     */
    matchAnchorWidth?: boolean;
    /**
     * Обработчик клика вне компонента Dropdown
     */
    onClickOutside?: () => void;
    /**
     * Дополнительные зависимости для перерасчета позиции дропдауна
     */
    triggerDeps?: unknown;
    /** id родителя */
    parentId?: string;
    /**
     * Имя класса
     */
    className?: string;
    /**
     * Доп зависимости для перерасчета позиции дропдауна
     */
    extraDeps?: any[];
    /**
     * z-index для компонента
     */
    zIndex?: CSSProperties['zIndex'];
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
    /**
     * Playwright test identifier
     */
    'data-pw'?: string;
    /**
     * @deprecated
     * */
    dropdownCssPositionStyles?: DropdownCssPositionStylesType;
    /**
     * @deprecated
     * Основные стили компонента
     */
    style?: CSSProperties;
    /**
     * @deprecated
     * Использовать ли портал
     */
    usePortal?: boolean;
    /**
     * @deprecated
     * Контейнер для портала
     */
    portalContainer?: Element | DocumentFragment;
    /**
     * @deprecated
     * Принудительно отрендерить компонент, даже когда dropdown закрыт
     */
    forceRender?: boolean;
    /**
     * @deprecated
     * Отрендерить ли dropdown в div контейнере с position: relative
     */
    withRelativeContainer?: boolean;
};
type DropdownCssPositionStylesType = {
    position?: 'absolute' | 'fixed';
    top?: CSSProperties['top'];
    bottom?: CSSProperties['bottom'];
    left?: CSSProperties['left'];
    right?: CSSProperties['right'];
    transform?: CSSProperties['transform'];
};
export {};
