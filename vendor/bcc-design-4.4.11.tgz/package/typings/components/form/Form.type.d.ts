import React from 'react';
import { ControllerProps, FieldValues, UseFormProps } from 'react-hook-form';
import { UseFormReturn, UseFormStateReturn } from 'react-hook-form/dist/types';
import { ControllerFieldState, ControllerRenderProps } from 'react-hook-form/dist/types/controller';
export type FormProps<T extends FieldValues = FieldValues> = {
    handleError?: (error: any) => void;
    onSubmit: (data: T) => void;
    children?: React.ReactNode;
    className?: string;
    style?: React.CSSProperties;
    form?: UseFormReturn<T>;
    formOptions?: UseFormProps<T>;
    'data-pw'?: string;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
};
/**
 * Переписываем тип функции render, чтобы можно было прокидывать null
 * Далее в компоненте уже обрабатываем кейс, когда приходит null
 * Нужно для того чтобы, иметь возможность отрендерить компонент если он используется вне контекста Form
 *
 * control - убираем т.к. будем сами его прокидывать в компоненте Form.Item
 * name - убираем т.к. name = string, а нужно string | undefined, иначе не будет работать без name
 * render - перезаписываем, чтобы мы могли прокинуть null, если используется вне компонента Form
 * */
export type FormItemProps = Omit<ControllerProps, 'control' | 'render' | 'name'> & {
    name?: string;
    render: (renderProps: {
        /**
         * onChange
         * onBlur
         * value
         * disabled
         * name
         * ref
         * */
        field: ControllerRenderProps;
        /**
         * https://react-hook-form.com/ts#UseControllerProps
         * */
        fieldState: ControllerFieldState;
        /**
         * isDirty
         * isLoading
         * isSubmitted
         * isSubmitSuccessful
         * isSubmitting
         * isValidating
         * isValid
         * disabled
         * submitCount
         * defaultValues
         * dirtyFields
         * touchedFields
         * validatingFields
         * errors
         * */
        formState: UseFormStateReturn<any>;
    } | null) => React.ReactElement;
};
/**
 * Пропсы компонента который оборачивают в HOC withForm
 * расширяются типом Omit<FormProps, 'children'>
 * */
export type WithInjectedFormProps<Props> = Props & Omit<FormProps, 'children'>;
