import { FieldValues, useFieldArray, useForm, useFormState } from 'react-hook-form';
import { FormProps } from './Form.type';
export declare const Form: {
    <T extends FieldValues = FieldValues>({ onSubmit, handleError, form, formOptions, className, children, style, "data-pw": dataPw, "data-test-id": dataTestId, }: FormProps<T>): import("react/jsx-runtime").JSX.Element;
    Item: (props: import("./Form.type").FormItemProps) => import("react/jsx-runtime").JSX.Element;
    useFormContext: <TFieldValues extends FieldValues, TContext = any, TTransformedValues = TFieldValues>() => import("react-hook-form").UseFormReturn<TFieldValues, TContext, TTransformedValues>;
    useForm: typeof useForm;
    useFormState: typeof useFormState;
    useFieldArray: typeof useFieldArray;
};
