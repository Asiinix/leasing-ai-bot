/// <reference types="react" />
import { PaginationProps } from '../../Pagination.type';
export declare const DesktopPagination: import("react").ForwardRefExoticComponent<PaginationProps & import("react").RefAttributes<HTMLDivElement>>;
