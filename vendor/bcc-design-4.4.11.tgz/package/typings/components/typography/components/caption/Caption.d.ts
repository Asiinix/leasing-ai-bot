import React, { HTMLAttributes } from 'react';
import { TextSkeletonProps } from '../../type';
type NativeProps = HTMLAttributes<HTMLSpanElement>;
export type CaptionProps = Omit<NativeProps, 'color'> & {
    /**
     * HTML тег
     */
    tag?: 'span' | 'div' | 'p';
    /**
     * Толщина шрифта
     */
    weight?: 'regular' | 'medium' | 'semibold';
    /**
     * [Вариант начертания]
     */
    view?: 'medium' | 'small' | 'large';
    /**
     * Делает цифры моноширинными
     */
    monospaceNumbers?: boolean;
    /**
     * Декорация текста
     */
    decoration?: 'underline' | 'line-through';
    /**
     * Css-класс для стилизации (native prop)
     */
    className?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Playwright test identifier
     */
    'data-pw'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
    /**
     * Количество строк
     */
    rowLimit?: '1' | '2' | '3' | 'none';
    /**
     * Цвет текста
     */
    color?: 'primary' | 'secondary';
    /**
     * Показать скелетон
     */
    showSkeleton?: boolean;
    /**
     * Пропы для скелетона
     */
    skeletonProps?: TextSkeletonProps;
};
type CaptionElementType = HTMLSpanElement | HTMLDivElement;
export declare const Caption: React.ForwardRefExoticComponent<Omit<NativeProps, "color"> & {
    /**
     * HTML тег
     */
    tag?: "div" | "p" | "span" | undefined;
    /**
     * Толщина шрифта
     */
    weight?: "medium" | "regular" | "semibold" | undefined;
    /**
     * [Вариант начертания]
     */
    view?: "small" | "medium" | "large" | undefined;
    /**
     * Делает цифры моноширинными
     */
    monospaceNumbers?: boolean | undefined;
    /**
     * Декорация текста
     */
    decoration?: "line-through" | "underline" | undefined;
    /**
     * Css-класс для стилизации (native prop)
     */
    className?: string | undefined;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string | undefined;
    /**
     * Playwright test identifier
     */
    'data-pw'?: string | undefined;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
    /**
     * Количество строк
     */
    rowLimit?: "1" | "2" | "3" | "none" | undefined;
    /**
     * Цвет текста
     */
    color?: "primary" | "secondary" | undefined;
    /**
     * Показать скелетон
     */
    showSkeleton?: boolean | undefined;
    /**
     * Пропы для скелетона
     */
    skeletonProps?: TextSkeletonProps | undefined;
} & React.RefAttributes<CaptionElementType>>;
export {};
