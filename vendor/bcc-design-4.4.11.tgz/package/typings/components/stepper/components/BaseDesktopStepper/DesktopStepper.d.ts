/// <reference types="react" />
import { StepperProps } from '../../Stepper.type';
export declare const DesktopStepper: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<StepperProps & import("react").RefAttributes<HTMLDivElement>>>;
