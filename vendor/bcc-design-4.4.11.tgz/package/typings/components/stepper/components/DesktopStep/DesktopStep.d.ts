import { StepProps } from '../../Stepper.type';
export declare const DesktopStep: ({ point, index, orientation, currentStep, length, status, disablePadding, fullWidth, contentHeightRef, syncedHeight, }: StepProps) => import("react/jsx-runtime").JSX.Element;
