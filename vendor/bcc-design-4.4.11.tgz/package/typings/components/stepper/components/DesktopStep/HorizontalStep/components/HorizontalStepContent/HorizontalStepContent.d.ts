import { RefObject } from 'react';
import { StepItem } from '../../../../../Stepper.type';
interface HorizontalStepContentProps {
    point: StepItem;
    fullWidth?: boolean;
    isNotActiveStep: boolean;
    status: string;
    shouldApplyDynamicCentering: boolean;
    isLastItem: boolean;
    contentMarginLeft: number;
    contentRef: RefObject<HTMLDivElement>;
    contentHeightRef?: RefObject<HTMLDivElement>;
    syncedHeight?: number;
}
export declare function HorizontalStepContent({ point, fullWidth, isNotActiveStep, status, shouldApplyDynamicCentering, isLastItem, contentMarginLeft, contentRef, contentHeightRef, syncedHeight, }: HorizontalStepContentProps): import("react/jsx-runtime").JSX.Element;
export {};
