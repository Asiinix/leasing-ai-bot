import React, { RefObject } from 'react';
interface HorizontalStepWrapperProps {
    fullWidth?: boolean;
    children: React.ReactNode;
    containerRef: RefObject<HTMLDivElement>;
    shouldApplyDynamicCentering: boolean;
    isFirstItem: boolean;
    marginLeft: number;
    isLastItem: boolean;
    isCurrentStepActive: boolean;
    index: number;
    currentStep: number;
    status: string;
}
export declare function HorizontalStepWrapper({ fullWidth, children, containerRef, shouldApplyDynamicCentering, isFirstItem, marginLeft, isLastItem, isCurrentStepActive, index, currentStep, status, }: HorizontalStepWrapperProps): import("react/jsx-runtime").JSX.Element;
export {};
