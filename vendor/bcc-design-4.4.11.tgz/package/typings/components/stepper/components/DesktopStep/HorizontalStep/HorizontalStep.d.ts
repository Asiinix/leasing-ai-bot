import { HorizontalStepParams } from '../../../Stepper.type';
export declare function HorizontalStep({ point, isNotActiveStep, status, isFirstItem, isMiddleItem, isLastItem, isCurrentStepActive, index, currentStep, fullWidth, totalSteps, contentHeightRef, syncedHeight, }: HorizontalStepParams): import("react/jsx-runtime").JSX.Element;
