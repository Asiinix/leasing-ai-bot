export declare const AlertIcon: () => import("react/jsx-runtime").JSX.Element;
