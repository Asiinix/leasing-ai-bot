export declare const CancelIcon: () => import("react/jsx-runtime").JSX.Element;
