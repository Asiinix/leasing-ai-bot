import { Header, Table } from '@tanstack/react-table';
import { ColumnV2, TableStructureV2 } from '../TableV2.type';
export declare const getHeaderCellByType: (header: Header<TableStructureV2, unknown>, column: ColumnV2, table: Table<TableStructureV2>) => any;
