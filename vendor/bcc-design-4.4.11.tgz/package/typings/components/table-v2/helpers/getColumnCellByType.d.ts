import { Row, Table } from '@tanstack/react-table';
import { ColumnV2, TableStructureV2 } from '../TableV2.type';
export declare const getColumnCellByType: (column: ColumnV2, row: Row<TableStructureV2>, table: Table<TableStructureV2>) => any;
