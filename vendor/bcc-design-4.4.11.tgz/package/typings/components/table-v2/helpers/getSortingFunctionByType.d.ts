import { ColumnV2 } from '../TableV2.type';
export declare const getSortingFunctionByType: (column: ColumnV2) => any;
