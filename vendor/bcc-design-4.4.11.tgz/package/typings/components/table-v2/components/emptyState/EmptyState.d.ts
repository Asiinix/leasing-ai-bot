export declare const EmptyState: ({ resetFilters, customEmptyContent, table, columns }: {
    resetFilters: any;
    customEmptyContent: any;
    table: any;
    columns: any;
}) => import("react/jsx-runtime").JSX.Element;
export declare const EmptyStateTBody: ({ resetFilters, customEmptyContent, colsCount, emptyTitle, emptyDescription, resetFilterButtonText, }: {
    resetFilters: any;
    customEmptyContent: any;
    colsCount: any;
    emptyTitle?: string | undefined;
    emptyDescription?: string | undefined;
    resetFilterButtonText?: string | undefined;
}) => import("react/jsx-runtime").JSX.Element;
