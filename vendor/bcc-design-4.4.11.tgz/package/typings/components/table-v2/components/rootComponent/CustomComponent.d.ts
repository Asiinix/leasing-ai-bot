export declare const CustomComponent: (props: any) => import("react/jsx-runtime").JSX.Element;
