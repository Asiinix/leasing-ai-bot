export declare const DragHandleCell: ({ rowId }: {
    rowId: string;
}) => import("react/jsx-runtime").JSX.Element;
