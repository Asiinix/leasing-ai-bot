import { Table } from '@tanstack/react-table';
import { ColumnV2, TableStructureV2 } from '../../../../../table-v2/TableV2.type';
export interface CheckboxCellProps {
    table: Table<TableStructureV2>;
    column: ColumnV2;
}
