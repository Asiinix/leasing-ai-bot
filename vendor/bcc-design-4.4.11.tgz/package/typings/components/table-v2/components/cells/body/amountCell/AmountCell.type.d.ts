import { TooltipProps } from '../../../../../tooltip';
export interface AmountCellProps {
    amount?: number | null;
    currency?: string;
    tooltipProps?: TooltipProps;
}
