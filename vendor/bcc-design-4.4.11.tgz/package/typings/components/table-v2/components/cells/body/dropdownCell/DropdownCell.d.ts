export declare const DropdownCell: ({ id, items, table }: {
    id: any;
    items: any;
    table: any;
}) => import("react/jsx-runtime").JSX.Element;
