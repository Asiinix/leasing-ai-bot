import { Table } from '@tanstack/react-table';
import { TableStructureV2 } from '../../../../../table-v2/TableV2.type';
export interface DropdownItem {
    title: string;
    desc?: string;
    onClick?: () => void;
}
export interface DropdownCellProps {
    id: string;
    items: DropdownItem[];
    table: Table<TableStructureV2>;
}
