/// <reference types="react" />
import { CheckboxCellProps } from './CheckboxCell.type';
export declare const CheckboxCell: React.FC<CheckboxCellProps>;
