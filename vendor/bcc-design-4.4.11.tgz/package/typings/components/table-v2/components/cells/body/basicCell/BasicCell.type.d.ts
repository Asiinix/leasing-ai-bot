/// <reference types="react" />
import { TagProps } from '../../../../../tag';
import { TooltipProps } from '../../../../../tooltip';
export interface BasicCellProps {
    title?: string;
    subheading?: string;
    description?: string;
    addon?: React.ReactNode;
    tooltipProps?: TooltipProps;
    tagProps?: TagProps;
    disabled?: boolean;
}
