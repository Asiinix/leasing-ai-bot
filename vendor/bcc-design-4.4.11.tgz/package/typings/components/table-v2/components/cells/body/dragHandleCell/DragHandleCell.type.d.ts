export interface DragHandleCellProps {
    rowId: string;
}
