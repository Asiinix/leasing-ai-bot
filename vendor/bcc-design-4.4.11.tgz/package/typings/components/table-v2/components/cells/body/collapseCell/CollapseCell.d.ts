import React from 'react';
import { CollapseCellProps } from './CollapseCell.type';
export declare const CollapseCell: React.FC<CollapseCellProps>;
