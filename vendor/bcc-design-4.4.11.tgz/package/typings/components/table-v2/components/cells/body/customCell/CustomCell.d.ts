import React from 'react';
interface CustomCellProps {
    component: React.ReactElement;
    table: any;
    row: any;
    rowId: string;
    accessorKey: string;
}
export declare const CustomCell: React.NamedExoticComponent<CustomCellProps>;
export {};
