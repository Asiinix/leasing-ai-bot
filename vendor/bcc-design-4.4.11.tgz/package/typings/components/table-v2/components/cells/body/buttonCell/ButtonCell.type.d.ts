/// <reference types="react" />
import { DropdownItem } from '../dropdownCell/DropdownCell.type';
export type ButtonType = 'button' | 'icon' | 'compact';
export interface ButtonCellProps {
    children?: string | React.ReactNode;
    onClick?: () => void;
    disabled?: boolean;
    buttonType?: ButtonType;
    icon?: React.ReactNode;
    dropdownItems?: DropdownItem[];
    onDropdownItemClick?: (item: unknown) => void;
    cellId?: string;
}
