/// <reference types="react" />
import { ButtonCellProps } from './ButtonCell.type';
export declare const ButtonCell: React.FC<ButtonCellProps>;
