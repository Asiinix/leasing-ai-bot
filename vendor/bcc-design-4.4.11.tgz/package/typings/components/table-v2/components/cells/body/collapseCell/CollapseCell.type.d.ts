import { Row } from '@tanstack/react-table';
import { TableStructureV2 } from '../../../../../table-v2/TableV2.type';
export interface CollapseCellProps {
    row: Row<TableStructureV2>;
}
