import React from 'react';
import { ControlCellProps } from './ControlCell.type';
export declare const ControlCell: React.FC<ControlCellProps>;
