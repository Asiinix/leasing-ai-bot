/// <reference types="react" />
import { AmountCellProps } from './AmountCell.type';
export declare const AmountCell: React.FC<AmountCellProps>;
