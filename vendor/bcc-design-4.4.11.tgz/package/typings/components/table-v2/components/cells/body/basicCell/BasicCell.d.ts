/// <reference types="react" />
import { BasicCellProps } from './BasicCell.type';
export declare const BasicCell: React.FC<BasicCellProps>;
