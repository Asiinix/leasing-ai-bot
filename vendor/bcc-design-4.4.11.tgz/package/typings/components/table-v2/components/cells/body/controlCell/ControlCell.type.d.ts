import { Row, Table } from '@tanstack/react-table';
import { TableStructureV2 } from '../../../../../table-v2/TableV2.type';
export type ControlType = 'checkbox' | 'switch' | 'settings';
export interface ControlCellProps {
    controlType: ControlType;
    table: Table<TableStructureV2>;
    row: Row<TableStructureV2>;
    accessorKey: string;
    column: {
        id: string;
    };
}
