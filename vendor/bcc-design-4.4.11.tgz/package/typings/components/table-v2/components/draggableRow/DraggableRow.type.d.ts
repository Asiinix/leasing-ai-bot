import { CSSProperties, HTMLAttributes } from 'react';
import { Row, Table } from '@tanstack/react-table';
export interface DraggableRowProps extends HTMLAttributes<HTMLTableRowElement> {
    row: Row<any>;
    table: Table<any>;
    children: React.ReactNode;
    className?: string;
    style?: CSSProperties;
}
