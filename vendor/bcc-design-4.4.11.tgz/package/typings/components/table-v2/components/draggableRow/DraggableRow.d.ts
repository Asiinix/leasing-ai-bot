import React from 'react';
import { Row } from '@tanstack/react-table';
import { ColumnV2 } from '../../../table-v2/TableV2.type';
interface DraggableRowProps {
    row: Row<any>;
    columns?: ColumnV2[];
    onRowClick?: (row: any) => void;
    rowSelectionState?: Record<string, boolean>;
}
export declare const DraggableRow: React.NamedExoticComponent<DraggableRowProps>;
export {};
