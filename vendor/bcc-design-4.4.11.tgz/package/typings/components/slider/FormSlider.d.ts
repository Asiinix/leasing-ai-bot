import React from 'react';
import { SliderRef } from 'rc-slider';
import { FormItemProps } from '../form';
import { SliderProps } from './Slider.type';
export type FormSliderProps = SliderProps & Omit<FormItemProps, 'render'>;
export declare const FormSlider: React.ForwardRefExoticComponent<SliderProps & Omit<FormItemProps, "render"> & React.RefAttributes<SliderRef>>;
