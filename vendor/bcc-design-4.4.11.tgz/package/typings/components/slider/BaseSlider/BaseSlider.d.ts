import React from 'react';
import type { SliderProps, SliderRef } from 'rc-slider';
import type { StateModifiers } from '../Slider.type';
export declare const BaseSlider: React.ForwardRefExoticComponent<{
    stateModifiers: StateModifiers;
} & Omit<SliderProps<number | number[]>, "className" | "keyboard" | "classNames" | "prefixCls" | "pushable"> & React.RefAttributes<SliderRef>>;
