import React, { CSSProperties } from 'react';
export type CardProps = {
    /**
     * Можно передать валидный ReactNode либо текст
     */
    children: React.ReactNode;
    /**
     * Размеры, которые влияют на padding, border-radius
     */
    size?: 's' | 'm';
    /**
     * Типы, которые определяют background, box-shadow
     */
    type?: 'primary' | 'secondary';
    /**
     * Ширина карточки
     */
    width?: CSSProperties['width'];
    /**
     * Максимальная ширина карточки
     */
    maxWidth?: CSSProperties['width'];
    /**
     * Радиус скругления углов
     */
    borderRadius?: CSSProperties['borderRadius'];
    /**
     * Отключить тень
     */
    disableShadow?: boolean;
    /**
     * Высота карточки
     */
    height?: CSSProperties['height'];
    /**
     * Автоматически центрировать по горизонтали, относительно родительского элемента
     */
    autoCenter?: boolean;
    /**
     * Обработчик события нажатия на карточку
     */
    onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
    /**
     * Кастомные стили
     */
    style?: CSSProperties;
    /**
     * Имя класса
     */
    className?: string;
    /**
     * Кастомные внутренние отступы
     */
    padding?: CSSProperties['padding'];
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
