import { CardProps } from './Card.type';
export declare const Card: ({ children, size, type, width, height, maxWidth, autoCenter, disableShadow, borderRadius, padding, onClick, style, className, "data-test-id": dataTestId, }: CardProps) => import("react/jsx-runtime").JSX.Element;
