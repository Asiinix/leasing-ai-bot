import React from 'react';
import { FormItemProps } from '../form';
import type { YearPickerProps } from './YearPicker.type';
export type FormYearPickerProps = YearPickerProps & Omit<FormItemProps, 'render'>;
export declare const FormYearPicker: React.ForwardRefExoticComponent<{
    minDate: string | import("../../utilities/types/utility-types").Nullable<Date>;
    maxDate: string | import("../../utilities/types/utility-types").Nullable<Date>;
} & {
    position?: import("../dropdown").DropdownPositionType | undefined;
    placement?: import("../dropdown/Dropdown.type").DropdownPlacementType | undefined;
} & {
    id?: string | undefined;
    name?: string | undefined;
    onFocus?: React.FocusEventHandler<HTMLInputElement> | undefined;
    onBlur?: React.FocusEventHandler<HTMLInputElement> | undefined;
    onClick?: ((event: React.MouseEvent<HTMLDivElement, MouseEvent>) => void) | undefined;
    error?: React.ReactNode;
    size?: "sm" | "md" | "lg" | undefined;
    loading?: boolean | undefined;
    disabled?: boolean | undefined;
    label?: React.ReactNode;
    clear?: boolean | undefined;
    fullWidth?: boolean | undefined;
    'data-pw'?: string | undefined;
    readOnly?: boolean | undefined;
    hint?: React.ReactNode;
    preserveCaptionSpace?: boolean | undefined;
    animateCaption?: boolean | undefined;
    labelType?: "inner" | undefined;
    onClear?: ((event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void) | undefined;
    leftAddon?: React.ReactNode;
    focusAfterClear?: boolean | undefined;
} & {
    onOpen?: (() => void) | undefined;
    onClose?: (() => void) | undefined;
    value?: import("./YearPicker.type").YearPickerValue | undefined;
    onChange?: import("./YearPicker.type").YearPickerChangeHandler | undefined;
    enableFullRangeOnly?: boolean | undefined;
    closeAfterSelect?: boolean | undefined;
    withFooter?: boolean | undefined;
    isRange?: boolean | undefined;
    footerCancelText?: string | undefined;
    footerSubmitText?: string | undefined;
    'data-test-id'?: string | undefined;
} & Omit<FormItemProps, "render"> & React.RefAttributes<HTMLInputElement>>;
