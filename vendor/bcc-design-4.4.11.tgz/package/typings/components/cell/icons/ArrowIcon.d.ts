export declare const ArrowIcon: () => import("react/jsx-runtime").JSX.Element;
