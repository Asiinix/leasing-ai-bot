export declare const DragCheckmarkIcon: () => import("react/jsx-runtime").JSX.Element;
