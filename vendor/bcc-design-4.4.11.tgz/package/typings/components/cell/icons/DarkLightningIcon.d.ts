export declare const DarkLightningIcon: () => import("react/jsx-runtime").JSX.Element;
