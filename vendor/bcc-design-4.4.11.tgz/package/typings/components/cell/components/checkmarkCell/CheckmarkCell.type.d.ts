import { HTMLAttributes } from 'react';
import { PercentProps } from '../../../layout/label/components/percent';
import { StatusProps } from '../../../layout/label/components/status';
import { TagProps } from '../../../tag';
import { TooltipProps } from '../../../tooltip';
type NativeProps = HTMLAttributes<HTMLHeadingElement>;
export type CheckmarkCellProps = NativeProps & {
    /**
     * Иконка слева от заголовка
     */
    addon?: React.ReactNode;
    /**
     * Скрыть addon (иконку слева от заголовка)
     */
    hideAddon?: boolean;
    /**
     * Заголовок категории
     */
    title?: string;
    /**
     * Флаг активности значка checkmark
     */
    enableCheckmark?: boolean;
    /**
     * Описание категории
     */
    description?: string;
    /**
     * Подописание категории
     */
    subDescription?: string;
    /**
     * Позиция описания
     */
    descPosition?: 'row' | 'column';
    /**
     * Props для статуса
     */
    labelStatusProps?: StatusProps;
    /**
     * Props для процента
     */
    labelPercentProps?: PercentProps;
    /**
     * Props для тега
     */
    tagProps?: TagProps;
    /**
     * Props для тултипа
     */
    tooltipProps?: Omit<TooltipProps, 'children'>;
    /**
     * Флаг активности категории
     */
    disabled?: boolean;
    /**
     * Тайтл для значения
     */
    valueTitle?: string;
    /**
     * Позиция значения
     */
    valuePosition?: 'start' | 'end';
    /**
     * Подописание значения
     */
    valueSubheading?: string;
    /**
     * Описание значения
     */
    valueDescription?: string;
    /**
     * Подописание значения
     */
    valueSubDescription?: string;
    /**
     * Позиция описания
     */
    valueDescPosition?: 'row' | 'column';
    /**
     * Props для статуса
     */
    valueLabelStatusProps?: StatusProps;
    /**
     * Props для процента
     */
    valueLabelPercentProps?: PercentProps;
    /**
     * Props для цены
     */
    valueLabelPriceProps?: PercentProps;
    /**
     * Props для тега
     */
    valueTagProps?: TagProps;
    /**
     * Валюта
     */
    valueCurrency?: 'kz' | 'us' | 'eu' | 'gb' | 'ru' | 'bcc_cashback' | '';
    /**
     * Флаг отключения тайтла
     */
    disableTitle?: boolean;
    /**
     * Подзаголовок
     */
    subheading?: string;
    /**
     * Обработчик клика
     */
    onClick?: () => void;
    /**
     * Флаг активности категории
     */
    isActive?: boolean;
    /**
     * Css-класс для стилизации
     */
    className?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
};
export {};
