/// <reference types="react" />
export declare const AccountCell: import("react").ForwardRefExoticComponent<Omit<import("react").HTMLAttributes<HTMLHeadingElement>, "onChange"> & {
    icon?: import("react").ReactNode;
    title: string;
    subheading?: string | undefined;
    description?: string | undefined;
    disabled?: boolean | undefined;
    value?: boolean | undefined;
    type?: "checkbox" | "radio" | "switch" | undefined;
    name?: string | undefined;
    position?: "end" | "start" | undefined;
    subDescription?: string | undefined;
    descPosition?: "column" | "row" | undefined;
    currency?: "ru" | "kz" | "us" | "eu" | "gb" | "bcc_cashback" | undefined;
    labelStatusProps?: import("../../../layout/label/components/status").StatusProps | undefined;
    labelPercentProps?: import("../../../layout/label/components/percent").PercentProps | undefined;
    labelPriceProps?: import("../../../layout/label/components/price").PriceProps | undefined;
    tagProps?: import("../../../tag").TagProps | undefined;
    onChange?: import("./AccountCell.type").OnChangeHandler | undefined;
    className?: string | undefined;
    'data-test-id'?: string | undefined;
    children?: import("react").ReactNode;
} & import("react").RefAttributes<HTMLDivElement>>;
