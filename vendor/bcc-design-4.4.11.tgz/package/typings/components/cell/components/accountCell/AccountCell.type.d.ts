import { ChangeEvent, HTMLAttributes } from 'react';
import { PercentProps } from '../../../layout/label/components/percent';
import { PriceProps } from '../../../layout/label/components/price';
import { StatusProps } from '../../../layout/label/components/status';
import { TagProps } from '../../../tag';
type NativeProps = HTMLAttributes<HTMLHeadingElement>;
export type OnChangeHandler = (e: ChangeEvent<HTMLInputElement>, payload: any) => void;
export type AccountCellProps = Omit<NativeProps, 'onChange'> & {
    /**
     * Иконка слева от заголовка
     */
    icon?: React.ReactNode;
    /**
     * Заголовок категории
     */
    title: string;
    /**
     * Подзаголовок категории
     */
    subheading?: string;
    /**
     * Описание категории
     */
    description?: string;
    /**
     * Отключение контрола
     */
    disabled?: boolean;
    /**
     * Значение категории
     */
    value?: boolean;
    /**
     * Тип контрола
     */
    type?: 'radio' | 'checkbox' | 'switch';
    /**
     * Имя контрола
     */
    name?: string;
    /**
     * Позиция контента
     */
    position?: 'start' | 'end';
    /**
     * Дополнительное описание
     */
    subDescription?: string;
    /**
     * Позиция дополнительного описания
     */
    descPosition?: 'column' | 'row';
    /**
     * Валюта
     */
    currency?: 'kz' | 'us' | 'eu' | 'gb' | 'ru' | 'bcc_cashback';
    /**
     * Пропсы статуса
     */
    labelStatusProps?: StatusProps;
    /**
     * Пропсы процента
     */
    labelPercentProps?: PercentProps;
    /**
     * Пропсы цены
     */
    labelPriceProps?: PriceProps;
    /**
     * Пропсы тега
     */
    tagProps?: TagProps;
    /**
     * Обработчик изменения значения
     */
    onChange?: OnChangeHandler;
    /**
     * Css-класс для стилизации
     */
    className?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
};
export {};
