import { ChangeEvent, HTMLAttributes } from 'react';
import { PercentProps } from '../../../layout/label/components/percent';
import { StatusProps } from '../../../layout/label/components/status';
import { TooltipProps } from '../../../tooltip';
type NativeProps = HTMLAttributes<HTMLHeadingElement>;
export type OnChangeHandler = (e: ChangeEvent<HTMLInputElement>, payload: any) => void;
export type DragCellProps = Omit<NativeProps, 'onClick'> & {
    /**
     * Иконка слева от заголовка
     */
    addon?: React.ReactNode;
    /**
     * Заголовок категории
     */
    title?: string;
    /**
     * Флаг активности значка checkmark
     */
    enableCheckmark?: boolean;
    /**
     * Описание категории
     */
    description?: string;
    /**
     * Подописание категории
     */
    subDescription?: string;
    /**
     * Позиция описания
     */
    descPosition?: 'row' | 'column';
    /**
     * Props для статуса
     */
    labelStatusProps?: StatusProps;
    /**
     * Props для процента
     */
    labelPercentProps?: PercentProps;
    /**
     * Props для тултипа
     */
    tooltipProps?: Omit<TooltipProps, 'children'>;
    /**
     * Флаг отключения тайтла
     */
    disableTitle?: boolean;
    /**
     * Флаг активности категории
     */
    disabled?: boolean;
    /**
     * Тайтл для значения
     */
    valueTitle?: string;
    /**
     * Позиция значения
     */
    valuePosition?: 'start' | 'end';
    /**
     * Подописание значения
     */
    valueSubheading?: string;
    /**
     * Описание значения
     */
    valueDescription?: string;
    /**
     * Подописание значения
     */
    valueSubDescription?: string;
    /**
     * Позиция описания
     */
    valueDescPosition?: 'row' | 'column';
    /**
     * Props для статуса
     */
    valueLabelStatusProps?: StatusProps;
    /**
     * Props для процента
     */
    valueLabelPercentProps?: PercentProps;
    /**
     * Props для цены
     */
    valueLabelPriceProps?: PercentProps;
    /**
     * Валюта
     */
    valueCurrency?: 'kz' | 'us' | 'eu' | 'gb' | 'ru' | 'bcc_cashback' | '';
    /**
     * Подзаголовок
     */
    subheading?: string;
    /**
     * Обработчик клика
     */
    onClick?: () => void;
    /**
     * Позиция контрола
     */
    controlPosition?: 'start' | 'end';
    /**
     * Обработчик перетаскивания на старт
     */
    onDragStart?: () => void;
    /**
     * Обработчик перетаскивания на конец
     */
    onDragEnd?: () => void;
    /**
     * Обработчик перетаскивания
     */
    onDrag?: () => void;
    /**
     * Css-класс для стилизации
     */
    className?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
};
export {};
