import { ChangeEvent, HTMLAttributes } from 'react';
type NativeProps = HTMLAttributes<HTMLHeadingElement>;
export type OnChangeHandler = (e: ChangeEvent<HTMLInputElement>, payload: any) => void;
export type CardCellProps = Omit<NativeProps, 'onChange'> & {
    /**
     * Иконка слева от заголовка
     */
    addon?: React.ReactNode;
    /**
     * Заголовок категории
     */
    title: string;
    /**
     * Подзаголовок категории
     */
    subheading?: string;
    /**
     * Описание категории
     */
    description?: string;
    /**
     * Отключение контрола
     */
    disabled?: boolean;
    /**
     * Значение категории
     */
    value?: boolean;
    /**
     * Тип контрола
     */
    type?: 'checkmark' | 'checkbox' | 'switch' | 'radio' | 'switch' | 'drag' | 'dots';
    /**
     * Позиция контрола
     */
    controlPosition?: 'start' | 'end';
    /**
     * Имя контрола
     */
    name?: string;
    /**
     * Дополнительное описание
     */
    subDescription?: string;
    /**
     * Позиция дополнительного описания
     */
    descPosition?: 'column' | 'row';
    /**
     * Обработчик изменения значения
     */
    onChange?: OnChangeHandler;
    /**
     * Обработчик клика
     */
    onClick?: () => void;
    /**
     * Обработчик клика
     */
    onCellClick?: () => void;
    /**
     * Обработчик начала перетаскивания
     */
    onDragStart?: () => void;
    /**
     * Обработчик окончания перетаскивания
     */
    onDragEnd?: () => void;
    /**
     * Обработчик перетаскивания
     */
    onDrag?: () => void;
    /**
     * Css-класс для стилизации
     */
    className?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
};
export {};
