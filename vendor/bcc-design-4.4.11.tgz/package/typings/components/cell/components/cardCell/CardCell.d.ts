/// <reference types="react" />
export declare const CardCell: import("react").ForwardRefExoticComponent<Omit<import("react").HTMLAttributes<HTMLHeadingElement>, "onChange"> & {
    addon?: import("react").ReactNode;
    title: string;
    subheading?: string | undefined;
    description?: string | undefined;
    disabled?: boolean | undefined;
    value?: boolean | undefined;
    type?: "drag" | "checkbox" | "radio" | "switch" | "checkmark" | "dots" | undefined;
    controlPosition?: "end" | "start" | undefined;
    name?: string | undefined;
    subDescription?: string | undefined;
    descPosition?: "column" | "row" | undefined;
    onChange?: import("./CardCell.type").OnChangeHandler | undefined;
    onClick?: (() => void) | undefined;
    onCellClick?: (() => void) | undefined;
    onDragStart?: (() => void) | undefined;
    onDragEnd?: (() => void) | undefined;
    onDrag?: (() => void) | undefined;
    className?: string | undefined;
    'data-test-id'?: string | undefined;
    children?: import("react").ReactNode;
} & import("react").RefAttributes<HTMLDivElement>>;
