import { HTMLAttributes } from 'react';
import { PercentProps } from '../../../layout/label/components/percent';
import { PriceProps } from '../../../layout/label/components/price';
import { StatusProps } from '../../../layout/label/components/status';
import { TagProps } from '../../../tag';
type NativeProps = HTMLAttributes<HTMLHeadingElement>;
export type HistoryCellProps = Omit<NativeProps, 'onClick'> & {
    /**
     * Иконка слева от заголовка
     */
    addon?: React.ReactNode;
    /**
     * Заголовок категории
     */
    title?: string;
    /**
     * Время
     */
    time?: Date;
    /**
     * Включает зеленое значение
     */
    successValue?: boolean;
    /**
     * Заголовок value
     */
    valueTitle?: string;
    /**
     * Подзаголовок категории
     */
    subheading?: string;
    /**
     * Описание категории
     */
    description?: string;
    /**
     * Позиция контента
     */
    position?: 'start' | 'end';
    /**
     * Дополнительное описание
     */
    subDescription?: string;
    /**
     * Позиция дополнительного описания
     */
    descPosition?: 'column' | 'row';
    /**
     * Валюта
     */
    currency?: 'kz' | 'us' | 'eu' | 'gb' | 'ru' | 'bcc_cashback';
    /**
     * Пропсы статуса
     */
    labelStatusProps?: StatusProps;
    /**
     * Пропсы процента
     */
    labelPercentProps?: PercentProps;
    /**
     * Пропсы цены
     */
    labelPriceProps?: PriceProps;
    /**
     * Пропсы тега
     */
    tagProps?: TagProps;
    /**
     * Обработчик клика
     */
    onClick?: () => void;
    /**
     * Css-класс для стилизации
     */
    className?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
};
export {};
