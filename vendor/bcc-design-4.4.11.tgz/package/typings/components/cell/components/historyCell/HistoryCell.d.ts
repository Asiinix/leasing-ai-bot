/// <reference types="react" />
export declare const HistoryCell: import("react").ForwardRefExoticComponent<Omit<import("react").HTMLAttributes<HTMLHeadingElement>, "onClick"> & {
    addon?: import("react").ReactNode;
    title?: string | undefined;
    time?: Date | undefined;
    successValue?: boolean | undefined;
    valueTitle?: string | undefined;
    subheading?: string | undefined;
    description?: string | undefined;
    position?: "end" | "start" | undefined;
    subDescription?: string | undefined;
    descPosition?: "column" | "row" | undefined;
    currency?: "ru" | "kz" | "us" | "eu" | "gb" | "bcc_cashback" | undefined;
    labelStatusProps?: import("../../../layout/label/components/status").StatusProps | undefined;
    labelPercentProps?: import("../../../layout/label/components/percent").PercentProps | undefined;
    labelPriceProps?: import("../../../layout/label/components/price").PriceProps | undefined;
    tagProps?: import("../../../tag").TagProps | undefined;
    onClick?: (() => void) | undefined;
    className?: string | undefined;
    'data-test-id'?: string | undefined;
    children?: import("react").ReactNode;
} & import("react").RefAttributes<HTMLDivElement>>;
