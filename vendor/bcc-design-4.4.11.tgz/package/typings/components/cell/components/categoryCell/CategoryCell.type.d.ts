import { HTMLAttributes } from 'react';
import { PercentProps } from '../../../layout/label/components/percent';
import { StatusProps } from '../../../layout/label/components/status';
import { TooltipProps } from '../../../tooltip';
type NativeProps = HTMLAttributes<HTMLHeadingElement>;
export type CategoryCellProps = NativeProps & {
    /**
     * Иконка слева от заголовка
     */
    addon?: React.ReactNode;
    /**
     * Заголовок категории
     */
    title?: string;
    /**
     * Подзаголовок категории
     */
    subheading?: string;
    /**
     * Подописание категории
     */
    subDescription?: string;
    /**
     * Позиция описания
     */
    descPosition?: 'row' | 'column';
    /**
     * Свойства для статуса
     */
    labelStatusProps?: StatusProps;
    /**
     * Свойства для процентов
     */
    labelPercentProps?: PercentProps;
    /**
     * Свойства для тултипа
     */
    tooltipProps?: Omit<TooltipProps, 'children'>;
    /**
     * Описание категории
     */
    description?: string;
    /**
     * Флаг активности категории
     */
    disabled?: boolean;
    /**
     * Обработчик клика
     */
    onClick?: () => void;
    /**
     * Размер текста
     */
    textSize?: 'sm' | 'md';
    /**
     * Флаг кликабельности
     */
    clickable?: boolean;
    /**
     * Флаг активности категории
     */
    isActive?: boolean;
    /**
     * Css-класс для стилизации
     */
    className?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
};
export {};
