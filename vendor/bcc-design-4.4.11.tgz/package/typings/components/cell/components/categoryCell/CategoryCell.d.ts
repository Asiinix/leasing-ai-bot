/// <reference types="react" />
export declare const CategoryCell: import("react").ForwardRefExoticComponent<import("react").HTMLAttributes<HTMLHeadingElement> & {
    addon?: import("react").ReactNode;
    title?: string | undefined;
    subheading?: string | undefined;
    subDescription?: string | undefined;
    descPosition?: "column" | "row" | undefined;
    labelStatusProps?: import("../../../layout/label/components/status").StatusProps | undefined;
    labelPercentProps?: import("../../../layout/label/components/percent").PercentProps | undefined;
    tooltipProps?: Omit<import("../../../tooltip").TooltipProps, "children"> | undefined;
    description?: string | undefined;
    disabled?: boolean | undefined;
    onClick?: (() => void) | undefined;
    textSize?: "sm" | "md" | undefined;
    clickable?: boolean | undefined;
    isActive?: boolean | undefined;
    className?: string | undefined;
    'data-test-id'?: string | undefined;
    children?: import("react").ReactNode;
} & import("react").RefAttributes<HTMLDivElement>>;
