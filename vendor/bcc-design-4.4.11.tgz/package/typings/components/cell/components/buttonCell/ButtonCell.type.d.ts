import { HTMLAttributes } from 'react';
import { EButtonVariant } from '../../../button';
import { PercentProps } from '../../../layout/label/components/percent';
import { StatusProps } from '../../../layout/label/components/status';
import { TagProps } from '../../../tag';
import { TooltipProps } from '../../../tooltip';
type NativeProps = HTMLAttributes<HTMLHeadingElement>;
export type ButtonCellProps = NativeProps & {
    /**
     * Иконка слева от заголовка
     */
    addon?: React.ReactNode;
    /**
     * Заголовок категории
     */
    title?: string;
    /**
     * Описание категории
     */
    description?: string;
    /**
     * Подописание категории
     */
    subDescription?: string;
    /**
     * Позиция описания
     */
    descPosition?: 'row' | 'column';
    /**
     * Props для статуса
     */
    labelStatusProps?: StatusProps;
    /**
     * Props для процента
     */
    labelPercentProps?: PercentProps;
    /**
     * Props для тега
     */
    tagProps?: TagProps;
    /**
     * Props для тултипа
     */
    tooltipProps?: Omit<TooltipProps, 'children'>;
    /**
     * Тайтл для значения
     */
    valueTitle?: string;
    /**
     * Позиция значения
     */
    valuePosition?: 'start' | 'end';
    /**
     * Подописание значения
     */
    valueSubheading?: string;
    /**
     * Описание значения
     */
    valueDescription?: string;
    /**
     * Подописание значения
     */
    valueSubDescription?: string;
    /**
     * Позиция описания
     */
    valueDescPosition?: 'row' | 'column';
    /**
     * Props для статуса
     */
    valueLabelStatusProps?: StatusProps;
    /**
     * Props для процента
     */
    valueLabelPercentProps?: PercentProps;
    /**
     * Props для цены
     */
    valueLabelPriceProps?: PercentProps;
    /**
     * Лейбл значения
     */
    valueLabel?: string;
    /**
     * Props для тега
     */
    valueTagProps?: TagProps;
    /**
     * Валюта
     */
    valueCurrency?: 'kz' | 'us' | 'eu' | 'gb' | 'ru' | 'bcc_cashback';
    /**
     * Флаг отключения тайтла
     */
    disableTitle?: boolean;
    /**
     * Флаг активности категории
     */
    disabled?: boolean;
    /**
     *  Текст кнопки
     */
    buttonText?: string;
    /**
     * Вид кнопки
     */
    buttonView?: EButtonVariant;
    /**
     * Подзаголовок
     */
    subheading?: string;
    /**
     * Обработчик клика
     */
    onClick?: () => void;
    /**
     * Css-класс для стилизации
     */
    className?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
};
export {};
