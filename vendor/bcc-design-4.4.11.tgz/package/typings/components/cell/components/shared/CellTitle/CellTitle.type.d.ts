import { HTMLAttributes } from 'react';
import { PercentProps } from '../../../../layout/label/components/percent';
import { StatusProps } from '../../../../layout/label/components/status';
import { TagProps } from '../../../../tag';
import { TooltipProps } from '../../../../tooltip';
type NativeProps = HTMLAttributes<HTMLDivElement>;
export type CellTitleProps = NativeProps & {
    /**
     * Заголовок категории
     */
    title: string;
    /**
     * Описание
     */
    description?: string;
    /**
     * Подзаголовок
     */
    subDescription?: string;
    /**
     * Позиции описания
     */
    descPosition?: 'column' | 'row';
    /**
     * Размер текста
     */
    textSize?: 'sm' | 'md';
    /**
     * Подзаголовок категории
     */
    subheading?: string;
    /**
     * Пропсы статуса
     */
    labelStatusProps?: StatusProps;
    /**
     * Пропсы процента
     */
    labelPercentProps?: PercentProps;
    /**
     * Пропсы тега
     */
    tagProps?: TagProps;
    /**
     * Пропсы тултипа
     */
    tooltipProps?: Omit<TooltipProps, 'children'>;
    /**
     * Флаг активности
     */
    disabled?: boolean;
    /**
     * Флаг успешности
     */
    successType?: boolean;
    /**
     * Css-класс для стилизации
     */
    className?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
};
export {};
