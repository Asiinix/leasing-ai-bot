export declare const DotsIcon: ({ disabled, onClick }: {
    disabled: any;
    onClick: any;
}) => import("react/jsx-runtime").JSX.Element;
