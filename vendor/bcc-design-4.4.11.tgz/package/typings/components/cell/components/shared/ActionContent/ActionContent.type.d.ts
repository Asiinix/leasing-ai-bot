import { HTMLAttributes } from 'react';
import { PercentProps } from '../../../../layout/label/components/percent';
import { StatusProps } from '../../../../layout/label/components/status';
import { TagProps } from '../../../../tag';
import { TooltipProps } from '../../../../tooltip';
type NativeProps = Omit<HTMLAttributes<HTMLHeadingElement>, 'onChange'>;
export type ActionContentProps = NativeProps & {
    /**
     * Иконка слева от заголовка
     */
    addon?: React.ReactNode;
    /**
     * Флаг квадратной иконки
     */
    isSquareAddon?: boolean;
    /**
     * Заголовок категории
     */
    title?: string;
    /**
     * Описание категории
     */
    description?: string;
    /**
     * Подописание категории
     */
    subDescription?: string;
    /**
     * Позиция описания
     */
    descPosition?: 'row' | 'column';
    /**
     * Позиция контрола
     */
    controlPosition?: 'start' | 'end';
    /**
     * Props для статуса
     */
    labelStatusProps?: StatusProps;
    /**
     * Props для процента
     */
    labelPercentProps?: PercentProps;
    /**
     * Props для тега
     */
    tagProps?: TagProps;
    /**
     * Props для тултипа
     */
    tooltipProps?: Omit<TooltipProps, 'children'>;
    /**
     * Флаг активности категории
     */
    disabled?: boolean;
    /**
     * Имя контрола
     */
    name?: string;
    /**
     * Значение категории
     */
    value?: boolean;
    /**
     * Тайтл для значения
     */
    valueTitle?: string;
    /**
     * Позиция значения
     */
    valuePosition?: 'start' | 'end';
    /**
     * Подописание значения
     */
    valueSubheading?: string;
    /**
     * Описание значения
     */
    valueDescription?: string;
    /**
     * Подописание значения
     */
    valueSubDescription?: string;
    /**
     * Позиция описания
     */
    valueDescPosition?: 'row' | 'column';
    /**
     * Props для статуса
     */
    valueLabelStatusProps?: StatusProps;
    /**
     * Props для процента
     */
    valueLabelPercentProps?: PercentProps;
    /**
     * Props для цены
     */
    valueLabelPriceProps?: PercentProps;
    /**
     * Лейбл значения
     */
    valueLabel?: string;
    /**
     * Props для тега
     */
    valueTagProps?: TagProps;
    /**
     * Валюта
     */
    valueCurrency?: 'kz' | 'us' | 'eu' | 'gb' | 'ru' | 'bcc_cashback' | '';
    /**
     * Подзаголовок
     */
    subheading?: string;
    /**
     * Флаг отключения тайтла
     */
    disableTitle?: boolean;
    /**
     * Флаг отключения значения в конце ячейки
     */
    disableValueEnd?: boolean;
    /**
     * Текущий компонент в начале cell
     */
    componentStart?: React.ReactNode;
    /**
     * Текущий компонент в конце cell
     */
    componentEnd?: React.ReactNode;
    /**
     * Css-класс для стилизации
     */
    className?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
};
export {};
