export declare const ActionItem: ({ Component, value, name, onChange, controlPosition, disabled }: {
    Component: any;
    value: any;
    name: any;
    onChange: any;
    controlPosition?: string | undefined;
    disabled: any;
}) => import("react/jsx-runtime").JSX.Element;
