export declare const CellDescription: ({ description, subDescription, descPosition, disabled, descriptionImagesArray }: {
    description: any;
    subDescription: any;
    descPosition: any;
    disabled: any;
    descriptionImagesArray: any;
}) => import("react/jsx-runtime").JSX.Element;
