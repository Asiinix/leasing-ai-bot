export declare const CheckmarkIcon: ({ disabled }: {
    disabled: any;
}) => import("react/jsx-runtime").JSX.Element;
