/// <reference types="react" />
import { CellValueProps } from './CellValue.type';
export declare const CellValue: React.FC<CellValueProps>;
