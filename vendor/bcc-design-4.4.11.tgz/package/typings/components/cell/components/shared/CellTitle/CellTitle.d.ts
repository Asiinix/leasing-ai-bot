/// <reference types="react" />
import { CellTitleProps } from './CellTitle.type';
export declare const CellTitle: React.FC<CellTitleProps>;
