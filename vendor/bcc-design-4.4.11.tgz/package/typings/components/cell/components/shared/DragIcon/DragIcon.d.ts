export declare const DragIcon: ({ disabled, onDragStart, onDragEnd, onDrag }: {
    disabled: any;
    onDragStart: any;
    onDragEnd: any;
    onDrag: any;
}) => import("react/jsx-runtime").JSX.Element;
