import React from 'react';
interface CellImagesProps {
    /** Array of images to be displayed */
    descriptionImagesArray: React.ReactNode[];
    /** Optional class name for additional styling */
    disabled?: boolean;
}
export declare const CellImages: React.FC<CellImagesProps>;
export {};
