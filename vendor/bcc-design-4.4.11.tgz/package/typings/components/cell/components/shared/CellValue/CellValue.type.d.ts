import { HTMLAttributes } from 'react';
import { PercentProps } from '../../../../layout/label/components/percent';
import { PriceProps } from '../../../../layout/label/components/price';
import { StatusProps } from '../../../../layout/label/components/status';
import { TagProps } from '../../../../tag';
type NativeProps = HTMLAttributes<HTMLDivElement>;
export type CellValueProps = NativeProps & {
    /**
     * Заголовок категории
     */
    title: string;
    /**
     * Включает зеленое значение
     */
    successValue?: boolean;
    /**
     * Тип позиции
     */
    position?: 'start' | 'end';
    /**
     * Описание
     */
    description?: string;
    /**
     * Массив изображений
     */
    descriptionImagesArray?: React.ReactNode[];
    /**
     * Подзаголовок
     */
    subDescription?: string;
    /**
     * Позиции описания
     */
    descPosition?: 'column' | 'row';
    /**
     * Валюта
     */
    currency?: 'kz' | 'us' | 'eu' | 'gb' | 'ru' | 'bcc_cashback' | '';
    /**
     * Подзаголовок категории
     */
    subheading?: string;
    /**
     * Пропсы статуса
     */
    labelStatusProps?: StatusProps;
    /**
     * Пропсы процента
     */
    labelPercentProps?: PercentProps;
    /**
     * Пропсы цены
     */
    labelPriceProps?: PriceProps;
    /**
     * Пропсы тега
     */
    tagProps?: TagProps;
    /**
     * Иконка тега
     */
    tagIcon?: React.ReactNode;
    /**
     * Флаг активности
     */
    disabled?: boolean;
    /**
     * Css-класс для стилизации
     */
    className?: string;
    /**
     * Css-класс для стилизации заголовка
     */
    classNameTitle?: string;
    /**
     * Id компонента для тестов
     */
    'data-test-id'?: string;
    /**
     * Контент (native prop)
     */
    children?: React.ReactNode;
};
export {};
