/// <reference types="react" />
import { AccentFieldProps } from '../../../info-field/components/accentField/AccentField.type';
export declare const AccentField: import("react").ForwardRefExoticComponent<AccentFieldProps & import("react").RefAttributes<HTMLDivElement>>;
