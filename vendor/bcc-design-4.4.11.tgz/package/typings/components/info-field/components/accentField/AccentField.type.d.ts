/// <reference types="react" />
import { InfoFieldSuffixProps } from '../../../info-field/InfoField.type';
declare enum FieldDirection {
    Horizontal = "horizontal",
    Vertical = "vertical"
}
declare enum LabelSize {
    Small = "sm",
    Medium = "md",
    Large = "lg"
}
export interface AccentFieldProps {
    /**
     * Уникальный идентификатор для автоматизированного тестирования
     * @example "field-name-test-id"
     */
    'data-test-id'?: string;
    /**
     * Направление отображения поля
     * @default FieldDirection.Vertical
     */
    direction?: FieldDirection;
    /**
     * Текст метки поля
     */
    label: string;
    /**
     * Размер метки
     * @default LabelSize.Medium
     */
    labelSize?: LabelSize;
    /**
     * Значение поля. Для числовых типов рекомендуется использовать `FieldType`
     */
    value: string | number | React.ReactNode;
    /**
     * Значение поля. Для числовых типов рекомендуется использовать `FieldType`
     */
    valueTrough?: string | number | React.ReactNode;
    /**
     * Суффикс для дополнительной информации или действий
     */
    suffix?: InfoFieldSuffixProps;
    /**
     * Дополнительный элемент иконка рядом с полем
     */
    addon?: React.ReactNode;
    /**
     * Отключенное состояние поля
     * @default false
     */
    disabled?: boolean;
    /**
     * Дополнительное описание под полем
     */
    caption?: string;
    /**
     * CSS-класс для стилизации (native prop)
     */
    className?: string;
    /**
     * CSS-класс для стилизации метки (native prop)
     */
    labelClassName?: string;
    /**
     * CSS-класс для стилизации описания (native prop)
     */
    captionClassName?: string;
    /**
     * CSS-класс для стилизации иконки (native prop)
     */
    addonClassName?: string;
}
export {};
