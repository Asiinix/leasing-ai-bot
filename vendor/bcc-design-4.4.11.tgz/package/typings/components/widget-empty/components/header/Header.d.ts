import { WidgetEmptyData, WidgetEmptySize } from '../../WidgetEmpty.type';
type WidgetEmptyHeaderProps = {
    iconPath?: WidgetEmptyData['icon'] | null;
    size?: WidgetEmptySize;
};
export declare const WidgetEmptyHeader: ({ iconPath, size }: WidgetEmptyHeaderProps) => import("react/jsx-runtime").JSX.Element | null;
export {};
