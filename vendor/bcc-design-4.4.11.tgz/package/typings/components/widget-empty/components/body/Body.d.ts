import { ReactNode } from 'react';
import { WidgetEmptySize } from '../../WidgetEmpty.type';
type WidgetEmptyBodyProps = {
    title: string;
    description: ReactNode;
    size?: WidgetEmptySize;
};
export declare const WidgetEmptyBody: ({ title, description, size }: WidgetEmptyBodyProps) => import("react/jsx-runtime").JSX.Element;
export {};
