import { WidgetEmptySize } from '../../WidgetEmpty.type';
type WidgetEmptyFooterProps = {
    actionButtonHandler: () => void;
    actionButtonLabel: string;
    isLoading?: boolean;
    size?: WidgetEmptySize;
};
export declare const WidgetEmptyFooter: ({ actionButtonHandler, actionButtonLabel, isLoading, size, }: WidgetEmptyFooterProps) => import("react/jsx-runtime").JSX.Element;
export {};
