import { ReactNode } from 'react';
export type FormControlExtraAddonWrapperProps = {
    position: 'left' | 'right';
    children?: ReactNode;
};
