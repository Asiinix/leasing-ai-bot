import { FormControlExtraAddonWrapperProps } from './FormControlExtraAddonWrapper.type';
export declare const FormControlExtraAddonWrapper: ({ children, position }: FormControlExtraAddonWrapperProps) => import("react/jsx-runtime").JSX.Element;
