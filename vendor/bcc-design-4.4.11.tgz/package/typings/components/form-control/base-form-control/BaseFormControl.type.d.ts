import type { HTMLAttributes, ReactNode } from 'react';
export type BaseFormLabelType = 'inner' | 'outer';
type NativeProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange' | 'onClear'>;
export type BaseFormControlProps = NativeProps & {
    /**
     * Растянуть элемент на всю ширину
     */
    fullWidth?: boolean;
    /**
     * Размер инпута (размер sm не отображает label)
     */
    size?: 'sm' | 'md' | 'lg';
    /**
     * Отключенное состояние
     */
    disabled?: boolean;
    /**
     * Выбранное (фокус) состояние
     */
    focused?: boolean;
    /**
     * Выбранное (фокус) состояние для wrapper-a
     */
    focusedWrapper?: boolean;
    /**
     * Заполненое состояние
     */
    filled?: boolean;
    /**
     * Отображение ошибки / состояние ошибки
     */
    error?: ReactNode | boolean;
    /**
     * Состояние успеха / текст подсказки успеха
     */
    success?: ReactNode | boolean;
    /**
     * Текст подсказки
     */
    hint?: ReactNode;
    /**
     * Лейбл компонента
     */
    label?: ReactNode;
    /**
     * Вид лейбла внутри / снаружи
     */
    labelType?: BaseFormLabelType;
    /**
     * Слот слева
     */
    leftAddon?: ReactNode;
    /**
     * Слот справа
     */
    rightAddon?: ReactNode;
    /**
     * Компонент поля (инпут, textarea и пр.)
     */
    children?: ReactNode;
    /**
     * Выделять ли место для caption или error текста
     */
    preserveCaptionSpace?: boolean;
    /**
     * Анимировать ли появление caption или error
     */
    animateCaption?: boolean;
    /**
     * Дополнительный контент справа в caption вместо счетчика символов
     */
    captionRight?: ReactNode;
    inputWrapperId?: string;
    _extraAddonLeft?: ReactNode;
    _extraAddonRight?: ReactNode;
    _extraAddonBottom?: ReactNode;
    _extraInnerAddonRight?: ((formControlRenderingData: any) => ReactNode) | ReactNode;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
};
export {};
