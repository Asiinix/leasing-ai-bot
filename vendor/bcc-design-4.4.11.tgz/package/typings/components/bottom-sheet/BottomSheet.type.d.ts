import { ReactNode } from 'react';
export type BottomSheetProps = {
    /** Определяет, открыто ли шторка. */
    open: boolean;
    /** Заголовок шторки */
    title?: ReactNode;
    /** Выравнивания заголовка */
    titleAlign?: 'left' | 'center' | 'right';
    /** Футер шторки */
    footer?: ReactNode;
    /** Контейнер, в котором будет рендериться компонент. */
    container?: Element | DocumentFragment | null;
    /** Определяет, использовать ли портал для рендеринга. */
    usePortal?: boolean;
    /** Производить ли автофокус по первому инпут элементу при открытии. */
    autoFocus?: boolean;
    /**
     * Магнитные зоны останова для шторки. Указывать можно как в пикселях (number), так и в процентах (string)
     * Например: [0, 250, 400, '100%'].
     * */
    snapAreas?: (number | string)[];
    /** Индекс точки из snapAreas, к которому нужно примагнититься при первом открытии шторки. */
    initialActiveAreaIndex?: number;
    /** Определяет, есть ли кнопка закрытия. */
    showClose?: boolean;
    /** Показывать ли кнопку назад. */
    showBackArrow?: boolean;
    /** Обработчик клика по кнопке назад. */
    onBackArrowClick?: () => void;
    /** Закреплять заголовок при скролле. */
    stickyHeader?: boolean;
    /** Адаптировать ли высоту контента. */
    adaptiveHeight?: boolean;
    /** Закреплять футер при скролле(по умолчанию true). */
    stickyFooter?: boolean;
    /** Скрыть оверлей. */
    hideBackdrop?: boolean;
    /** Лочить ли скролл контентной части. (применится overflow: hidden) */
    lockScroll?: boolean;
    /** Отключить закрытие по клику на оверлей. */
    disableBackdropClick?: boolean;
    /** Включить/выключить свайпы. */
    swipeable?: boolean;
    /** Порог для свайпа */
    swipeThreshold?: number;
    /** Смещение заголовка сверху */
    headerOffset?: number;
    /** Должна ли свайпаться шторка, если свайп происходит по контентной части */
    swipableContent?: boolean;
    /** Коллбэк на закрытие. */
    onClose?: () => void;
    /** Добавления border при скролле хедера. */
    highlightHeader?: boolean;
    /** Добавления border при скролле футера. */
    highlightFooter?: boolean;
    /** Добавить ли blur эффект для бэкдропа. */
    withBlurredBackdrop?: boolean;
    /** Рендерить ли шторку, даже если она закрыта. */
    forceRender?: boolean;
    /** Доп слот внизу хедера. */
    headerBottomAddon?: ReactNode;
    /**
     * Убрать внутренние отступы заголовка хедера.
     * Используется, когда в title передаётся компонент со своими отступами (например, Topbar),
     * чтобы не было двойного паддинга и обрезки контента.
     */
    disableHeaderInsets?: boolean;
    children?: ReactNode;
    /** Сеттер высоты контентной части шторки */
    heightContentSetter?: (contentHeight: number) => void;
    /** Тестовый идентификатор. */
    'data-test-id'?: string;
};
