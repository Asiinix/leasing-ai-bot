import React, { ReactNode } from 'react';
type BottomSheetFooterProps = {
    sticky: boolean;
    highlight: boolean;
    children?: ReactNode;
};
export declare const BottomSheetFooter: React.MemoExoticComponent<React.ForwardRefExoticComponent<BottomSheetFooterProps & React.RefAttributes<HTMLDivElement>>>;
export {};
