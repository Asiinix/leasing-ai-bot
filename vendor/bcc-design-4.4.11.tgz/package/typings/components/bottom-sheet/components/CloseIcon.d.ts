import React, { SVGProps } from 'react';
export declare const CloseIcon: React.MemoExoticComponent<(props: SVGProps<SVGSVGElement>) => import("react/jsx-runtime").JSX.Element>;
