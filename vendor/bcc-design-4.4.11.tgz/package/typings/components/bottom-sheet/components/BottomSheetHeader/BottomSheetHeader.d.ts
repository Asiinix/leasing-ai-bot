import { ReactNode } from 'react';
type BottomSheetHeaderProps = {
    sticky: boolean;
    swipeable: boolean;
    highlight: boolean;
    showClose: boolean;
    showBackArrow?: boolean;
    onBackArrowClick?: () => void;
    titleAlign?: 'left' | 'center' | 'right';
    headerBottomAddon?: ReactNode;
    children?: ReactNode;
    onClose?: () => void;
    /** Убрать внутренние отступы заголовка (для вложенного контента со своими отступами, напр. Topbar). */
    disableInsets?: boolean;
};
export declare const BottomSheetHeader: import("react").ForwardRefExoticComponent<BottomSheetHeaderProps & import("react").RefAttributes<HTMLDivElement>>;
export {};
