import React from 'react';
type Props = {
    shouldRender: boolean;
    usePortal: boolean;
    container: Element | DocumentFragment | null;
    children: React.ReactNode;
};
export declare const BottomSheetPortal: ({ shouldRender, usePortal, children, container }: Props) => import("react/jsx-runtime").JSX.Element | null;
export {};
