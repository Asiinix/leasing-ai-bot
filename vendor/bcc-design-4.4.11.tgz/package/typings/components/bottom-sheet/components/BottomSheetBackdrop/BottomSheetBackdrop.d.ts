import React from 'react';
type BottomSheetBackdropProps = {
    opacity: number;
    show: boolean;
    hidden: boolean;
    blured: boolean;
    onClick?: () => void;
};
export declare const BottomSheetBackdrop: React.MemoExoticComponent<({ opacity, show, hidden, blured, onClick }: BottomSheetBackdropProps) => import("react/jsx-runtime").JSX.Element>;
export {};
