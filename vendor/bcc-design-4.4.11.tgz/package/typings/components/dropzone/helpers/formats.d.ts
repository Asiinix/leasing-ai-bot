export declare const getAcceptedFormats: (accept: Record<string, string[]>) => string;
