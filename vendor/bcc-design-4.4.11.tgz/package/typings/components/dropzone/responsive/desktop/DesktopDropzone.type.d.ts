import { CSSProperties } from 'react';
import { DropzoneError, FileStatus } from '../../Dropzone.type';
type UploadMethod = 'post' | 'put' | 'patch';
export type DesktopDropzoneProps = {
    title?: string;
    description?: string;
    separatorText?: string;
    maxSize?: number;
    maxFiles?: number;
    accept?: Record<string, string[]>;
    acceptText?: string;
    isError?: boolean;
    errorText?: string;
    dragFileText?: string;
    buttonText?: string;
    uploadMethod?: UploadMethod;
    uploadLink?: string;
    customFileStatuses?: FileStatus[];
    customDropHandler?: (files: File[]) => void;
    onFileDelete?: (file: any, deleteUICallback: () => void) => void;
    onFileRefresh?: (file: FileStatus) => void;
    onFileClick?: (file: FileStatus) => void;
    handleSuccessDrop?: (data: any) => void;
    /**
     * @deprecated Use onDropRejected instead for better error handling with error types
     */
    handleErrorDrop?: (data: any) => void;
    onDropRejected?: (error: DropzoneError) => void;
    onFileSizeError?: (error: DropzoneError) => void;
    onFileCountError?: (error: DropzoneError) => void;
    disableImmediateUpload?: boolean;
    onUploadHandler?: (files: File | File[]) => void;
    isDisabled?: boolean;
    className?: string;
    style?: CSSProperties;
    'data-pw'?: string;
};
export {};
