/// <reference types="react" />
import { DesktopDropzoneProps } from './DesktopDropzone.type';
export declare const DesktopDropzone: React.FC<DesktopDropzoneProps>;
