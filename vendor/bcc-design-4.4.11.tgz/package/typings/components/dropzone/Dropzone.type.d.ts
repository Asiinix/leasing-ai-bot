import { CSSProperties } from 'react';
import { FileRejection } from 'react-dropzone';
type UploadMethod = 'post' | 'put' | 'patch';
export declare enum DropzoneErrorType {
    FILE_TOO_LARGE = "file-too-large",
    TOO_MANY_FILES = "too-many-files",
    FILE_INVALID_TYPE = "file-invalid-type",
    OTHER = "other"
}
export interface DropzoneError {
    type: DropzoneErrorType;
    message: string;
    rejectedFiles: FileRejection[];
}
export type DropzoneProps = {
    title?: string;
    description?: string;
    separatorText?: string;
    maxSize?: number;
    maxFiles?: number;
    accept?: Record<string, string[]>;
    acceptText?: string;
    isError?: boolean;
    errorText?: string;
    dragFileText?: string;
    buttonText?: string;
    uploadMethod?: UploadMethod;
    uploadLink?: string;
    customFileStatuses?: FileStatus[];
    customDropHandler?: (files: File[]) => void;
    onFileDelete?: (file: any, deleteUICallback: () => void) => void;
    onFileRefresh?: (file: FileStatus) => void;
    /**
     * Handler вызывается при клике на загруженный файл
     * Может использоваться для открытия превью или скачивания файла
     */
    onFileClick?: (file: FileStatus) => void;
    handleSuccessDrop?: (data: any) => void;
    /**
     * @deprecated Use onDropRejected instead for better error handling with error types
     */
    handleErrorDrop?: (data: any) => void;
    /**
     * Handler вызывается при ошибке загрузки файлов
     * Получает объект с типом ошибки, сообщением и отклоненными файлами
     */
    onDropRejected?: (error: DropzoneError) => void;
    /**
     * Handler для ошибок превышения размера файла
     * Если не указан, используется onDropRejected
     */
    onFileSizeError?: (error: DropzoneError) => void;
    /**
     * Handler для ошибок превышения количества файлов
     * Если не указан, используется onDropRejected
     */
    onFileCountError?: (error: DropzoneError) => void;
    disableImmediateUpload?: boolean;
    onUploadHandler?: (files: File | File[]) => void;
    /**
     * Скрыть красный прогресс-бар при ошибке загрузки (только текст ошибки)
     */
    hideErrorProgressBar?: boolean;
    isDisabled?: boolean;
    className?: string;
    style?: CSSProperties;
    'data-pw'?: string;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
export interface FileStatus {
    id: string;
    name: string;
    progress: number;
    status: 'failed' | 'uploading' | 'completed';
    img?: string;
}
export {};
