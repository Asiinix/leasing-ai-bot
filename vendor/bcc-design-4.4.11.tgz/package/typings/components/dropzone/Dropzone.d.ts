/// <reference types="react" />
import { DropzoneProps } from './Dropzone.type';
export declare const Dropzone: React.FC<DropzoneProps>;
