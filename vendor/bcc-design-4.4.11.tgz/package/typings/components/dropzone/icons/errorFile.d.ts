export declare const ErrorFile: () => import("react/jsx-runtime").JSX.Element;
