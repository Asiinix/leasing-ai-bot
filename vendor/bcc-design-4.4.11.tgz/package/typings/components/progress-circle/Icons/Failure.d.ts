import React from 'react';
export declare const Failure: React.MemoExoticComponent<(props: {
    size: number;
}) => import("react/jsx-runtime").JSX.Element>;
