/// <reference types="react" />
import { DesktopProgressCircleHandle, DesktopProgressCircleProps } from './DesktopProgressCircle.type';
export declare const DesktopProgressCircle: import("react").ForwardRefExoticComponent<DesktopProgressCircleProps & import("react").RefAttributes<DesktopProgressCircleHandle>>;
