import { HTMLAttributes } from 'react';
export type DesktopProgressCirclepropsSize = 's' | 'm' | 'l';
export interface DesktopCallbackPercentProps {
    percent: number | undefined;
}
export interface DesktopCallbackTimerProps {
    time: string;
    counterSeconds: number;
    intervalSeconds: number;
}
export type DesktopOnComleteProps = DesktopCallbackPercentProps | DesktopCallbackTimerProps;
export interface DesktopProgressCircleProps extends HTMLAttributes<HTMLDivElement> {
    percent?: number;
    textShow?: boolean;
    error?: boolean;
    success?: boolean;
    timer?: boolean;
    onComplete?: (props: DesktopOnComleteProps) => void;
    size?: DesktopProgressCirclepropsSize;
    interval?: number;
}
export interface DesktopProgressCircleHandle {
    resetCounter: () => void;
}
