import React from 'react';
type Props = {
    onClick?: () => void;
    className?: string;
};
export declare const CloseIcon: React.MemoExoticComponent<({ onClick, className }: Props) => import("react/jsx-runtime").JSX.Element>;
export {};
