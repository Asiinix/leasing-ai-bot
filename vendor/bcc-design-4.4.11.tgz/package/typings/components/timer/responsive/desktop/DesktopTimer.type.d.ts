import { TimerProps } from '../../Timer.type';
export type DesktopTimerProps = TimerProps;
