/// <reference types="react" />
export declare const DesktopTimer: import("react").ForwardRefExoticComponent<import("../../Timer.type").NativeProps & {
    type: import("../..").TimerType;
    size?: "sm" | "md" | "lg" | undefined;
    color?: string | undefined;
    'data-test-id'?: string | undefined;
    title?: import("react").ReactNode;
    deadline?: number | Date | undefined;
    lowTime?: number | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
