import React from 'react';
interface AnimatedNumberProps {
    value: string;
}
export declare const AnimatedNumber: React.FC<AnimatedNumberProps>;
export {};
