import React from 'react';
interface DigitRollerProps {
    digit: string;
}
export declare const DigitRoller: React.FC<DigitRollerProps>;
export {};
