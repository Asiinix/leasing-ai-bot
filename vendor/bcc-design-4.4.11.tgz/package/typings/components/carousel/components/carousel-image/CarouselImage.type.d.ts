import { CSSProperties, MouseEvent } from 'react';
export type CarouselImageProps = {
    index: number;
    src: string;
    alt?: string;
    className?: string;
    onClick?: (e: MouseEvent<HTMLDivElement>, index: number) => void;
    loading?: 'eager' | 'lazy';
    showZoom?: boolean;
    onZoomClick?: (index: number) => void;
    isLoading?: boolean;
    objectFit?: 'cover' | 'contain' | 'fill' | 'none' | 'scale-down';
    height?: CSSProperties['height'];
    borderRadius?: CSSProperties['borderRadius'];
    alignSlide?: CSSProperties['alignItems'];
};
