import React from 'react';
import type { CarouselImageProps } from './CarouselImage.type';
export declare const CarouselImage: React.MemoExoticComponent<({ src, alt, className, onClick, loading, showZoom, onZoomClick, index, objectFit, height, borderRadius, alignSlide, isLoading, }: CarouselImageProps) => import("react/jsx-runtime").JSX.Element>;
