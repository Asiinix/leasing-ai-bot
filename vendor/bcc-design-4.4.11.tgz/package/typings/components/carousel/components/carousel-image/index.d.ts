export { CarouselImage } from './CarouselImage';
export type { CarouselImageProps } from './CarouselImage.type';
