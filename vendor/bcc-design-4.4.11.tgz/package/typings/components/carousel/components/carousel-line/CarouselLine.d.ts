/// <reference types="react" />
import { CarouselLineProps } from './CarouselLine.type';
export declare const CarouselLine: import("react").MemoExoticComponent<({ handlers, thumbs, currentIndex, objectFit, disableScrollIntoView }: CarouselLineProps) => import("react/jsx-runtime").JSX.Element>;
