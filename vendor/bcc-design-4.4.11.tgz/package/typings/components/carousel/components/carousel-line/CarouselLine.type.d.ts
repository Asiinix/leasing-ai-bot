import { CSSProperties } from 'react';
import type { CarouselHandlers } from '../../../carousel';
export type CarouselLineProps = {
    thumbs: string[];
    handlers: CarouselHandlers;
    currentIndex: number;
    objectFit?: CSSProperties['objectFit'];
    disableScrollIntoView?: boolean;
};
