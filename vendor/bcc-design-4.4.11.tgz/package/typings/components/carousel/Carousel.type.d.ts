import { CSSProperties, ReactNode } from 'react';
type ContainerStyles = Omit<CSSProperties, 'position' | 'width' | 'maxWidth' | 'minWidth' | 'overflow'>;
export type CarouselProps = {
    /** Автоматическое пролистывание слайдов */
    autoPlay?: boolean;
    /** Интервал автоматического пролистывания (в миллисекундах)  */
    autoPlayInterval?: number;
    /** Количество одновременно видимых слайдов */
    visibleSlides?: number;
    /** Отступ между слайдами */
    slideGap?: number;
    /** Дочерние элементы карусели (обычно слайды) */
    children?: ReactNode;
    /** Показывать эффект затухания по краям карусели */
    showFade?: boolean;
    /** Колбэк, вызываемый при изменении состояния карусели */
    onStateUpdate?: (state: CarouselState) => void;
    /** Кастомные стили контейнера (исключая position, width, maxWidth, minWidth и overflow свойства) */
    containerStyles?: ContainerStyles;
    /** Test identifier for Playwright testing */
    'data-pw'?: string;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
};
export type CarouselState = {
    isSwiping: boolean;
    translateX: number;
    currentIndex: number;
    maxIndex: number;
    itemsCount: number;
    currentThumbIndex: number;
    maxThumbIndex: number;
    thumbsCount: number;
};
export type CarouselHandlers = {
    goToPrevious: (infinite?: boolean) => void;
    goToNext: (infinite?: boolean) => void;
    goToSlide: (index: number) => void;
    goToPreviousThumb: (infinite?: boolean) => void;
    goToNextThumb: (infinite?: boolean) => void;
    goToSlideThumb: (thumbIndex: number) => void;
};
export type CarouselStateAndProps = CarouselState & Required<Omit<CarouselProps, 'data-pw' | 'data-test-id'>> & Pick<CarouselProps, 'data-pw' | 'data-test-id'>;
export {};
