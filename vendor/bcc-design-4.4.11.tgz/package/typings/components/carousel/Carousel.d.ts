/// <reference types="react" />
import type { CarouselHandlers, CarouselProps } from './Carousel.type';
export declare const Carousel: import("react").ForwardRefExoticComponent<CarouselProps & import("react").RefAttributes<CarouselHandlers>>;
