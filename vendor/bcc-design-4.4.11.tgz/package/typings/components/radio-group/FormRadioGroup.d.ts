import React from 'react';
import { FormItemProps } from '../form';
import { RadioGroupProps } from './RadioGroup.type';
export type FormRadioGroupProps = RadioGroupProps & Omit<FormItemProps, 'render'>;
export declare const FormRadioGroup: React.ForwardRefExoticComponent<RadioGroupProps & Omit<FormItemProps, "render"> & React.RefAttributes<HTMLInputElement>>;
