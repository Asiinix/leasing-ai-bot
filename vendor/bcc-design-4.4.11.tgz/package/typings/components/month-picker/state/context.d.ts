/// <reference types="react" />
import { CalendarBaseClass, type CalendarMonth } from '../../../utilities/dates/calendar';
export type MonthPickerStore = {
    currentYear: number;
    availableYears: number[];
    hoveredMonth: CalendarMonth | null;
    calendar: CalendarBaseClass;
    yearsWithMonths: CalendarBaseClass['yearsWithMonths'];
    currentMonths: CalendarBaseClass['yearsWithMonths'][number]['months'];
};
declare const Provider: ({ children, dynamicState }: {
    children: import("react").ReactNode;
    dynamicState?: MonthPickerStore | undefined;
}) => import("react/jsx-runtime").JSX.Element, useStore: <SelectorOutput>(selector: (store: MonthPickerStore) => SelectorOutput) => [SelectorOutput, (value: Partial<MonthPickerStore>) => void];
export { Provider as MonthPickerProvider, useStore as useMonthPickerStore };
export declare const createMonthPickerStore: (calendar: CalendarBaseClass) => MonthPickerStore;
