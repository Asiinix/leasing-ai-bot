import { CSSProperties, ReactNode } from 'react';
import { CalendarDayModifications, WeekdayStart } from '../../utilities/dates/calendar';
import { SupportedCalendarLocales } from '../../utilities/dates/calendar/calendar-base-class.type';
import { Nullable } from '../../utilities/types/utility-types';
export type CalendarValueSingle = Nullable<Date>;
export type CalendarChangeEventSingle = {
    value: CalendarValueSingle;
};
export type CalendarValueRange = [Nullable<Date>, Nullable<Date>];
export type CalendarChangeEventRange = {
    value: CalendarValueRange;
};
export type CalendarValue = CalendarValueSingle | CalendarValueRange;
export type CalendarChangeEvent = CalendarChangeEventSingle | CalendarChangeEventRange;
export type CalendarRefType = {
    scrollIntoValueMonth: () => void;
};
export type CalendarChangeHandler = (data: CalendarChangeEvent) => void;
export type CalendarProps = {
    /** Минимальная дата календаря */
    minDate?: string | Date;
    /** Максимальная дата календаря */
    maxDate?: string | Date;
    /**
     * Ограничение периода относительно текущего дня:
     * - `past` — доступны только прошедшие даты и сегодня (будущее задизейблено);
     * - `future` — доступны только сегодня и будущие даты (прошлое задизейблено).
     * Пересекается с minDate/maxDate (ужимает диапазон).
     */
    period?: 'past' | 'future';
    /** Начало недели начинается с пн/вс (0: вс, 1: пн) */
    weekStart?: WeekdayStart;
    /** Смежные месяцы */
    siblingMonths?: boolean;
    /**
     * @deprecated С 4.2.0 десктопный календарь показывает один месяц, а месяц и год выбираются в шапке.
     * Список месяцев остался только в мобильном режиме `adaptive`. Проп будет удалён в следующем мажорном релизе.
     */
    withMonthsList?: boolean;
    /**
     * @deprecated Селект года в списке месяцев работает только в режиме `adaptive` вместе с `withMonthsList`;
     * на десктопе выбор года всегда доступен в шапке. Проп будет удалён в следующем мажорном релизе.
     */
    withYearSelect?: boolean;
    /** Является ли лейбл месяца sticky (только в режиме adaptive) */
    stickyMonthLabel?: boolean;
    /** Скроллиться в месяц текущей даты при открытии (только в режиме adaptive) */
    scrollIntoCurrentMonth?: boolean;
    /** Можно ли выбирать период. Если да, то value = [Date | null, Date | null], если нет: Date | null */
    isRange?: boolean;
    /** Значение, принимает: Date | null или [Date | null, Date | null] в зависимости от пропсы isRange */
    value?: CalendarValue;
    /** Обработчик события. Реагирует на проп isRange и прокидывает соответсвующий value */
    onChange?: CalendarChangeHandler;
    /**
     * Обработчик события при нажатии на календарный день. Не реагирует на проп isRange.
     * Хорошо подходит если нужно прописать свою логику выбора дат.
     * */
    onDaySelect?: (selectedDate: Date) => void;
    /** Header компонент */
    header?: ReactNode;
    /** Footer компонент  */
    footer?: ReactNode;
    /** Локализация: ru | en | kk | zh  */
    locale?: SupportedCalendarLocales;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
    /** Высота */
    height?: CSSProperties['height'];
    /** Мобильный режим: прежняя вёрстка с вертикальным скроллом месяцев и без hover-эффектов */
    adaptive?: boolean;
    /** Показывать ли дни недели */
    showWeekdays?: boolean;
    /** Стили */
    style?: CSSProperties;
    /** Отключены ли выходные для выбора (только при isRange={false}) */
    disableWeekends?: boolean;
    /** Модификаторы дня */
    dayModifiers?: CalendarDayModifications;
    dayClassName?: string;
};
