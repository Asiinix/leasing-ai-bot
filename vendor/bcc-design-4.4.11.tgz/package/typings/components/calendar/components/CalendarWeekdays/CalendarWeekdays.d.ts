/// <reference types="react" />
import { CalendarWeekday } from '../../../../utilities/dates/calendar';
type CalendarWeekdaysProps = {
    weekdays: CalendarWeekday[];
    showWeekdays: boolean;
    'data-pw'?: string;
};
export declare const CalendarWeekdays: import("react").MemoExoticComponent<(props: CalendarWeekdaysProps) => import("react/jsx-runtime").JSX.Element | null>;
export {};
