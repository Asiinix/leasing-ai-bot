import React from 'react';
type Props = {
    onClick?: () => void;
    open: boolean;
};
export declare const CalendarYearSelect: React.MemoExoticComponent<({ onClick, open }: Props) => import("react/jsx-runtime").JSX.Element>;
export {};
