/// <reference types="react" />
type CalendarMonthsListProps = {
    scrollIntoCurrentMonth?: boolean;
    'data-pw'?: string;
};
export declare const CalendarMonthsList: import("react").MemoExoticComponent<({ scrollIntoCurrentMonth, "data-pw": dataPw }: CalendarMonthsListProps) => import("react/jsx-runtime").JSX.Element>;
export {};
