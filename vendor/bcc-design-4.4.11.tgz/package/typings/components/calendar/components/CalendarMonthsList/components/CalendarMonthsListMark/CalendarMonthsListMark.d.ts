/// <reference types="react" />
export declare const CalendarMonthsListMark: import("react").MemoExoticComponent<() => import("react/jsx-runtime").JSX.Element>;
