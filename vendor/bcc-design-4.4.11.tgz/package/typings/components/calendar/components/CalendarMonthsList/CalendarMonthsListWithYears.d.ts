/// <reference types="react" />
export declare const CalendarMonthsListWithYears: import("react").MemoExoticComponent<(_: any) => import("react/jsx-runtime").JSX.Element>;
