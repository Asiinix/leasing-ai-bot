/// <reference types="react" />
import { CalendarMonth as CalendarMonthType } from '../../../../utilities/dates/calendar';
type CalendarMonthProps = {
    show: boolean | undefined;
    adaptive: boolean;
    month: CalendarMonthType;
    startDate: Date | null;
    endDate: Date | null;
    showLabel: boolean;
    onDaySelect: (selectedDate: Date) => void;
    onDayMouseLeave: (hoveredDate: Date) => void;
    onDayMouseEnter: (hoveredDate: Date) => void;
    stickyMonthLabel: boolean;
    stickyTop?: number;
    'data-test-id'?: string;
};
export declare const CalendarMonth: import("react").MemoExoticComponent<(props: CalendarMonthProps) => import("react/jsx-runtime").JSX.Element | null>;
export {};
