/// <reference types="react" />
import { type CalendarDay as CalendarDayType } from '../../../../utilities/dates/calendar';
type CalendarDayAdaptiveProps = {
    day: CalendarDayType | false;
    onDaySelect: (selectedDate: Date) => void;
    isHovered: boolean;
    isStartDate: boolean;
    isEndDate: boolean;
    isRangeDay: boolean;
    isWeekend: boolean;
    isDisable: boolean;
    isStartOfWeek: boolean;
    isEndOfWeek: boolean;
};
export declare const CalendarDayAdaptive: import("react").MemoExoticComponent<(props: CalendarDayAdaptiveProps) => import("react/jsx-runtime").JSX.Element>;
export {};
