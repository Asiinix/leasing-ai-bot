/// <reference types="react" />
import { type CalendarDay as CalendarDayType } from '../../../../utilities/dates/calendar';
export type CalendarDayProps = {
    day: CalendarDayType | false;
    onDaySelect: (selectedDate: Date) => void;
    onDayMouseLeave: (hoveredDate: Date) => void;
    onDayMouseEnter: (hoveredDate: Date) => void;
    isHovered: boolean;
    isStartDate: boolean;
    isEndDate: boolean;
    isRangeDay: boolean;
    isWeekend: boolean;
    isDisable: boolean;
    isStartOfWeek: boolean;
    isEndOfWeek: boolean;
    className?: string;
};
export declare const CalendarDay: import("react").MemoExoticComponent<(props: CalendarDayProps) => import("react/jsx-runtime").JSX.Element>;
