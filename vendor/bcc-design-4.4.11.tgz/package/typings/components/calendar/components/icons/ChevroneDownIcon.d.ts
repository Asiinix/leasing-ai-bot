type Props = {
    className?: string;
};
export declare const ChevroneDownIcon: ({ className }: Props) => import("react/jsx-runtime").JSX.Element;
export {};
