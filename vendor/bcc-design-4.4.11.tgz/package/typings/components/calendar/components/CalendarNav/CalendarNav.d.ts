/// <reference types="react" />
export type CalendarNavItem = {
    key: string | number;
    label: string | number;
    selected?: boolean;
    disabled?: boolean;
    onSelect: () => void;
};
export type CalendarNavProps = {
    monthLabel: string;
    yearLabel: string | number;
    onPrev: () => void;
    onNext: () => void;
    prevDisabled?: boolean;
    nextDisabled?: boolean;
    monthItems?: CalendarNavItem[];
    monthMenuDataPw?: string;
    monthOpen?: boolean;
    onMonthOpenChange?: (isOpen: boolean) => void;
    yearItems?: CalendarNavItem[];
    yearMenuDataPw?: string;
    yearOpen?: boolean;
    onYearOpenChange?: (isOpen: boolean) => void;
    'data-pw'?: string;
};
export declare const CalendarNav: import("react").MemoExoticComponent<(props: CalendarNavProps) => import("react/jsx-runtime").JSX.Element>;
