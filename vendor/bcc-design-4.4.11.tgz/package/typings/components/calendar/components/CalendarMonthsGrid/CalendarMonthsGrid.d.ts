/// <reference types="react" />
import { Nullable } from '../../../../utilities/types/utility-types';
type CalendarMonthsGridProps = {
    startDate?: Nullable<Date>;
    endDate?: Nullable<Date>;
    onDaySelect: (selectedDate: Date) => void;
    scrollIntoCurrentMonth?: boolean;
    adaptive: boolean;
    showWeekdays: boolean;
    stickyMonthLabel: boolean;
    'data-test-id'?: string;
};
export declare const CalendarMonthsGrid: import("react").MemoExoticComponent<(props: CalendarMonthsGridProps) => import("react/jsx-runtime").JSX.Element>;
export {};
