/// <reference types="react" />
import { Nullable } from '../../../../utilities/types/utility-types';
type CalendarDaysViewProps = {
    startDate?: Nullable<Date>;
    endDate?: Nullable<Date>;
    onDaySelect: (selectedDate: Date) => void;
    adaptive: boolean;
    showWeekdays: boolean;
    'data-test-id'?: string;
};
/**
 * Десктопный вид календаря по новому макету: ОДИН месяц + шапка навигации
 * (`CalendarNav`), без вертикального скролла. Листание — стрелками шапки;
 * выбор месяца/года — через дропдауны со списком в шапке.
 */
export declare const CalendarDaysView: import("react").MemoExoticComponent<(props: CalendarDaysViewProps) => import("react/jsx-runtime").JSX.Element | null>;
export {};
