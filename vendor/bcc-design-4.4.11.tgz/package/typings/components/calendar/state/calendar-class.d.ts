import { Virtualizer } from '@tanstack/react-virtual';
import { CalendarBaseClass, CalendarDay, CalendarDaySettings, CalendarMonth, CalendarOptions, CalendarWeekday } from '../../../utilities/dates/calendar';
import { CalendarYearWithMonths } from '../../../utilities/dates/calendar/calendar-base-class.type';
import type { Nullable } from '../../../utilities/types/utility-types';
import { CalendarRefTypes, VisibleMonth } from './calendar-class.type';
export type CalendarState = {
    yearsWithMonths: CalendarYearWithMonths;
    months: CalendarMonth[];
    weekdays: CalendarWeekday[];
    visibleMonth: VisibleMonth;
    hoveredDate: Nullable<Date>;
};
type GridTableMap = Record<number, {
    list: number;
    grid: number;
    height: number;
}>;
export declare class CalendarClass {
    CalendarBase: Nullable<CalendarBaseClass>;
    options: CalendarOptions;
    state: CalendarState;
    monthsListRef: Nullable<HTMLDivElement>;
    monthsGridRef: Nullable<HTMLDivElement>;
    monthsGridTracker: Nullable<HTMLDivElement>;
    monthsGridTableMap: GridTableMap;
    virtualizer: Virtualizer<HTMLDivElement, Element>;
    constructor(options: Partial<CalendarOptions>);
    /** SETTERS */
    setRef(refType: CalendarRefTypes, ref: Nullable<HTMLDivElement>): void;
    setVirtualizer(virt: Virtualizer<HTMLDivElement, Element>): void;
    setVisibleMonth(index: number): void;
    setHoveredDate(newDate: Nullable<Date>): void;
    /** internal */
    private calculateMonthsHeight;
    getCalendarDaySettings: (data: {
        day: false | CalendarDay;
        endDate: Nullable<Date>;
        startDate: Nullable<Date>;
    }) => CalendarDaySettings;
    /** MODIFIERS */
    applyDayModification(date: Date, dateSettings: CalendarDaySettings): CalendarDaySettings;
    /** SCROLL */
    moveList(index: number, type: 'top' | 'bottom', behavior?: 'smooth' | 'instant'): void;
    moveGrid(index: number, behavior?: 'smooth' | 'auto'): void;
    /**
     * Скроллит сетку месяцев (справа) в нужный месяц.
     * Если не прокидывать дату, скроллит в текущий месяц.
     * */
    scrollGridIntoMonth(scrollToDate: Date, behavior?: 'smooth' | 'auto'): void;
    /**
     * Скроллит список месяцев (слева) в нужный месяц, если withYearSelect={false}
     * */
    setInitialMonthListScrollTopPosition(): void;
    /** HELPERS */
    /**
     * Находит monthIndex для даты, если дату не передавать то найдет ее для текущего дня.
     * */
    private findMonthIndex;
    getScrollTopValue: (key: 'list' | 'grid', index: number) => number;
    getMonthHeight(index: number): number;
    isBeforeMinDate(date: Date): boolean;
    isAfterMaxDate(date: Date): boolean;
}
export {};
