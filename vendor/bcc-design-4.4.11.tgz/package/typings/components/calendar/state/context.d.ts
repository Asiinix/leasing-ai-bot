/// <reference types="react" />
import type { CalendarOptions } from '../../../utilities/dates/calendar';
import type { CalendarProps } from '../Calendar.type';
import { CalendarClass, CalendarState } from './calendar-class';
export type CalendarStoreState = CalendarState & {
    calendar: CalendarClass;
    props: Partial<CalendarProps>;
};
declare const Provider: ({ children, dynamicState }: {
    children: import("react").ReactNode;
    dynamicState?: CalendarStoreState | undefined;
}) => import("react/jsx-runtime").JSX.Element, useStore: <SelectorOutput>(selector: (store: CalendarStoreState) => SelectorOutput) => [SelectorOutput, (value: Partial<CalendarStoreState>) => void];
export { Provider as CalendarProvider, useStore as useCalendar };
export declare const createCalendarStore: (options: Partial<CalendarOptions>, props: Partial<CalendarProps>) => CalendarStoreState;
