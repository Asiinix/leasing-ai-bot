import { CalendarMonth } from '../../../utilities/dates/calendar';
export type CalendarRefTypes = 'monthsListRef' | 'monthsGridRef' | 'monthGridTracker';
export type VisibleMonth = {
    index: number;
    month: CalendarMonth;
};
