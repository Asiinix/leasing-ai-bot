/// <reference types="react" />
import { CalendarProps, CalendarRefType } from './Calendar.type';
export declare const Calendar: import("react").MemoExoticComponent<import("react").ForwardRefExoticComponent<CalendarProps & import("react").RefAttributes<CalendarRefType>>>;
