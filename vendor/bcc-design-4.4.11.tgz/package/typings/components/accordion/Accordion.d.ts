/// <reference types="react" />
export declare const Accordion: import("react").ForwardRefExoticComponent<import("./Accordion.type").NativeProps & {
    title?: import("react").ReactNode;
    caption?: string | undefined;
    paymentTitle?: string | undefined;
    paymentContentTitle?: string | undefined;
    type?: "default" | "payment" | undefined;
    variant?: string | undefined;
    items?: import("./Accordion.type").AccordionItemProps[] | undefined;
    chips?: import("../chip").ChipProps[] | undefined;
    onChipItemClick?: ((chip: import("../chip").ChipProps) => void) | undefined;
    disableImages?: boolean | undefined;
    closeOthersOnClick?: boolean | undefined;
    enableFeedback?: boolean | undefined;
    feedbackType?: "default" | "reason_why" | undefined;
    positiveFeedbackPercentage?: number | undefined;
    positiveFeedbackCallback?: ((id: string) => void) | undefined;
    negativeFeedbackCallback?: ((id: string) => void) | undefined;
    sendFeedbackHandler?: ((id: string, feedback: string) => void) | undefined;
    children?: import("react").ReactNode;
    childrenRef?: import("react").LegacyRef<HTMLSpanElement> | undefined;
    styles?: import("react").CSSProperties | undefined;
    'data-test-id'?: string | undefined;
    compact?: boolean | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
