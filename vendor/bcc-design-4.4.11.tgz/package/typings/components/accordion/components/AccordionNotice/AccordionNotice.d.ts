export declare const AccordionNotice: ({ index, children, title, contentTitle, variant, fullWidth, disableTruncate, }: {
    index?: number | undefined;
    children: any;
    title?: string | undefined;
    contentTitle?: string | undefined;
    variant?: string | undefined;
    fullWidth?: boolean | undefined;
    disableTruncate?: boolean | undefined;
}) => import("react/jsx-runtime").JSX.Element;
