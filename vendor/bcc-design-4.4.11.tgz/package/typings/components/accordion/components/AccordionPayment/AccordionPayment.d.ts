export declare const AccordionPayment: ({ id, index, title, subTitle, descriptionTitle, detail, image, disableImages, enableFeedback, feedbackType, positiveFeedbackPercentage, positiveFeedbackCallback, negativeFeedbackCallback, sendFeedbackHandler, accordionsState, handleAccordionClick, }: {
    id: any;
    index: any;
    title: any;
    subTitle: any;
    descriptionTitle: any;
    detail: any;
    image: any;
    disableImages: any;
    enableFeedback: any;
    feedbackType: any;
    positiveFeedbackPercentage: any;
    positiveFeedbackCallback: any;
    negativeFeedbackCallback: any;
    sendFeedbackHandler: any;
    accordionsState: any;
    handleAccordionClick: any;
}) => import("react/jsx-runtime").JSX.Element;
