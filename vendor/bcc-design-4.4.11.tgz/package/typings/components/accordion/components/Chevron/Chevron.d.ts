export declare const Chevron: ({ isActive, style }: {
    isActive: any;
    style?: {} | undefined;
}) => import("react/jsx-runtime").JSX.Element;
