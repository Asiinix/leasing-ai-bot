export declare const FeedbackSection: ({ id, feedbackType, positiveFeedbackPercentage, positiveFeedbackCallback, negativeFeedbackCallback, sendFeedbackHandler, feedback, setFeedback, }: {
    id: any;
    feedbackType: any;
    positiveFeedbackPercentage: any;
    positiveFeedbackCallback: any;
    negativeFeedbackCallback: any;
    sendFeedbackHandler: any;
    feedback: any;
    setFeedback: any;
}) => import("react/jsx-runtime").JSX.Element;
