/// <reference types="react" />
export declare const AccordionMobile: import("react").ForwardRefExoticComponent<import("./AccordionMobile.type").NativeProps & {
    title?: string | undefined;
    caption?: string | undefined;
    items?: import("./AccordionMobile.type").AccordionMobileItemProps[] | undefined;
    closeOthersOnClick?: boolean | undefined;
    disableImages?: boolean | undefined;
    enableFeedback?: boolean | undefined;
    feedbackType?: "default" | "reason_why" | undefined;
    positiveFeedbackPercentage?: number | undefined;
    positiveFeedbackCallback?: ((id: string) => void) | undefined;
    negativeFeedbackCallback?: ((id: string) => void) | undefined;
    sendFeedbackHandler?: ((id: string, feedback: string) => void) | undefined;
    children?: import("react").ReactNode;
    childrenRef?: import("react").LegacyRef<HTMLSpanElement> | undefined;
    styles?: import("react").CSSProperties | undefined;
    'data-test-id'?: string | undefined;
    compact?: boolean | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
