import React, { CSSProperties, HTMLAttributes, LegacyRef, ReactNode } from 'react';
import { AccordionLink } from '../../Accordion.type';
export interface AccordionMobileItemProps {
    id: string;
    title: ReactNode;
    detail: ReactNode;
    image?: string;
    customContent?: ReactNode;
    /**
     * Отдельная ссылка-кнопка под текстом ответа
     */
    link?: AccordionLink;
    /**
     * Дата обновления, рендерится как «Обновлено {updatedDate}»
     */
    updatedDate?: string;
}
export type NativeProps = HTMLAttributes<HTMLDivElement>;
export type AccordionMobileProps = NativeProps & {
    /**
     * Заголовок компонента
     */
    title?: string;
    /**
     * Подпись под заголовком
     */
    caption?: string;
    /**
     * Размеры компонента
     */
    items?: AccordionMobileItemProps[];
    /**
     * Скрытие остальных элементов при клике на активный
     */
    closeOthersOnClick?: boolean;
    /**
     * Отключение опции отображения изображений
     */
    disableImages?: boolean;
    /**
     * Включение опции обратной связи
     */
    enableFeedback?: boolean;
    /**
     * Вариант отображения обратной связи
     */
    feedbackType?: 'default' | 'reason_why';
    /**
     * Процент положительной обратной связи
     */
    positiveFeedbackPercentage?: number;
    /**
     * Коллбек на положительную обратную связь
     */
    positiveFeedbackCallback?: (id: string) => void;
    /**
     * Коллбек на отрицательную обратную связь
     */
    negativeFeedbackCallback?: (id: string) => void;
    /**
     * Коллбек на отправку отрицательной обратной связи
     */
    sendFeedbackHandler?: (id: string, feedback: string) => void;
    /**
     * Содержимое компонента BadgeProps
     */
    children?: React.ReactNode;
    /**
     * ref на children
     */
    childrenRef?: LegacyRef<HTMLSpanElement> | undefined;
    /**
     * Основные стили компонента
     */
    styles?: CSSProperties;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
    /**
     * Компактный вариант отображения с уменьшенными отступами и размерами
     */
    compact?: boolean;
};
