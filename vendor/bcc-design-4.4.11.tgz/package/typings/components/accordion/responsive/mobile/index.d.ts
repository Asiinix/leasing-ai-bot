export * from './AccordionMobile';
export type { AccordionMobileProps, AccordionMobileItemProps } from './AccordionMobile.type';
