export * from './AccordionDesktop';
export type { AccordionDesktopProps, AccordionDesktopItemProps } from './AccordionDesktop.type';
