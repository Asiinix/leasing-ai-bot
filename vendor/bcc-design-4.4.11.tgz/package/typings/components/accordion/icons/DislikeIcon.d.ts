export declare const DislikeIcon: () => import("react/jsx-runtime").JSX.Element;
