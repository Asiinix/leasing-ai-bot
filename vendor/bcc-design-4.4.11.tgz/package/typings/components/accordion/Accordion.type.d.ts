import React, { CSSProperties, HTMLAttributes, LegacyRef, ReactNode } from 'react';
import { ChipProps } from '../chip/Chip.type';
export interface AccordionLink {
    /**
     * Текст ссылки
     */
    text: string;
    /**
     * Адрес ссылки
     */
    href: string;
}
export interface AccordionItemProps {
    id: string;
    title: ReactNode;
    detail: ReactNode;
    image?: string;
    customContent?: ReactNode;
    /**
     * Отдельная ссылка-кнопка под текстом ответа
     */
    link?: AccordionLink;
    /**
     * Дата обновления, рендерится как «Обновлено {updatedDate}»
     */
    updatedDate?: string;
}
export type NativeProps = HTMLAttributes<HTMLDivElement>;
export type AccordionProps = NativeProps & {
    /**
     * Заголовок компонента
     */
    title?: string | React.ReactNode;
    /**
     * Подпись под заголовком в компактном варианте
     */
    caption?: string;
    /**
     * Заголовок компонента для варианта payment
     */
    paymentTitle?: string;
    /**
     * Заголовок компонента для варианта payment, для контентной его части
     */
    paymentContentTitle?: string;
    /**
     * Описание над заголовком
     */
    /**
     * Тип отображения компонента
     */
    type?: 'default' | 'payment';
    /**
     * Если выбран @type=payment, то будет доступен пропс variant
     */
    variant?: 'success' | 'warning' | 'error' | 'info' | string;
    /**
     * Размеры компонента
     */
    items?: AccordionItemProps[];
    /**
     * Массив для компонента Chips
     */
    chips?: ChipProps[];
    /**
     * Обработчик клика по чипу
     */
    onChipItemClick?: (chip: ChipProps) => void;
    /**
     * Отключение опции отображения изображений
     */
    disableImages?: boolean;
    /**
     * Скрытие остальных элементов при клике на активный
     */
    closeOthersOnClick?: boolean;
    /**
     * Включение опции обратной связи
     */
    enableFeedback?: boolean;
    /**
     * Вариант отображения обратной связи
     */
    feedbackType?: 'default' | 'reason_why';
    /**
     * Процент положительной обратной связи
     */
    positiveFeedbackPercentage?: number;
    /**
     * Коллбек на положительную обратную связь
     */
    positiveFeedbackCallback?: (id: string) => void;
    /**
     * Коллбек на отрицательную обратную связь
     */
    negativeFeedbackCallback?: (id: string) => void;
    /**
     * Коллбек на отправку отрицательной обратной связи
     */
    sendFeedbackHandler?: (id: string, feedback: string) => void;
    /**
     * Содержимое компонента BadgeProps
     */
    children?: React.ReactNode;
    /**
     * ref на children
     */
    childrenRef?: LegacyRef<HTMLSpanElement> | undefined;
    /**
     * Основные стили компонента
     */
    styles?: CSSProperties;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
    /**
     * Компактный вариант отображения с уменьшенными отступами и размерами
     */
    compact?: boolean;
};
