import { HeaderButtonIconProps } from './HeaderButtonIcon.type';
/**
 * Иконка-кнопка для правой части Desktop-хедера.
 *
 * Нативная кнопка 36×36px с белым фоном и опциональным Badge в правом верхнем углу.
 * Outer wrapper имеет padding: 2px 0, чтобы Badge мог «выглядывать» за пределы контейнера.
 *
 * Состояния:
 * - static:   белый фон (#fff / weak-0)
 * - hovered:  серый фон  (#d8d9de / weak-200)
 * - pressed:  тёмно-серый (#bdbec3 / weak-300)
 * - focused:  белый + 4px синяя рамка (#458aff / focus-strong-500)
 * - disabled: серый фон, иконка затемнена, Badge скрыт
 */
export declare const HeaderButtonIcon: ({ icon, badge, onClick, disabled, "data-pw": dataPw, }: HeaderButtonIconProps) => import("react/jsx-runtime").JSX.Element;
