import { HeaderItemProps } from './HeaderItem.type';
/**
 * Информационный блок хедера.
 *
 * Компоновка (слева направо):
 *   [avatar | icon-container?]  [text: subtitle + title]  [chevron?]  [menu?]
 *
 * Высота: 40px (выравнивается по центру родителя).
 * Минимальная ширина: 150px.
 */
export declare const HeaderItem: ({ subtitle, title, avatar, icon, chevronIcon, menuIcon, isChevronOpen, onChevronClick, onMenuClick, className, "data-pw": dataPw, }: HeaderItemProps) => import("react/jsx-runtime").JSX.Element;
