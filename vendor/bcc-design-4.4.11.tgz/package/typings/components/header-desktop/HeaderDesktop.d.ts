/// <reference types="react" />
/**
 * Desktop-хедер для приложений Банка ЦентрКредит.
 *
 * Горизонтальная полоска (64px высота, bg-weak-50, border-bottom).
 * Правая часть всегда содержит блок пользователя и кнопки действий.
 * Левая часть зависит от `type`.
 *
 * @example
 * ```tsx
 * <HeaderDesktop
 *   type="default"
 *   leftItems={[
 *     { subtitle: 'На KZT счетах', title: '392 450 000,59 ₸', icon: <Kzt /> },
 *     { subtitle: 'Бонусы', title: '392 450 000 Б', icon: <Zap /> },
 *   ]}
 *   userAvatar={<Avatar type="picture" imgSrc="..." size="xl" />}
 *   userSubtitle="АО «Банк ЦентрКредит»"
 *   userTitle="Акылбай Серик М."
 *   userChevronIcon={<ChevronDirectionDown />}
 *   userMenuIcon={<MenuKebab />}
 *   onUserChevronClick={() => setOpen(true)}
 *   actionButtons={[{ icon: <Bell />, badge: 5, onClick: () => {} }]}
 * />
 * ```
 */
export declare const HeaderDesktop: import("react").ForwardRefExoticComponent<import("react").HTMLAttributes<HTMLElement> & {
    'data-pw'?: string | undefined;
    type?: import("./HeaderDesktop.type").HeaderDesktopType | undefined;
    leftItems?: import("./HeaderDesktop.type").HeaderDesktopItem[] | undefined;
    title?: string | undefined;
    caption?: string | undefined;
    leftContent?: import("react").ReactNode;
    userAvatar?: import("react").ReactNode;
    userSubtitle?: string | undefined;
    userTitle?: string | undefined;
    userChevronIcon?: import("react").ReactNode;
    userMenuIcon?: import("react").ReactNode;
    onUserChevronClick?: (() => void) | undefined;
    onUserMenuClick?: (() => void) | undefined;
    userDropdownContent?: import("react").ReactNode;
    isDropdownOpen?: boolean | undefined;
    actionButtons?: import("./HeaderDesktop.type").HeaderDesktopActionButton[] | undefined;
} & import("react").RefAttributes<HTMLElement>>;
