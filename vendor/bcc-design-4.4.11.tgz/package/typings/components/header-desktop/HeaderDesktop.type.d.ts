import { HTMLAttributes, ReactNode } from 'react';
/**
 * Тип варианта Desktop-хедера.
 *
 * - `default` — левая часть содержит финансовые блоки (счета, бонусы)
 * - `title`   — левая часть содержит заголовок страницы и опциональный caption
 * - `empty`   — левая часть отсутствует, только правая (пользователь + кнопки)
 * - `custom`  — левая часть содержит произвольный React-контент через `leftContent`
 */
export type HeaderDesktopType = 'default' | 'title' | 'empty' | 'custom';
/**
 * Информационный блок для левой части хедера (тип `default`).
 * Содержит иконку в белом контейнере, subtitle и title.
 */
export interface HeaderDesktopItem {
    /**
     * Подзаголовок блока (серый текст).
     * Например: «На KZT счетах», «Бонусы»
     */
    subtitle?: string;
    /**
     * Основной текст блока (тёмный текст).
     * Например: «392 450 000,59 ₸»
     */
    title: string;
    /**
     * Иконка в белом контейнере 36×36px (20×20px SVG внутри).
     */
    icon?: ReactNode;
}
/**
 * Кнопка-действие в правой части хедера.
 * Рендерится как нативная кнопка 36×36px с иконкой и опциональным Badge.
 */
export interface HeaderDesktopActionButton {
    /**
     * Иконка кнопки (20×20px SVG).
     */
    icon: ReactNode;
    /**
     * Обработчик клика.
     */
    onClick?: () => void;
    /**
     * Число для Badge (view="count").
     * Если не передано — Badge не рендерится.
     * Значения ≥100 отображаются как «99+».
     */
    badge?: number;
    /**
     * Отключённое состояние кнопки.
     *
     * @default false
     */
    disabled?: boolean;
    /**
     * Тестовый идентификатор для Playwright.
     */
    'data-pw'?: string;
}
/**
 * Пропсы Desktop-хедера.
 */
export type HeaderDesktopProps = HTMLAttributes<HTMLElement> & {
    /**
     * Тестовый идентификатор для Playwright.
     *
     * @default 'header-desktop'
     */
    'data-pw'?: string;
    /**
     * Вариант хедера.
     *
     * @default 'default'
     */
    type?: HeaderDesktopType;
    /**
     * Информационные блоки в левой части (тип `default`).
     * По умолчанию 2 блока: KZT-счета и Бонусы.
     */
    leftItems?: HeaderDesktopItem[];
    /**
     * Заголовок страницы (тип `title`).
     * Шрифт: 16px semibold.
     */
    title?: string;
    /**
     * Дополнительный caption под заголовком (тип `title`).
     * Шрифт: 14px regular, серый цвет.
     */
    caption?: string;
    /**
     * Произвольный контент в левой части (тип `custom`).
     * Высота контейнера ограничена 40px.
     */
    leftContent?: ReactNode;
    /**
     * Аватар пользователя (ReactNode) для блока пользователя.
     * Рекомендуется использовать `<Avatar>` компонент.
     * Отображается как 36×36px, круглая форма задаётся снаружи через CSS.
     */
    userAvatar?: ReactNode;
    /**
     * Подзаголовок блока пользователя (название организации).
     * Например: «АО «Банк ЦентрКредит»»
     */
    userSubtitle?: string;
    /**
     * Заголовок блока пользователя (имя пользователя).
     * Например: «Акылбай Серик М.»
     */
    userTitle?: string;
    /**
     * Иконка для chevron-кнопки в блоке пользователя.
     * Если не передана — кнопка не рендерится.
     */
    userChevronIcon?: ReactNode;
    /**
     * Иконка для menu-кнопки в блоке пользователя.
     * Если не передана — кнопка не рендерится.
     */
    userMenuIcon?: ReactNode;
    /**
     * Обработчик клика по chevron-кнопке блока пользователя.
     */
    onUserChevronClick?: () => void;
    /**
     * Обработчик клика по menu-кнопке блока пользователя.
     */
    onUserMenuClick?: () => void;
    /**
     * Контент dropdown-меню для блока пользователя (controlled).
     * Рендерится под блоком пользователя при `isDropdownOpen=true`.
     */
    userDropdownContent?: ReactNode;
    /**
     * Состояние открытия dropdown-меню пользователя (controlled).
     *
     * @default false
     */
    isDropdownOpen?: boolean;
    /**
     * Кнопки действий в правой части хедера (до 5 штук).
     * Каждая кнопка — нативный button 36×36px с иконкой и опциональным Badge.
     */
    actionButtons?: HeaderDesktopActionButton[];
};
