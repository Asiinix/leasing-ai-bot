/// <reference types="react" />
import ReactCrop from 'react-image-crop';
import { ImageCropProps } from './ImageCrop.type';
export interface ImageCropRef {
    container: HTMLDivElement | null;
    api: ReactCrop | null;
}
export declare const ImageCrop: import("react").ForwardRefExoticComponent<ImageCropProps & import("react").RefAttributes<ImageCropRef>>;
