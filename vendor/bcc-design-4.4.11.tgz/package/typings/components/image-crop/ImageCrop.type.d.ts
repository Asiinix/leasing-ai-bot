/// <reference types="react" />
import { PercentCrop, PixelCrop, type Crop } from 'react-image-crop';
export type ImageCropProps = {
    /** Ссылка на изображение */
    src?: string;
    /** Обрезка изображения */
    crop?: Crop;
    /** Соотношение сторон */
    aspect?: number;
    /** Минимальная ширина */
    minWidth?: number;
    /** Максимальная ширина */
    maxWidth?: number;
    /** Минимальная высота */
    minHeight?: number;
    /** Максимальная высота */
    maxHeight?: number;
    /** Отключение полностью */
    disabled?: boolean;
    /** Отключение изменения размеров и создания новых */
    locked?: boolean;
    /** Круглый кроп
     * @default false
     */
    circularCrop?: boolean;
    /** Обработчик начала перетаскивания */
    onDragStart?: (e: PointerEvent) => void;
    /** Обработчик завершения перетаскивания */
    onDragEnd?: (e: PointerEvent) => void;
    /** Обработчик завершения
     */
    onComplete?: (crop: Crop, percentCrop?: PercentCrop) => void;
    /** Обработчик изменения
     */
    onChange: (crop: PixelCrop, percentCrop: PercentCrop) => void;
    /** Идентификатор для систем автоматизированного тестирования */
    'data-test-id'?: string;
    /** Ref картинки */
    imageRef?: React.RefObject<HTMLImageElement>;
    /** Угол поворота картинки */
    rotation?: number;
    /** Отражение картинки */
    reflection?: {
        horizontal?: number;
        vertical?: number;
    };
    /** Стили для компонента */
    style?: React.CSSProperties;
    /** Атрибут data-pw для тестирования */
    'data-pw'?: string;
};
