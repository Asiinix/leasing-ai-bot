/// <reference types="react" />
import { UploaderProps } from '../../Uploader.type';
export declare const DesktopUploader: React.FC<UploaderProps>;
