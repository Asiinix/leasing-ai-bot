export declare const ImageUpload: ({ uploadedImage, onUpload, openEditModal, onPreview, openUploadPreview, onEdit, onDelete, crop, elementWidth, elementHeight, type, disablePreview, disableEdit, isMobileUpload, isError, style, }: {
    uploadedImage: any;
    onUpload: any;
    openEditModal: any;
    onPreview: any;
    openUploadPreview: any;
    onEdit: any;
    onDelete: any;
    crop: any;
    elementWidth: any;
    elementHeight: any;
    type?: string | undefined;
    disablePreview?: boolean | undefined;
    disableEdit?: boolean | undefined;
    isMobileUpload?: boolean | undefined;
    isError?: boolean | undefined;
    style?: {} | undefined;
}) => import("react/jsx-runtime").JSX.Element;
