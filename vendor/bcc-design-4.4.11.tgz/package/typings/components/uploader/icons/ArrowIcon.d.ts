export declare const DownArrowIcon: ({ color }: {
    color?: string | undefined;
}) => import("react/jsx-runtime").JSX.Element;
