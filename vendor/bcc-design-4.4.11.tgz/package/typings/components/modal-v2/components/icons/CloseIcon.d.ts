import React from 'react';
declare function Icon(): import("react/jsx-runtime").JSX.Element;
export declare const CloseIcon: React.MemoExoticComponent<typeof Icon>;
export {};
