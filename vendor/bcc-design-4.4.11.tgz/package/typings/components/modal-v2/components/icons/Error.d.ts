import React from 'react';
declare function Icon(): import("react/jsx-runtime").JSX.Element;
export declare const ErrorStatus: React.MemoExoticComponent<typeof Icon>;
export {};
