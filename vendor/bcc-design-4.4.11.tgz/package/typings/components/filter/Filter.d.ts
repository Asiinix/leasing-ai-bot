/// <reference types="react" />
import { FilterProps } from './Filter.type';
export declare const Filter: React.FC<FilterProps>;
