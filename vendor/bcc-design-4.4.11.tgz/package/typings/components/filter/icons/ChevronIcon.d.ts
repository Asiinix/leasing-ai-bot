export declare const ChevronIcon: () => import("react/jsx-runtime").JSX.Element;
