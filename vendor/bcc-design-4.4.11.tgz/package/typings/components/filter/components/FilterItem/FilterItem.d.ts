export declare const FilterItem: (props: any) => import("react/jsx-runtime").JSX.Element;
