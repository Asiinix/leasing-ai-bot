export declare const FilterChip: (props: any) => import("react/jsx-runtime").JSX.Element;
