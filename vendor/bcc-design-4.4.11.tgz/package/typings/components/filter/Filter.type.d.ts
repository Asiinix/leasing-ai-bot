import React, { CSSProperties, HTMLAttributes, LegacyRef } from 'react';
import { ChipProps } from '../chip';
import { SelectOptionType } from '../select/components/SelectOption';
import { SelectDropdownMenuProps } from '../select/components/SelectDropdownMenu/SelectDropdownMenu.type';
export type NativeProps = HTMLAttributes<HTMLUListElement>;
export interface SortableListItem {
    name: string;
    label: string;
    selected: boolean;
}
type TypesToOmit = 'shape' | 'size' | 'onClick' | 'children' | 'checked';
type ChipItemForFilters = Omit<ChipProps, TypesToOmit>;
type FilterTypes = {
    name?: string;
    label?: string;
    labelCounter?: string;
    filterType?: 'sortable' | 'filter' | 'tab' | 'select';
    filterState: any;
    sortableList?: SortableListItem[];
    filterComponent?: any;
    rootComponent?: any;
    filterComponentProps?: {
        [name: string]: any;
    };
    filterOptions?: SelectOptionType[];
    selectDropdownProps?: Partial<Omit<SelectDropdownMenuProps, 'options' | 'value' | 'onChange' | 'onSelect' | 'onDeselect'>>;
    filterValueKey?: string;
    filterFunctionKey?: string;
    showFilterState?: boolean;
    transformFilterStateToText?: (state: any) => string;
};
export type FilterItemProps = ChipItemForFilters & FilterTypes;
export type FilterProps = Omit<NativeProps, 'onClick'> & {
    /**
     * Массив объектов, содержащих информацию о фильтрах
     */
    items?: FilterItemProps[];
    /**
     * Обработчик фильтрации
     */
    handleFilterChange?: (name: string, data: any, callback: () => void) => void;
    /**
     * Обработчик установки данных фильтра - отвечает за обновление UI фильтра
     */
    setFilterData?: (data: any) => void;
    /**
     * Размер чипа
     */
    chipSize?: 's' | 'md';
    /**
     * Включить белый цвет для чипа
     */
    enableWhiteChip?: boolean;
    /**
     * Содержимое компонента Filter
     */
    children?: React.ReactNode;
    /**
     * ref на children
     */
    childrenRef?: LegacyRef<HTMLSpanElement> | undefined;
    /**
     * Основные стили компонента
     */
    styles?: CSSProperties;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
    /**
     * Атрибут data-pw для тестирования
     */
    'data-pw'?: string;
};
export {};
