/// <reference types="react" />
import { DesktopFilterProps } from './DesktopFilter.type';
export declare const DesktopFilter: React.FC<DesktopFilterProps>;
