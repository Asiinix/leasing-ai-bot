import React, { CSSProperties, HTMLAttributes, LegacyRef } from 'react';
import { BottomSheetProps } from '../../../bottom-sheet';
import { ChipProps } from '../../../chip';
import { SelectOptionType } from '../../../select/components/SelectOption';
import { SelectDropdownMenuProps } from '../../../select/components/SelectDropdownMenu/SelectDropdownMenu.type';
export type NativeProps = HTMLAttributes<HTMLUListElement>;
export interface SortableListItem {
    name: string;
    label: string;
    selected: boolean;
}
type TypesToOmit = 'shape' | 'size' | 'onClick' | 'children' | 'checked' | 'disabled';
type ChipItemForFilters = Omit<ChipProps, TypesToOmit>;
type FilterTypes = {
    label?: string;
    labelCounter?: string;
    filterType?: 'sortable' | 'filter' | 'tab' | 'select';
    filterState: any;
    sortableList?: SortableListItem[];
    filterComponent?: any;
    filterComponentProps?: {
        [name: string]: any;
    };
    filterOptions?: SelectOptionType[];
    selectDropdownProps?: Partial<Omit<SelectDropdownMenuProps, 'options' | 'value' | 'onChange' | 'onSelect' | 'onDeselect'>>;
    filterValueKey?: string;
    filterFunctionKey?: string;
};
export type DesktopFilterItemProps = ChipItemForFilters & FilterTypes;
export type DesktopFilterProps = Omit<NativeProps, 'onClick'> & {
    /**
     * Массив объектов, содержащих информацию о фильтрах
     */
    items?: DesktopFilterItemProps[];
    /**
     * Размер чипа
     */
    chipSize?: 's' | 'md';
    /**
     * Объект с параметрами для BottomSheet
     */
    bottomSheetProps?: BottomSheetProps;
    /**
     * Обработчик фильтрации
     */
    handleFilterChange?: (name: string, data: any, callback: () => void) => void;
    /**
     * Обработчик установки данных фильтра - отвечает за обновление UI фильтра
     */
    setFilterData?: (data: any) => void;
    /**
     * Включить белый цвет для чипа
     */
    enableWhiteChip?: boolean;
    /**
     * Содержимое компонента Filter
     */
    children?: React.ReactNode;
    /**
     * ref на children
     */
    childrenRef?: LegacyRef<HTMLSpanElement> | undefined;
    /**
     * Основные стили компонента
     */
    styles?: CSSProperties;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
    /**
     * Атрибут data-pw для тестирования
     */
    'data-pw'?: string;
};
export {};
