import React from 'react';
import { CommonButtonProps } from '../../Button.type';
export type ContainerElement = HTMLButtonElement | HTMLAnchorElement;
export declare const BaseButton: React.MemoExoticComponent<React.ForwardRefExoticComponent<CommonButtonProps & React.RefAttributes<HTMLButtonElement | HTMLAnchorElement>>>;
