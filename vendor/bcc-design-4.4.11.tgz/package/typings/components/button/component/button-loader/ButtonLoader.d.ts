import React from 'react';
import { ButtonProps } from '../../../button/Button.type';
export interface LoadingDotsProps extends Pick<ButtonProps, 'view'> {
    id?: string;
    size: 's' | 'm' | 'l' | 'xl' | string;
    disabled?: boolean;
}
export declare const ButtonLoader: React.FC<LoadingDotsProps>;
