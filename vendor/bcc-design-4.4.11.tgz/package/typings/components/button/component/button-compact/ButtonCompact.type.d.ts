import { ReactNode } from 'react';
import type { ButtonProps } from '../../Button.type';
export type ButtonCompactContentType = 'icon' | 'iconChevron' | 'textChevron';
export type ButtonCompactView = 'primary' | 'secondary' | 'tertiary' | 'neutral';
/** Размеры по Figma: s — 24px, m — 32px, l — 40px */
export type ButtonCompactSize = 's' | 'm' | 'l';
export type ButtonCompactProps = Omit<ButtonProps, 'size' | 'fullWidth' | 'view'> & {
    /** Тип контента кнопки */
    contentType?: ButtonCompactContentType;
    /** Вариант отображения (primary/secondary/tertiary) */
    compactView?: ButtonCompactView;
    /**
     * Размер кнопки по Figma: 's' — 24px, 'm' — 32px, 'l' — 40px.
     * Если не задан, сохраняется прежнее поведение (legacy ~36px).
     */
    size?: ButtonCompactSize;
    /** Иконка */
    icon?: ReactNode;
    /** Содержимое выпадающего списка */
    dropdownContent?: ReactNode;
    /** Состояние открытия dropdown (controlled) */
    isOpen?: boolean;
    /** Callback при изменении состояния dropdown */
    onOpenChange?: (isOpen: boolean) => void;
    /** Позиция dropdown относительно кнопки */
    dropdownPosition?: 'start' | 'center' | 'end';
    /** Расположение dropdown */
    dropdownPlacement?: 'top' | 'bottom';
};
