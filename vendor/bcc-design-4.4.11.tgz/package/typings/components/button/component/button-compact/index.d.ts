export { ButtonCompact } from './ButtonCompact';
export type { ButtonCompactProps, ButtonCompactContentType, ButtonCompactView } from './ButtonCompact.type';
