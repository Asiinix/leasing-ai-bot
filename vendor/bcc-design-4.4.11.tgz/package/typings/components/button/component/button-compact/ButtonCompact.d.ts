import React from 'react';
import { ButtonProps } from '../../Button.type';
import type { ButtonCompactSize, ButtonCompactView } from './ButtonCompact.type';
export declare const ButtonCompact: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<ButtonProps, "view" | "size" | "fullWidth"> & {
    contentType?: import("./ButtonCompact.type").ButtonCompactContentType | undefined;
    compactView?: ButtonCompactView | undefined;
    size?: ButtonCompactSize | undefined;
    icon?: React.ReactNode;
    dropdownContent?: React.ReactNode;
    isOpen?: boolean | undefined;
    onOpenChange?: ((isOpen: boolean) => void) | undefined;
    dropdownPosition?: "end" | "center" | "start" | undefined;
    dropdownPlacement?: "bottom" | "top" | undefined;
} & React.RefAttributes<HTMLButtonElement>>>;
