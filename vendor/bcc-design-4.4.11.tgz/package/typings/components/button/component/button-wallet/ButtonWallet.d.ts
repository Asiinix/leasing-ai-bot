import React from 'react';
export declare const ButtonWallet: React.MemoExoticComponent<React.ForwardRefExoticComponent<Omit<import("../..").ButtonProps, "children" | "view" | "size" | "htmlType" | "iconLeft"> & import("./ButtonWallet.type").NativeButtonWalletProps & React.RefAttributes<HTMLButtonElement>>>;
