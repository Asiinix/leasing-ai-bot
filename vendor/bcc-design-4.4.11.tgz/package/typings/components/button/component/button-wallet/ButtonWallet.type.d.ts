import type { ButtonProps } from '../../Button.type';
export type NativeButtonWalletProps = {
    /** Тип иконки */
    type?: 'button' | 'badge';
    /** Платформа */
    platform?: 'ios' | 'android' | 'auto';
    /** При type === 'badge', верхняя строка кнопки */
    subTitle?: string;
    /** Конкатенировать ли subTitle с children */
    concatSubtitle?: boolean;
    /** Смена типа на badge на мобильных устройствах */
    autoSize?: boolean;
    /** Дочерний компонент, только строка */
    children?: string;
};
export type ButtonWalletProps = Omit<ButtonProps, 'view' | 'size' | 'iconLeft' | 'htmlType' | 'children'> & NativeButtonWalletProps;
