import React from 'react';
export declare const GooglePay: React.MemoExoticComponent<() => import("react/jsx-runtime").JSX.Element>;
