import React from 'react';
export declare const ApplePay: React.MemoExoticComponent<() => import("react/jsx-runtime").JSX.Element>;
