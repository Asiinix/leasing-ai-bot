export { ApplePay } from './ApplePay';
export { GooglePay } from './GooglePay';
