import { BaseButton as Button } from './component/base-button';
export { Button };
