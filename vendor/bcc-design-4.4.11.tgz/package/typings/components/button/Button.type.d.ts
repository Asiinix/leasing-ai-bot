import { AnchorHTMLAttributes, ButtonHTMLAttributes, CSSProperties, FocusEventHandler, KeyboardEventHandler, MouseEventHandler, ReactNode } from 'react';
import { KeyboardKeys } from '../../utilities/keyboard';
export type ContainerElement = HTMLButtonElement | HTMLAnchorElement;
export declare enum EButtonVariant {
    NeutralFilled = "neutralFilled",
    NeutralFilledSecondary = "neutralFilledSecondary",
    AccentPrimary = "accentPrimary",
    AccentSecondary = "accentSecondary",
    AccentTertiary = "accentTertiary",
    Destructive = "destructive",
    DestructiveSecondary = "destructiveSecondary",
    DestructiveTertiary = "destructiveTertiary",
    InvertPrimary = "invertPrimary",
    InvertSecondary = "invertSecondary",
    InvertTertiary = "invertTertiary",
    WhitePrimary = "whitePrimary",
    WhiteSecondary = "whiteSecondary",
    WhiteTertiary = "whiteTertiary",
    Neutral = "neutral",
    Link = "link"
}
export type ButtonVariant = 'accentPrimary' | 'accentSecondary' | 'accentTertiary' | 'invertPrimary' | 'invertSecondary' | 'invertTertiary' | 'whitePrimary' | 'whiteSecondary' | 'whiteTertiary' | 'destructive' | 'destructiveSecondary' | 'destructiveTertiary' | 'neutral' | 'neutralFilled' | 'neutralFilledSecondary' | 'link';
export interface ButtonProps {
    /**
     * Уникальный id компонента
     */
    id?: string;
    /**
     * Определяет стиль кнопки
     */
    view?: ButtonVariant;
    /**
     * Определяет стиль кнопки
     */
    fullWidth?: boolean;
    /**
     * Определяет тип кнопки для работы с формой
     */
    htmlType?: 'button' | 'submit' | 'reset' | undefined;
    /**
     * Выводит ссылку в виде кнопки
     */
    href?: string;
    /**
     * Определяет размер кнопки
     */
    size?: 's' | 'm' | 'l' | 'xl';
    /**
     * Стилевое оформление для визуального выделения прогресса
     */
    loading?: boolean;
    /**
     * Неактивное состояние кнопки.
     * Состояние, при котором кнопка отображается, но недоступна для действий пользователя
     */
    disabled?: boolean;
    /**
     * Дополнительные инлайн стили
     */
    style?: CSSProperties;
    /**
     * Текст кнопки.
     */
    children?: ReactNode;
    /**
     * Набор клавиш, при нажатии на которые выставляется состояние `pressed`
     *
     * @default [Keys.SPACE, Keys.ENTER]
     */
    pressKeys?: KeyboardKeys[];
    /**
     * Обработчик события onKeyDown
     */
    onKeyDown?: KeyboardEventHandler<ContainerElement>;
    /**
     * Обработчик события `onKeyUp`
     */
    onKeyUp?: KeyboardEventHandler<ContainerElement>;
    /**
     * Обработчик клика на кнопку
     */
    onClick?: MouseEventHandler<ContainerElement>;
    /**
     * Дополнительный класс для кнопки
     */
    className?: string;
    /**
     * Дополнительный класс для кнопки
     */
    childWrapperClassName?: string;
    /**
     * Событие по своему действию похоже на `onClick` и возникает в момент нажатия кнопки мыши.
     * `onClick` в каком-то смысле является комбинацией событий `onMouseDown` и `onMouseUp`
     */
    onMouseDown?: MouseEventHandler<ContainerElement>;
    /**
     * Обработчик события `onMouseUp`
     */
    onMouseUp?: MouseEventHandler<ContainerElement>;
    /**
     * Обработчик события `onMouseLeave`
     */
    onMouseEnter?: MouseEventHandler<ContainerElement>;
    /**
     * Обработчик события `onMouseLeave`
     */
    onMouseLeave?: MouseEventHandler<ContainerElement>;
    /**
     * Обработчик события `onBlur`
     */
    onBlur?: FocusEventHandler<ContainerElement>;
    /**
     * Добавляет иконку с лева от текста кнопки
     */
    iconLeft?: ReactNode;
    /**
     * Добавляет иконку с права от текста кнопки
     */
    iconRight?: ReactNode;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    'data-test-id'?: string;
    /**
     * Playwright test identifier
     */
    'data-pw'?: string;
}
export type CommonButtonProps = ButtonProps & Partial<AnchorHTMLAttributes<HTMLAnchorElement> | ButtonHTMLAttributes<HTMLButtonElement>>;
