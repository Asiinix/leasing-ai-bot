export declare const getDarkMediaMatch: () => MediaQueryList | undefined;
