import { RealTheme } from '../types';
import type { BodyClassNameModifiers } from './updateBodyClassName';
export declare function getRootClassName(modifier?: Partial<BodyClassNameModifiers & {
    theme: RealTheme | boolean;
}>): string;
