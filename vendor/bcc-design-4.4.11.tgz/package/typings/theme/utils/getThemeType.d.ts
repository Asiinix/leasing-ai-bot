import { RealTheme } from '../types';
export declare function getThemeType(theme: RealTheme): "light" | "dark";
