import type { ThemeColorOptions, ThemeColorsConfig } from './themeGenerator.type';
export declare const createTheme: (name: string, settings: ThemeColorOptions) => ThemeColorsConfig;
export declare const DEFAULT_THEME_COLORS: ThemeColorOptions;
