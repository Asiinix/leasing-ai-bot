/// <reference types="react" />
import type { ThemeColorsConfig } from '../theming/themeGenerator.type';
type Props = {
    themeConfig?: ThemeColorsConfig | ThemeColorsConfig[] | undefined;
};
export declare const GeneratedThemeStyles: import("react").NamedExoticComponent<Props>;
export {};
