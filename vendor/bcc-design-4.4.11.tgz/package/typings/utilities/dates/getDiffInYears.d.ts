export declare function getDiffInYears(startDate: Date, endDate: Date): number;
