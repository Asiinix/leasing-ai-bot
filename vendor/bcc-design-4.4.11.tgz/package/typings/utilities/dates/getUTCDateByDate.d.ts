export declare const getUTCDateByDate: (date: Date) => Date;
