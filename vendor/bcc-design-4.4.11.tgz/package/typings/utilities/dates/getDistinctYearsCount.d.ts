export declare function getDistinctYearsCount(startDate: Date, endDate: Date): number;
