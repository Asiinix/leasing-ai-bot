import { CalendarDate, CalendarDay, CalendarMonth, CalendarOptions, CalendarWeekday, CalendarYearWithMonths, MonthIndex, SupportedCalendarLocales, WeekdayIndex } from './calendar-base-class.type';
export declare class CalendarBaseClass {
    options: CalendarOptions;
    months: CalendarMonth[];
    weekdays: CalendarWeekday[];
    yearsWithMonths: CalendarYearWithMonths;
    constructor(options: Partial<CalendarOptions>);
    /** CREATE */
    private createCalendar;
    private createCalendarMonths;
    private createCalendarMonthsWithYears;
    private createCalendarMonthsGroupedByYears;
    private createCalendarWeekdays;
    /** HELPERS */
    /**
     * Calculate a calendar month
     *
     * @param   year   Year
     * @param   month  Month [0-11]
     * @return         Calendar days
     */
    getCalendarMonth(year: number, month: MonthIndex): (false | CalendarDate)[];
    isDateWithinRange(minDate: Date, maxDate: Date, currentDate: Date): boolean;
    /** STATIC METHODS */
    /**
     * Calculates the number of days in a month
     *
     * @param   year  Year
     * @param   month Month [0-11]
     * @return        Length of the month
     */
    static daysInMonth(year: number, month: number): number;
    /**
     * Calculates the week number for a given date
     *
     * @param   date  Date object
     * @return        Week number
     */
    static calculateWeekNumber(date: CalendarDate): number;
    /** STATIC GETTERS HELPERS */
    static getUTCDateFromCalendarDay({ year, month, day }: CalendarDay, now?: Date): Date;
    static getDateStringFromCalendarDay({ year, month, day }: CalendarDay): string;
    static getMonthLabelByIndex(monthIndex: MonthIndex): string;
    static getWeekdayLabelByIndex(weekdayIndex: WeekdayIndex): string;
    static getMonthWeeks(monthDays: (CalendarDay | false)[]): (CalendarDay | false)[][];
    static getMonthListYears(months: CalendarMonth[]): number[];
    static getFirstDateOfMonth(month: CalendarMonth): Date;
    static getLastDateOfMonth(month: CalendarMonth): Date;
    /** LOCALE */
    static changeLocale(locale: SupportedCalendarLocales): void;
}
