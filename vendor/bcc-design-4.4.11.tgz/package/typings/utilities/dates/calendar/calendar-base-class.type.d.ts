import { Nullable } from '../../types/utility-types';
export type WeekdayStart = 0 | 1;
export type WeekdayIndex = 0 | 1 | 2 | 3 | 4 | 5 | 6;
export type MonthIndex = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11;
export type SupportedCalendarLocales = 'ru' | 'en' | 'kk' | 'zh';
export type CalendarOptions = {
    /** Минимальная дата календаря */
    minDate: Nullable<Date> | string;
    /** Максимальная дата календаря */
    maxDate: Nullable<Date> | string;
    /** Месяцы смежные */
    siblingMonths: boolean;
    /** Высчитывать ли weekDays */
    weekNumbers: boolean;
    /** Начало недели начинается с пн/вс (0: вс, 1: пн) */
    weekStart: WeekdayStart;
    /** Срезать ли начальные недели первого месяца календаря */
    cutPastWeeks: boolean;
    /** Период */
    isRange: boolean;
    /**
     * Если true - отдает доп. данные. Месяца с разбитием на года, поле yearsWithMonths в классе.
     *  Пример: {
     *    '2024': { months: [...] },
     *    '2025': { months: [...] },
     *    ...
     *  }
     * */
    withYearGroups: boolean;
    /** Дата откуда срезать недели (неделя с выбранной датой не будет срезана) */
    cutDate?: Date | string;
    /** experimental: Locale */
    locale?: SupportedCalendarLocales;
    /** Отключены ли выходные для выбора (только при isRange={false}) */
    disableWeekends?: boolean;
    /** Месяц какой даты показать при открытии календаря. По умолчанию — текущий месяц */
    initialVisibleDate?: Nullable<Date>;
    /** Модификаторы дня */
    dayModifiers?: CalendarDayModifications;
    skipMonthDays?: boolean;
};
export type CalendarDayModification = {
    disabled?: boolean;
    holiday?: boolean;
};
type ISO8601DateString = `${number}-${number}-${number}`;
export type CalendarDayModifications = Record<ISO8601DateString, CalendarDayModification>;
export type CalendarDate = {
    day: number;
    month: MonthIndex;
    year: number;
    siblingMonth?: boolean;
    weekDay?: WeekdayIndex;
    weekNumber?: number;
};
export type CalendarDateShort = Pick<CalendarDate, 'day' | 'month' | 'year'>;
export type CalendarDay = Pick<CalendarDate, 'day' | 'weekDay' | 'month' | 'year' | 'siblingMonth'>;
export type CalendarDaySettings = {
    isWeekend: boolean;
    isHovered: boolean;
    isStartDate: boolean;
    isEndDate: boolean;
    isRangeDay: boolean;
    isDisable: boolean;
};
export type CalendarMonth = {
    /**
     * Несмотря на наличие minDate и maxDate, все равно нужно отображать
     * все месяцы максимального и минимального года в листе слева.
     *
     * isWithinMinMaxDate - определяет входит ли месяц в ренджу minDate и maxDate.
     * */
    isWithinMinMaxDate?: boolean;
    /**
     * Индекс месяца в массиве месяцев. Если года 2, то может доходить до 23.
     * */
    monthIndex: number;
    /**
     * Индекс месяца в году, может быть от 0 до 11
     * */
    month: MonthIndex;
    monthLabel: string;
    year: number;
    monthDays: (false | CalendarDay)[];
};
export type CalendarWeekday = {
    weekdayLabel: string;
    isWeekend: boolean;
};
export type CalendarYearWithMonths = Record<string, {
    months: CalendarMonth[];
    year: number;
}>;
export {};
