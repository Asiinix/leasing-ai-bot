export declare const getDiffInMonths: (startDate: Date, endDate: Date) => number;
