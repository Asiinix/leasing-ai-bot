export declare function getDateWithTimeAtZero(date: Date): Date;
