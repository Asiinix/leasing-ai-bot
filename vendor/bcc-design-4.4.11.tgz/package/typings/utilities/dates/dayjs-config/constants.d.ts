export declare const SECOND = 1000;
export declare const MINUTE: number;
export declare const HOUR: number;
export declare const DAY: number;
export declare const SATURDAY_INDEX = 6;
export declare const SUNDAY_INDEX = 0;
export declare const NEXT_SUNDAY_INDEX = 7;
export declare const DAYS_IN_WEEK = 7;
export declare const MONTHS_IN_YEAR = 12;
