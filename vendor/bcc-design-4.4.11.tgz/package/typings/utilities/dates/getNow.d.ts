/**
 * Возвращает количество миллисекунд прошедших с 1 января 1970 года до сегодняшнего дня.
 * @return {number}
 */
export declare function getNow(): number;
