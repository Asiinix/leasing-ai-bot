export declare const getISObyDate: (date: Date, delimiter?: string) => string;
