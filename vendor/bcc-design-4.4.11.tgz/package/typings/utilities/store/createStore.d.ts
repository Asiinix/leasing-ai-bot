import React from 'react';
export declare function createStore<Store>(initialState: Store): {
    Provider: ({ children, dynamicState }: {
        children: React.ReactNode;
        dynamicState?: Store | undefined;
    }) => import("react/jsx-runtime").JSX.Element;
    useStore: <SelectorOutput>(selector: (store: Store) => SelectorOutput) => [SelectorOutput, (value: Partial<Store>) => void];
};
