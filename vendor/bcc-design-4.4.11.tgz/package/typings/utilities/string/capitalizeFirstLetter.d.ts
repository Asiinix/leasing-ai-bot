export declare function capitalizeFirstLetter(st: string): string;
