/** самый обычный пробел */
export declare const CHAR_SPACE = " ";
/** неразрывный пробел  */
export declare const CHAR_NBSP = "\u00A0";
/** узкий неразрывный пробел */
export declare const CHAR_NARROW_NO_BREAK_SPACE = "\u00A0";
export declare const CHAR_ENQUAD = "\u2000";
export declare const CHAR_ENSP = "\u2002";
export declare const CHAR_THINSP = "\u2009";
export declare const CHAR_SIX_PER_EM_SPACE = "\u2006";
export declare const CHAR_MIDDLE_DASH = "\u2013";
export declare const CHAR_WIDE_MIDDLE_DASH = "\u2014";
export declare const CHAR_RIGHT_ARROW = "\u2192";
export declare const CHAR_LIST_MARKER = "\u2022";
export declare const CHAR_LIST_MARKER_THIN = "\u00B7";
export declare const CHAR_DASH = "-";
export declare const CHAR_EN_DASH = "\u2013";
export declare const CHAR_EM_DASH = "\u2014";
export declare const CHAR_MINUS = "\u2212";
export declare const CHAR_MIDDLE_DOT = "\u00B7";
export declare const CHAR_BULLET_DOT = "\u2022";
export declare const CHAR_THIN_SPACE = "\u2006";
export declare const CHAR_ELLIPSES = "\u2026";
/**
 * Используем для указания размеров
 * @example
 * 36×30×27 см
 */
export declare const CHAR_MULTIPLICATION_SIGN = "\u00D7";
