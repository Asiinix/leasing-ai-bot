export declare function formatPrice(price: number, currency?: string): string;
