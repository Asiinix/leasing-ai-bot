export declare const hasFraction: (num: number) => boolean;
