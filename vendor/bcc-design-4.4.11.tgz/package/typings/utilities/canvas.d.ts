type CanvasInstanceType = {
    canvas: HTMLCanvasElement | null;
    ctx: CanvasRenderingContext2D | null;
};
export declare const createCanvasSingleton: () => CanvasInstanceType;
export {};
