export declare const getElementHorizontalDimensions: (element: HTMLElement) => {
    totalWidth: number;
    width: number;
    marginLeft: number;
    marginRight: number;
    paddingLeft: number;
    paddingRight: number;
    totalMarginsAndPaddings?: undefined;
} | {
    totalWidth: number;
    totalMarginsAndPaddings: number;
    width: number;
    marginLeft: number;
    marginRight: number;
    paddingLeft: number;
    paddingRight: number;
};
