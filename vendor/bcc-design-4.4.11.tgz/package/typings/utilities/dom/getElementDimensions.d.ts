export type ElementDimensions = {
    width: number;
    height: number;
};
export declare const getElementDimensions: (element: HTMLElement) => ElementDimensions;
