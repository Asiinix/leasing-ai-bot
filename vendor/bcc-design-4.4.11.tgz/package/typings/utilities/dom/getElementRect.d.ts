/**
 *  Имитация element.getBoundingClientRect(), но без reflow
 *  плохо работает для элементов, которые имеют position: absolute
 * */
export declare function getElementRect(element: HTMLElement): DOMRect;
