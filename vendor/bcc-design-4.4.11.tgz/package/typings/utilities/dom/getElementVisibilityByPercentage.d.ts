export declare function getElementVisibilityByPercentage(element: HTMLDivElement | null, withDecimals?: boolean): number;
