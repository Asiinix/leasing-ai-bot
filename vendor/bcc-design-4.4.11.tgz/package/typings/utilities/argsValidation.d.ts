export declare const validateArg: <T = any>(value: T | undefined, availableOptions: T[], fallback: T) => T;
