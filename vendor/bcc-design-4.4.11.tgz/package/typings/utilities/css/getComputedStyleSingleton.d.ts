export declare const createComputedStyleSingleton: (element: HTMLElement) => CSSStyleDeclaration;
