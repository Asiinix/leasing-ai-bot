export declare const getImageSrc: (img: unknown) => string;
export default getImageSrc;
