export declare const getWindow: () => (Window & typeof globalThis) | null;
export declare const getWindowNavigator: () => Navigator | null;
