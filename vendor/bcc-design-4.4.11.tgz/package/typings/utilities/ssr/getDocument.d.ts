export declare const getDocument: () => Document | null;
export declare const getDocumentBody: () => HTMLBodyElement | null;
export declare const getDocumentElement: () => HTMLElement | null;
export declare const getDocumentBodyClassList: () => DOMTokenList | null;
